"""
regulatory_checker.py — FinExtract AI
Checks PDF annual report disclosures against CSRD, TCFD, and EU Taxonomy frameworks.

Architecture: 3 batched OpenAI gpt-4o-mini calls (one per framework).
"""

import json
import os
import re
import csv
import logging
from pathlib import Path
from typing import Optional

import anthropic
import pandas as pd

from config import ANTHROPIC_API_KEY, EXTRACTION_MODEL, OUTPUT_DIR

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Framework requirement constants
# ---------------------------------------------------------------------------

CSRD_REQUIREMENTS: list[dict] = [
    {
        "id": "E1-1",
        "standard": "ESRS E1",
        "topic": "Climate Change Mitigation",
        "requirement": "Transition plan for climate change mitigation including decarbonisation targets and milestones.",
        "mandatory": True,
    },
    {
        "id": "E1-4",
        "standard": "ESRS E1",
        "topic": "Climate Change Targets",
        "requirement": "Climate change targets including net-zero target, interim GHG reduction targets, and target year.",
        "mandatory": True,
    },
    {
        "id": "E1-6",
        "standard": "ESRS E1",
        "topic": "GHG Emissions",
        "requirement": "Gross Scope 1, Scope 2 (location-based and market-based), and Scope 3 GHG emissions with methodology.",
        "mandatory": True,
    },
    {
        "id": "E1-7",
        "standard": "ESRS E1",
        "topic": "GHG Removals & Carbon Credits",
        "requirement": "GHG removals and carbon credits used, including nature-based and technology-based removals.",
        "mandatory": True,
    },
    {
        "id": "E1-8",
        "standard": "ESRS E1",
        "topic": "Internal Carbon Price",
        "requirement": "Internal carbon pricing mechanism used for decision-making, including price per tonne of CO2.",
        "mandatory": False,
    },
    {
        "id": "E1-9",
        "standard": "ESRS E1",
        "topic": "Physical & Transition Risk Financial Effects",
        "requirement": "Financial effects of physical and transition climate-related risks and opportunities on the business.",
        "mandatory": True,
    },
    {
        "id": "E2-4",
        "standard": "ESRS E2",
        "topic": "Air Pollutants",
        "requirement": "Air pollutants including sulphur oxides (SOx), nitrogen oxides (NOx), and particulate matter (PM) emissions.",
        "mandatory": True,
    },
    {
        "id": "E3-4",
        "standard": "ESRS E3",
        "topic": "Water Consumption",
        "requirement": "Total water consumption, water recycled and reused, and water intensity metrics.",
        "mandatory": True,
    },
    {
        "id": "E4-6",
        "standard": "ESRS E4",
        "topic": "Biodiversity & Ecosystems",
        "requirement": "Biodiversity and ecosystem impacts, including land use and species affected.",
        "mandatory": True,
    },
    {
        "id": "E5-5",
        "standard": "ESRS E5",
        "topic": "Circular Economy",
        "requirement": "Resource use and circular economy metrics including material input, waste generated, and circularity rates.",
        "mandatory": True,
    },
    {
        "id": "S1-1",
        "standard": "ESRS S1",
        "topic": "Own Workforce Diversity",
        "requirement": "Own workforce diversity and characteristics including headcount by gender, age group, and employment type.",
        "mandatory": True,
    },
    {
        "id": "S1-8",
        "standard": "ESRS S1",
        "topic": "Collective Bargaining",
        "requirement": "Collective bargaining coverage and social dialogue including percentage of employees covered.",
        "mandatory": True,
    },
    {
        "id": "S1-14",
        "standard": "ESRS S1",
        "topic": "Health & Safety",
        "requirement": "Health and safety metrics including Lost Time Injury Rate (LTIR), fatalities, and recordable incidents.",
        "mandatory": True,
    },
    {
        "id": "S1-16",
        "standard": "ESRS S1",
        "topic": "Pay Gap Metrics",
        "requirement": "Gender pay gap and CEO pay ratio metrics with methodology.",
        "mandatory": True,
    },
    {
        "id": "G1-1",
        "standard": "ESRS G1",
        "topic": "Business Conduct",
        "requirement": "Business conduct policies including anti-corruption, anti-bribery, and whistleblower protection.",
        "mandatory": True,
    },
    {
        "id": "G1-4",
        "standard": "ESRS G1",
        "topic": "Corruption Incidents",
        "requirement": "Number of confirmed corruption incidents and legal proceedings related to corruption.",
        "mandatory": True,
    },
    {
        "id": "G1-6",
        "standard": "ESRS G1",
        "topic": "Payment Practices",
        "requirement": "Payment practices including average payment period and percentage of payments beyond agreed terms.",
        "mandatory": True,
    },
    {
        "id": "E1-2",
        "standard": "ESRS E1",
        "topic": "Climate Change Policies",
        "requirement": "Policies related to climate change mitigation and adaptation including scope, actions, and resources.",
        "mandatory": True,
    },
    {
        "id": "S1-9",
        "standard": "ESRS S1",
        "topic": "Diversity Targets",
        "requirement": "Diversity targets and outcomes including gender balance targets and progress against them.",
        "mandatory": False,
    },
    {
        "id": "G1-2",
        "standard": "ESRS G1",
        "topic": "Supplier Relations",
        "requirement": "Management of relationships with suppliers including supplier due diligence and screening processes.",
        "mandatory": True,
    },
]

TCFD_REQUIREMENTS: list[dict] = [
    {
        "id": "GOV-1",
        "pillar": "Governance",
        "requirement": "Board oversight of climate-related risks and opportunities, including board-level committees and frequency of oversight.",
    },
    {
        "id": "GOV-2",
        "pillar": "Governance",
        "requirement": "Management's role in assessing and managing climate-related risks and opportunities, including senior management roles and responsibilities.",
    },
    {
        "id": "STR-1",
        "pillar": "Strategy",
        "requirement": "Short, medium, and long-term climate-related risks and opportunities identified by the organisation.",
    },
    {
        "id": "STR-2",
        "pillar": "Strategy",
        "requirement": "Impact of climate-related risks and opportunities on business, strategy, and financial planning.",
    },
    {
        "id": "STR-3",
        "pillar": "Strategy",
        "requirement": "Scenario analysis using 2°C or lower scenarios and physical risk scenarios to assess strategic resilience.",
    },
    {
        "id": "RM-1",
        "pillar": "Risk Management",
        "requirement": "Organisation's process for identifying and assessing climate-related risks.",
    },
    {
        "id": "RM-2",
        "pillar": "Risk Management",
        "requirement": "Organisation's process for managing climate-related risks.",
    },
    {
        "id": "RM-3",
        "pillar": "Risk Management",
        "requirement": "Integration of climate risk identification, assessment, and management processes into overall risk management.",
    },
    {
        "id": "MET-1",
        "pillar": "Metrics & Targets",
        "requirement": "Scope 1 and Scope 2 GHG emissions and, if appropriate, Scope 3 emissions, with associated methodology.",
    },
    {
        "id": "MET-2",
        "pillar": "Metrics & Targets",
        "requirement": "Climate-related risks and opportunities metrics used by the organisation (sector-specific if applicable).",
    },
    {
        "id": "MET-3",
        "pillar": "Metrics & Targets",
        "requirement": "GHG reduction targets and performance against these targets.",
    },
]

EU_TAXONOMY_REQUIREMENTS: list[dict] = [
    {
        "id": "ART8-1",
        "article": "Article 8(1)",
        "requirement": "Disclosure of proportion of turnover/revenue from taxonomy-eligible economic activities.",
    },
    {
        "id": "ART8-2",
        "article": "Article 8(2)",
        "requirement": "Disclosure of proportion of turnover/revenue from taxonomy-aligned economic activities.",
    },
    {
        "id": "ART8-3",
        "article": "Article 8(3)",
        "requirement": "CapEx plan for activities associated with taxonomy-aligned economic activities.",
    },
    {
        "id": "ART8-4",
        "article": "Article 8(4)",
        "requirement": "OpEx (operating expenditure) disclosure for taxonomy-eligible and taxonomy-aligned activities.",
    },
    {
        "id": "OBJ1",
        "article": "Objective 1",
        "requirement": "Assessment of alignment with the climate change mitigation objective including supporting activities.",
    },
    {
        "id": "OBJ2",
        "article": "Objective 2",
        "requirement": "Assessment of alignment with the climate change adaptation objective.",
    },
    {
        "id": "DNSH",
        "article": "DNSH",
        "requirement": "Do No Significant Harm (DNSH) assessment across all six EU Taxonomy environmental objectives.",
    },
    {
        "id": "MSS",
        "article": "Minimum Safeguards",
        "requirement": "Minimum social safeguards compliance including OECD guidelines and UN guiding principles.",
    },
]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_requirement_list_csrd() -> str:
    lines = []
    for i, req in enumerate(CSRD_REQUIREMENTS, 1):
        mandatory_label = "(Mandatory)" if req["mandatory"] else "(Voluntary)"
        lines.append(
            f"{i}. [{req['id']}] {req['topic']} {mandatory_label}\n"
            f"   Standard: {req['standard']}\n"
            f"   Requirement: {req['requirement']}"
        )
    return "\n\n".join(lines)


def _build_requirement_list_tcfd() -> str:
    lines = []
    for i, req in enumerate(TCFD_REQUIREMENTS, 1):
        lines.append(
            f"{i}. [{req['id']}] Pillar: {req['pillar']}\n"
            f"   Requirement: {req['requirement']}"
        )
    return "\n\n".join(lines)


def _build_requirement_list_eu_taxonomy() -> str:
    lines = []
    for i, req in enumerate(EU_TAXONOMY_REQUIREMENTS, 1):
        lines.append(
            f"{i}. [{req['id']}] {req['article']}\n"
            f"   Requirement: {req['requirement']}"
        )
    return "\n\n".join(lines)


def _parse_json_response(raw_text: str, expected_ids: list[str]) -> list[dict]:
    """Robustly parse a JSON array from Claude's response."""
    # Strip markdown code fences if present
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = cleaned.strip()

    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, list):
            return parsed
    except json.JSONDecodeError:
        pass

    # Attempt to extract JSON array with regex
    match = re.search(r"\[.*\]", cleaned, re.DOTALL)
    if match:
        try:
            parsed = json.loads(match.group(0))
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass

    # Fall back to empty result set so the caller can continue
    logger.warning("Failed to parse JSON response; returning not_disclosed defaults.")
    return [
        {
            "id": req_id,
            "status": "not_disclosed",
            "evidence": "Parse error — response could not be decoded.",
            "gap_description": "Unable to verify due to a parsing error.",
        }
        for req_id in expected_ids
    ]


def _call_haiku_for_framework(
    client: anthropic.Anthropic,
    framework_name: str,
    requirement_list_text: str,
    pdf_text: str,
    framework_id_list: list[str],
) -> list[dict]:
    """Make a single API call for one framework and return parsed results."""
    doc_excerpt = pdf_text[:60_000]

    system_prompt = (
        f"You are a regulatory compliance analyst checking an annual report against "
        f"{framework_name} requirements. For each requirement, check the document text "
        f"carefully. Be strict — only mark 'disclosed' if actual data or an explicit "
        f"statement is found. 'partial' means some information is present but incomplete. "
        f"'not_disclosed' means the topic is absent or only mentioned vaguely without data."
    )

    user_prompt = (
        f"Check the following {framework_name} requirements against the document excerpt below.\n\n"
        f"REQUIREMENTS:\n{requirement_list_text}\n\n"
        f"DOCUMENT TEXT:\n{doc_excerpt}\n\n"
        f"Return ONLY a valid JSON array with one object per requirement in this exact format:\n"
        f'[{{"id": "REQ-ID", "status": "disclosed"|"partial"|"not_disclosed", '
        f'"evidence": "verbatim quote or Not found", "gap_description": "description of what is missing or confirmed"}}]\n\n'
        f"Do not include any text outside the JSON array."
    )

    try:
        response = client.messages.create(
            model=EXTRACTION_MODEL,
            max_tokens=8192,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        raw_text = response.content[0].text

        return _parse_json_response(raw_text, framework_id_list)

    except anthropic.AuthenticationError:
        logger.error("Invalid or missing Anthropic API key.")
        return [
            {
                "id": req_id,
                "status": "not_disclosed",
                "evidence": "Not found",
                "gap_description": "API key missing or invalid — analysis could not be performed.",
            }
            for req_id in framework_id_list
        ]
    except anthropic.APIError as exc:
        logger.error("API error during framework check: %s", exc)
        return [
            {
                "id": req_id,
                "status": "not_disclosed",
                "evidence": "Not found",
                "gap_description": f"API error: {exc}",
            }
            for req_id in framework_id_list
        ]


def _merge_requirements_with_results(
    base_requirements: list[dict],
    api_results: list[dict],
) -> list[dict]:
    """Merge static requirement metadata with API-returned status/evidence."""
    results_by_id = {r.get("id", ""): r for r in api_results}
    merged = []
    for req in base_requirements:
        req_id = req["id"]
        api_result = results_by_id.get(req_id, {})
        merged.append(
            {
                **req,
                "status": api_result.get("status", "not_disclosed"),
                "evidence": api_result.get("evidence", "Not found"),
                "gap_description": api_result.get("gap_description", "Not checked."),
            }
        )
    return merged


def _compute_counts(requirements: list[dict]) -> dict:
    disclosed = sum(1 for r in requirements if r["status"] == "disclosed")
    partial = sum(1 for r in requirements if r["status"] == "partial")
    not_disclosed = sum(1 for r in requirements if r["status"] == "not_disclosed")
    total = len(requirements)
    overall_pct = round((disclosed + partial) / total * 100, 1) if total > 0 else 0.0
    return {
        "requirements": requirements,
        "disclosed_count": disclosed,
        "partial_count": partial,
        "not_disclosed_count": not_disclosed,
        "overall_pct": overall_pct,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_regulatory_alignment(pdf_text: str, doc_name: str) -> dict:
    """
    Check a PDF annual report against CSRD, TCFD, and EU Taxonomy requirements.

    Parameters
    ----------
    pdf_text : str
        Full extracted text of the PDF document.
    doc_name : str
        Human-readable name for the document (used in logging and gap reports).

    Returns
    -------
    dict with keys:
        csrd, tcfd, eu_taxonomy — each containing requirements list + counts
        overall_compliance_score — 0-100 float
    """
    if not ANTHROPIC_API_KEY:
        logger.warning("ANTHROPIC_API_KEY not set; returning empty compliance structure.")
        empty_note = "API key not configured — analysis skipped."
        empty_csrd = _compute_counts(
            [
                {**req, "status": "not_disclosed", "evidence": "Not found", "gap_description": empty_note}
                for req in CSRD_REQUIREMENTS
            ]
        )
        empty_tcfd = _compute_counts(
            [
                {**req, "status": "not_disclosed", "evidence": "Not found", "gap_description": empty_note}
                for req in TCFD_REQUIREMENTS
            ]
        )
        empty_eu = _compute_counts(
            [
                {**req, "status": "not_disclosed", "evidence": "Not found", "gap_description": empty_note}
                for req in EU_TAXONOMY_REQUIREMENTS
            ]
        )
        return {
            "csrd": empty_csrd,
            "tcfd": empty_tcfd,
            "eu_taxonomy": empty_eu,
            "overall_compliance_score": 0.0,
        }

    if not pdf_text or not pdf_text.strip():
        logger.warning("Empty PDF text supplied to check_regulatory_alignment.")
        pdf_text = "(No document text available.)"

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    # --- CSRD ---
    logger.info("Running CSRD framework check for %s …", doc_name)
    csrd_req_list = _build_requirement_list_csrd()
    csrd_ids = [r["id"] for r in CSRD_REQUIREMENTS]
    csrd_raw = _call_haiku_for_framework(
        client, "CSRD / ESRS", csrd_req_list, pdf_text, csrd_ids
    )
    csrd_merged = _merge_requirements_with_results(CSRD_REQUIREMENTS, csrd_raw)
    csrd_result = _compute_counts(csrd_merged)

    # --- TCFD ---
    logger.info("Running TCFD framework check for %s …", doc_name)
    tcfd_req_list = _build_requirement_list_tcfd()
    tcfd_ids = [r["id"] for r in TCFD_REQUIREMENTS]
    tcfd_raw = _call_haiku_for_framework(
        client, "TCFD", tcfd_req_list, pdf_text, tcfd_ids
    )
    tcfd_merged = _merge_requirements_with_results(TCFD_REQUIREMENTS, tcfd_raw)
    tcfd_result = _compute_counts(tcfd_merged)

    # --- EU Taxonomy ---
    logger.info("Running EU Taxonomy framework check for %s …", doc_name)
    eu_req_list = _build_requirement_list_eu_taxonomy()
    eu_ids = [r["id"] for r in EU_TAXONOMY_REQUIREMENTS]
    eu_raw = _call_haiku_for_framework(
        client, "EU Taxonomy (Article 8)", eu_req_list, pdf_text, eu_ids
    )
    eu_merged = _merge_requirements_with_results(EU_TAXONOMY_REQUIREMENTS, eu_raw)
    eu_result = _compute_counts(eu_merged)

    # --- Overall score ---
    all_pcts = [
        csrd_result["overall_pct"],
        tcfd_result["overall_pct"],
        eu_result["overall_pct"],
    ]
    overall_compliance_score = round(sum(all_pcts) / len(all_pcts), 1)

    result = {
        "csrd": csrd_result,
        "tcfd": tcfd_result,
        "eu_taxonomy": eu_result,
        "overall_compliance_score": overall_compliance_score,
    }

    # Persist gaps to CSV automatically
    try:
        save_regulatory_gaps(result, doc_name)
    except Exception as exc:
        logger.warning("Could not auto-save regulatory gaps: %s", exc)

    return result


def save_regulatory_gaps(data: dict, doc_name: str) -> None:
    """
    Persist regulatory gap analysis results to outputs/regulatory_gaps.csv.

    Parameters
    ----------
    data : dict
        Output of check_regulatory_alignment().
    doc_name : str
        Document identifier written into every row.
    """
    output_path = Path(OUTPUT_DIR) / "regulatory_gaps.csv"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "doc_name",
        "framework",
        "requirement_id",
        "topic_or_pillar",
        "requirement",
        "mandatory",
        "status",
        "evidence",
        "gap_description",
    ]

    rows = []

    # CSRD rows
    for req in data.get("csrd", {}).get("requirements", []):
        rows.append(
            {
                "doc_name": doc_name,
                "framework": "CSRD",
                "requirement_id": req.get("id", ""),
                "topic_or_pillar": req.get("topic", ""),
                "requirement": req.get("requirement", ""),
                "mandatory": req.get("mandatory", True),
                "status": req.get("status", "not_disclosed"),
                "evidence": req.get("evidence", "Not found"),
                "gap_description": req.get("gap_description", ""),
            }
        )

    # TCFD rows
    for req in data.get("tcfd", {}).get("requirements", []):
        rows.append(
            {
                "doc_name": doc_name,
                "framework": "TCFD",
                "requirement_id": req.get("id", ""),
                "topic_or_pillar": req.get("pillar", ""),
                "requirement": req.get("requirement", ""),
                "mandatory": True,
                "status": req.get("status", "not_disclosed"),
                "evidence": req.get("evidence", "Not found"),
                "gap_description": req.get("gap_description", ""),
            }
        )

    # EU Taxonomy rows
    for req in data.get("eu_taxonomy", {}).get("requirements", []):
        rows.append(
            {
                "doc_name": doc_name,
                "framework": "EU Taxonomy",
                "requirement_id": req.get("id", ""),
                "topic_or_pillar": req.get("article", ""),
                "requirement": req.get("requirement", ""),
                "mandatory": True,
                "status": req.get("status", "not_disclosed"),
                "evidence": req.get("evidence", "Not found"),
                "gap_description": req.get("gap_description", ""),
            }
        )

    # Append or create
    write_header = not output_path.exists()
    with open(output_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)

    logger.info("Saved %d regulatory gap rows to %s", len(rows), output_path)


def load_regulatory_gaps(doc_name: Optional[str] = None) -> pd.DataFrame:
    """
    Load previously saved regulatory gap data from outputs/regulatory_gaps.csv.

    Parameters
    ----------
    doc_name : str, optional
        If provided, filter rows to only this document.

    Returns
    -------
    pd.DataFrame — empty DataFrame if file does not exist.
    """
    output_path = Path(OUTPUT_DIR) / "regulatory_gaps.csv"

    if not output_path.exists():
        logger.info("No regulatory_gaps.csv found; returning empty DataFrame.")
        return pd.DataFrame(
            columns=[
                "doc_name",
                "framework",
                "requirement_id",
                "topic_or_pillar",
                "requirement",
                "mandatory",
                "status",
                "evidence",
                "gap_description",
            ]
        )

    try:
        df = pd.read_csv(output_path, encoding="utf-8")
        if doc_name is not None:
            df = df[df["doc_name"] == doc_name].reset_index(drop=True)
        return df
    except Exception as exc:
        logger.error("Failed to load regulatory_gaps.csv: %s", exc)
        return pd.DataFrame()
