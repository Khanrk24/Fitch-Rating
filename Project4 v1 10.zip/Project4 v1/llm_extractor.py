"""
llm_extractor.py — Agent 3
Uses Anthropic Claude to extract structured segment revenue data from page context.
claude-haiku is used by default (fast + cheap), falls back to claude-sonnet for low confidence.
Falls back to rule-based parsing if no API key is set.
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Optional

from config import ANTHROPIC_API_KEY, EXTRACTION_MODEL, COMPLEX_MODEL

# ── system prompt (cached — only billed once per cache TTL) ──────────────────
SYSTEM_PROMPT = """You are a specialist financial data analyst extracting business segment revenue data from annual reports.

Your task is to extract structured segment-level financial data from the provided page content (which may include text and table structures).

EXTRACTION RULES:
1. Extract BUSINESS OPERATING segments only — NOT geographic/regional breakdowns
2. Extract the TOP-LINE revenue/income metric: Revenue, Revenues, Net Sales, Total income, or Total operating income. Do NOT extract derived metrics like EBITDA, EBIT, Operating Profit, Depreciation, Net Income, or Assets. If a page shows both Revenue AND Operating Income sections, extract Revenue only.
3. Include ALL rows in the segment table: individual segments, subtotals (Reportable Segments), inter-segment eliminations, adjustments, reclassifications, and grand totals. Do NOT skip any row even if its label is long or unusual.
4. If the page shows multiple periods (current year + prior year columns), extract ONLY the most recent year column values.
5. Prefer business/operating segments over geographic splits. BUT if the only revenue breakdown on the page is geographic (by country or region), extract it as-is — do not return empty segments just because the split is geographic.
6. Do NOT invent or infer values — only extract what is explicitly stated on the page.
7. Negative values (eliminations, hedging losses, intercompany adjustments) MUST be preserved as negative numbers. Values in parentheses (xxx) are negative.
8. Units: determine from context — "millions", "thousands", "billions"
9. Currency: determine from context (USD, EUR, GBP, DKK, SAR, TRY, etc.)
10. Reporting period: the fiscal year-end date for the reported numbers

OUTPUT FORMAT — return ONLY valid JSON, no commentary:
{
  "segments": [
    {
      "segment": "<exact segment name from document>",
      "value_label": "<Revenue|Net Sales|Total income|Operating income|etc.>",
      "value": <numeric value — negative for eliminations>,
      "is_total": <true if this is a subtotal or grand total row, else false>
    }
  ],
  "currency": "<3-letter ISO code>",
  "unit": "<millions|thousands|billions>",
  "reporting_period": "<YYYY-MM-DD>",
  "confidence": <0.0-1.0 reflecting extraction confidence>,
  "extraction_notes": "<brief note on ambiguities or assumptions>"
}

If you cannot find segment revenue data on this page, return:
{"segments": [], "confidence": 0, "extraction_notes": "No segment revenue table found"}
"""

FEW_SHOT_EXAMPLES = [
    {
        "role": "user",
        "content": """Page 127 of Orsted Annual Report 2025:
=== STRUCTURED TABLES ===
[TABLE 1]
 | Offshore | Onshore | Bioenergy & Other | Reportable Segments | Other activities/ eliminations | Total
Revenue | 54,797 | 2,886 | 16,031 | 73,714 | (470) | 73,244

=== PAGE TEXT ===
Note 3 – Segment information Revenue DKK million 2025"""
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "segments": [
                {"segment": "Offshore", "value_label": "Revenue", "value": 54797.0, "is_total": False},
                {"segment": "Onshore", "value_label": "Revenue", "value": 2886.0, "is_total": False},
                {"segment": "Bioenergy & Other", "value_label": "Revenue", "value": 16031.0, "is_total": False},
                {"segment": "Reportable Segments", "value_label": "Revenue", "value": 73714.0, "is_total": True},
                {"segment": "Other activities/ eliminations", "value_label": "Revenue", "value": -470.0, "is_total": False},
                {"segment": "Total", "value_label": "Revenue", "value": 73244.0, "is_total": True},
            ],
            "currency": "DKK",
            "unit": "millions",
            "reporting_period": "2025-12-31",
            "confidence": 0.98,
            "extraction_notes": "Clear segment table, negative elimination preserved"
        })
    }
]


# ── Claude-based extraction ───────────────────────────────────────────────────

def extract_with_claude(page_context: str, use_complex: bool = False) -> dict:
    """Call Anthropic Claude to extract segment data. Returns parsed dict."""
    if not ANTHROPIC_API_KEY:
        return {"segments": [], "confidence": 0, "extraction_notes": "No API key — using rule-based fallback"}

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    model = COMPLEX_MODEL if use_complex else EXTRACTION_MODEL

    # Build messages excluding the system prompt (passed separately)
    messages = FEW_SHOT_EXAMPLES + [{"role": "user", "content": page_context[:8000]}]

    raw = ""
    try:
        response = client.messages.create(
            model=model,
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            messages=messages,
        )
        raw = response.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)
        return json.loads(raw)

    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except Exception:
                pass
        return {"segments": [], "confidence": 0, "extraction_notes": f"JSON parse error: {raw[:200]}"}

    except Exception as e:
        return {"segments": [], "confidence": 0, "extraction_notes": f"API error: {e}"}


# ── Rule-based fallback (no API key required) ─────────────────────────────────

_NUMBER_RE = re.compile(r"-?\s*[\d,]+(?:\.\d+)?")
_CURRENCY_RE = re.compile(r"\b(USD|EUR|GBP|DKK|NOK|SEK|CHF|JPY|CNY|SAR|TRY|PLN|AUD|CAD)\b", re.I)
_UNIT_RE = re.compile(r"\b(billion|million|thousand)s?\b", re.I)
_PERIOD_RE = re.compile(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})|(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})")


def _parse_number(s: str) -> Optional[float]:
    s = s.replace(",", "").replace(" ", "")
    try:
        return float(s)
    except ValueError:
        return None


def rule_based_extract(page_context: str) -> dict:
    """Heuristic fallback: detect currency/unit and parse numeric table rows."""
    lines = page_context.splitlines()

    # Detect currency
    currency = "USD"
    for line in lines[:30]:
        m = _CURRENCY_RE.search(line)
        if m:
            currency = m.group(1).upper()
            break

    # Detect unit
    unit = "millions"
    for line in lines[:30]:
        m = _UNIT_RE.search(line)
        if m:
            u = m.group(1).lower()
            unit = "billions" if "billion" in u else ("thousands" if "thousand" in u else "millions")
            break

    # Detect reporting period
    reporting_period = datetime.today().strftime("%Y-12-31")
    for line in lines[:50]:
        m = _PERIOD_RE.search(line)
        if m:
            groups = m.groups()
            if groups[3]:  # YYYY-MM-DD style
                reporting_period = f"{groups[3]}-{int(groups[4]):02d}-{int(groups[5]):02d}"
            break

    # Extract segment rows: lines with a label and at least one number
    segments = []
    value_label = "Revenue"
    for line in lines:
        lower = line.lower()
        if any(kw in lower for kw in ["revenue", "net sales", "total income", "operating income", "net revenue"]):
            value_label_match = re.search(r"(revenue|net sales|total income|operating income|net revenue)", lower)
            if value_label_match:
                value_label = value_label_match.group(1).title()
        nums = _NUMBER_RE.findall(line)
        if not nums or len(line) > 200:
            continue
        # Split on pipe or tab to get cells
        cells = re.split(r"\s*\|\s*|\t", line)
        if len(cells) >= 2:
            label = cells[0].strip()
            if not label or len(label) > 80:
                continue
            val_str = nums[-1]  # take last number (current year column)
            val = _parse_number(val_str)
            if val is not None and abs(val) > 0:
                is_total = any(t in label.lower() for t in ["total", "group", "consolidated"])
                segments.append({
                    "segment": label,
                    "value_label": value_label,
                    "value": val,
                    "is_total": is_total,
                })

    return {
        "segments": segments[:20],  # cap at 20 rows
        "currency": currency,
        "unit": unit,
        "reporting_period": reporting_period,
        "confidence": 0.5 if segments else 0.0,
        "extraction_notes": "Rule-based fallback (no API key)",
    }


# ── Public interface ──────────────────────────────────────────────────────────

def extract_segments(page_context: str, retry_with_complex: bool = True) -> dict:
    """
    Primary extraction entry point.
    1. Try claude-haiku (fast + cheap)
    2. If confidence < 0.6, retry with claude-sonnet
    3. If no API key, fall back to rule-based extraction
    """
    if not ANTHROPIC_API_KEY:
        return rule_based_extract(page_context)

    result = extract_with_claude(page_context, use_complex=False)

    # Escalate to Sonnet if haiku is uncertain or returns empty segments
    if retry_with_complex and (result.get("confidence", 0) < 0.6 or not result.get("segments")):
        result = extract_with_claude(page_context, use_complex=True)

    # Validate: segments that claim to be totals should be >= individual segments
    _validate_sums(result)

    return result


def _validate_sums(result: dict) -> None:
    """Check that non-total segments roughly sum to total rows. Adds a warning if not."""
    segments = result.get("segments", [])
    totals = [s for s in segments if s.get("is_total")]
    non_totals = [s for s in segments if not s.get("is_total")]
    if not totals or not non_totals:
        return
    computed_sum = sum(s["value"] for s in non_totals)
    for t in totals:
        ratio = abs(computed_sum / t["value"]) if t["value"] != 0 else 0
        if not (0.85 <= ratio <= 1.15):
            result["extraction_notes"] = (
                result.get("extraction_notes", "") +
                f" | WARNING: segment sum {computed_sum:.0f} vs total {t['value']:.0f} (ratio={ratio:.2f})"
            )
            result["confidence"] = min(result.get("confidence", 1.0), 0.7)


if __name__ == "__main__":
    # Quick test with dummy context
    ctx = """
    === STRUCTURED TABLES ===
    [TABLE 1]
    Segment | Revenue 2025 | Revenue 2024
    Google Services | 342,721 | 307,394
    Google Cloud | 58,705 | 43,228
    Other Bets | 1,537 | 1,527
    Hedging gains (losses) | (127) | 236
    Total revenues | 402,836 | 352,385
    === PAGE TEXT ===
    USD millions. Year ended December 31, 2025.
    """
    result = extract_segments(ctx)
    print(json.dumps(result, indent=2))
