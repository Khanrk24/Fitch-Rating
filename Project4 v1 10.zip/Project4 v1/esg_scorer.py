"""
esg_scorer.py — Agent 5
ESG scoring + greenwashing detection from full PDF text.

Scoring dimensions:
  E (Environmental) — emissions coverage, intensity, renewable energy, targets
  S (Social)        — employee metrics, safety, diversity mentions
  G (Governance)    — audit quality, board mentions, compliance language

Greenwashing flags (reduce E score):
  - Vague aspirational language without metrics
  - Scope 3 absent when Scope 1/2 present
  - No third-party assurance
  - Suspiciously round or improving numbers without explanation
  - Positive reframing of negative absolute increase
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

# ── Pattern libraries ──────────────────────────────────────────────────────────

# Emissions patterns
_SCOPE1 = re.compile(r"scope\s*1|direct\s+emission", re.I)
_SCOPE2 = re.compile(r"scope\s*2|indirect\s+emission|energy\s+indirect", re.I)
_SCOPE3 = re.compile(r"scope\s*3|value\s+chain|upstream.*emission|downstream.*emission", re.I)
_NET_ZERO = re.compile(r"net[\s-]zero|carbon\s+neutral|climate\s+neutral", re.I)
_CARBON_TARGET = re.compile(r"\d{4}.*?(carbon|emission|co2|ghg).*?target|target.*?\d{4}", re.I)
_THIRD_PARTY = re.compile(
    r"assured|assurance|verified|verification|bureau veritas|deloitte|pwc|kpmg|ey\b|ernst|dnv|sgv|lloyds register",
    re.I,
)
_RENEWABLE = re.compile(r"renewable energy|solar|wind\s+energy|hydro|biomass|ppa|power purchase", re.I)
_INTENSITY = re.compile(r"carbon intensity|emission intensity|co2 per|ghg per|tco2e? per", re.I)

# Social patterns
_SAFETY = re.compile(r"lost[\s-]time|ltir|trir|fatali|injury rate|safety", re.I)
_DIVERSITY = re.compile(r"diversity|inclusion|gender|women.*board|female.*director", re.I)
_EMPLOYEES = re.compile(r"\d[\d,]*\s*(employees|fte|full[\s-]time)", re.I)

# Governance patterns
_AUDIT = re.compile(r"external audit|statutory audit|auditor|audit committee", re.I)
_BOARD = re.compile(r"board of directors|supervisory board|non[\s-]executive|independent director", re.I)
_COMPLIANCE = re.compile(r"compliance|tcfd|csrd|gri|sasb|ifrs s[12]|esrs", re.I)

# Greenwashing red-flag phrases
_VAGUE_PHRASES = [
    r"committed to sustainability",
    r"aspire to",
    r"working towards",
    r"aim(?:ing)? to be",
    r"we believe in",
    r"sustainability is at the heart",
    r"proud of our progress",
    r"green future",
    r"responsible business",
    r"making a difference",
    r"carbon[\s-]neutral by \d{4}",       # goal without current performance
    r"net[\s-]zero by \d{4}",             # same
]
_VAGUE_RE = re.compile("|".join(_VAGUE_PHRASES), re.I)

# Suspicious round-number pattern (e.g. exactly 10,000 or 100,000 tCO2)
_ROUND_NUMBER = re.compile(r"\b[1-9]0{3,}\s*(?:tco2|t co2|tonnes?\s+co2|mtco2)", re.I)


@dataclass
class ESGScore:
    doc: str
    # Raw component scores (0-100)
    e_raw: float = 0.0
    s_raw: float = 0.0
    g_raw: float = 0.0
    # Greenwashing adjustment (0-40 penalty)
    greenwashing_penalty: float = 0.0
    # Flags
    has_scope1: bool = False
    has_scope2: bool = False
    has_scope3: bool = False
    has_net_zero: bool = False
    has_carbon_target: bool = False
    has_third_party: bool = False
    has_renewable: bool = False
    has_intensity: bool = False
    has_safety: bool = False
    has_diversity: bool = False
    has_employees: bool = False
    has_audit: bool = False
    has_board: bool = False
    has_compliance_framework: bool = False
    vague_phrase_count: int = 0
    suspicious_round_numbers: int = 0
    greenwashing_flags: list[str] = field(default_factory=list)

    @property
    def e_score(self) -> float:
        return max(0.0, self.e_raw - self.greenwashing_penalty)

    @property
    def composite(self) -> float:
        return round((self.e_score * 0.5 + self.s_raw * 0.25 + self.g_raw * 0.25), 1)

    @property
    def rating(self) -> str:
        c = self.composite
        if c >= 80:
            return "AAA"
        elif c >= 65:
            return "AA"
        elif c >= 50:
            return "A"
        elif c >= 35:
            return "BBB"
        elif c >= 20:
            return "BB"
        else:
            return "B"

    def to_dict(self) -> dict:
        return {
            "doc": self.doc,
            "e_raw": round(self.e_raw, 1),
            "e_score": round(self.e_score, 1),
            "s_score": round(self.s_raw, 1),
            "g_score": round(self.g_raw, 1),
            "composite": self.composite,
            "rating": self.rating,
            "greenwashing_penalty": round(self.greenwashing_penalty, 1),
            "greenwashing_flags": "; ".join(self.greenwashing_flags),
            "has_scope1": self.has_scope1,
            "has_scope2": self.has_scope2,
            "has_scope3": self.has_scope3,
            "has_third_party_assurance": self.has_third_party,
            "has_net_zero_target": self.has_net_zero,
            "vague_phrase_count": self.vague_phrase_count,
        }


def score_document(pdf_text: str, doc_name: str) -> ESGScore:
    """
    Run full ESG scoring on the complete PDF text.
    pdf_text: concatenated text from all pages (or relevant pages).
    """
    score = ESGScore(doc=doc_name)
    text = pdf_text

    # ── Environmental ─────────────────────────────────────────────────────────
    score.has_scope1 = bool(_SCOPE1.search(text))
    score.has_scope2 = bool(_SCOPE2.search(text))
    score.has_scope3 = bool(_SCOPE3.search(text))
    score.has_net_zero = bool(_NET_ZERO.search(text))
    score.has_carbon_target = bool(_CARBON_TARGET.search(text))
    score.has_third_party = bool(_THIRD_PARTY.search(text))
    score.has_renewable = bool(_RENEWABLE.search(text))
    score.has_intensity = bool(_INTENSITY.search(text))

    e = 0.0
    if score.has_scope1:
        e += 15
    if score.has_scope2:
        e += 15
    if score.has_scope3:
        e += 20
    if score.has_net_zero:
        e += 10
    if score.has_carbon_target:
        e += 10
    if score.has_third_party:
        e += 15
    if score.has_renewable:
        e += 10
    if score.has_intensity:
        e += 5
    score.e_raw = min(e, 100.0)

    # ── Social ────────────────────────────────────────────────────────────────
    score.has_safety = bool(_SAFETY.search(text))
    score.has_diversity = bool(_DIVERSITY.search(text))
    score.has_employees = bool(_EMPLOYEES.search(text))
    s = 0.0
    if score.has_employees:
        s += 30
    if score.has_safety:
        s += 40
    if score.has_diversity:
        s += 30
    score.s_raw = min(s, 100.0)

    # ── Governance ────────────────────────────────────────────────────────────
    score.has_audit = bool(_AUDIT.search(text))
    score.has_board = bool(_BOARD.search(text))
    score.has_compliance_framework = bool(_COMPLIANCE.search(text))
    g = 0.0
    if score.has_audit:
        g += 35
    if score.has_board:
        g += 30
    if score.has_compliance_framework:
        g += 35
    score.g_raw = min(g, 100.0)

    # ── Greenwashing detection ────────────────────────────────────────────────
    vague_matches = _VAGUE_RE.findall(text)
    score.vague_phrase_count = len(vague_matches)
    score.suspicious_round_numbers = len(_ROUND_NUMBER.findall(text))

    penalty = 0.0
    flags = []

    # Flag 1: Scope 1+2 present but Scope 3 missing → selective disclosure
    if (score.has_scope1 or score.has_scope2) and not score.has_scope3:
        penalty += 10
        flags.append("Missing Scope 3 despite reporting Scope 1/2")

    # Flag 2: Net-zero / carbon target claimed but no third-party assurance
    if score.has_net_zero and not score.has_third_party:
        penalty += 8
        flags.append("Net-zero target claimed without third-party assurance")

    # Flag 3: High vague language
    if score.vague_phrase_count >= 3:
        penalty += min(score.vague_phrase_count * 2, 12)
        flags.append(f"High vague language count ({score.vague_phrase_count} phrases)")

    # Flag 4: Suspiciously round emission numbers
    if score.suspicious_round_numbers >= 2:
        penalty += 5
        flags.append(f"Suspiciously round emission numbers ({score.suspicious_round_numbers})")

    # Flag 5: No scope data at all but sustainability claims
    if not score.has_scope1 and not score.has_scope2 and score.has_net_zero:
        penalty += 15
        flags.append("Sustainability claims with no quantified emissions data")

    score.greenwashing_penalty = min(penalty, 40.0)  # cap penalty at 40 pts
    score.greenwashing_flags = flags

    return score


def extract_full_text(pdf_path) -> str:
    """Extract all text from a PDF for ESG scoring."""
    import fitz
    try:
        doc = fitz.open(str(pdf_path))
        pages = []
        for page in doc:
            pages.append(page.get_text())
            if len("".join(pages)) > 200_000:  # cap at ~200k chars
                break
        doc.close()
        return " ".join(pages)
    except Exception:
        return ""


if __name__ == "__main__":
    import sys
    from pathlib import Path
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if path:
        text = extract_full_text(path)
        score = score_document(text, path.name)
        import json
        print(json.dumps(score.to_dict(), indent=2))
    else:
        # Quick demo
        demo_text = """
        Scope 1 emissions: 120,000 tCO2e. Scope 2 emissions: 45,000 tCO2e.
        Net-zero by 2040. Renewable energy sourced at 67%.
        We are committed to sustainability and aspire to a greener future.
        Board of directors includes 4 independent directors.
        External audit performed by Deloitte.
        TCFD-aligned reporting.
        """
        s = score_document(demo_text, "demo.pdf")
        import json
        print(json.dumps(s.to_dict(), indent=2))
