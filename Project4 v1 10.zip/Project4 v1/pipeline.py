"""
pipeline.py — Multi-agent orchestration
Chains together all agents in sequence for each PDF:

  Agent 1: Page Finder          (table_extractor.find_segment_pages)
  Agent 2: Table Extractor      (table_extractor.page_context)
  Agent 3: LLM Extractor        (llm_extractor.extract_segments)
  Agent 4: NACE Tagger          (nace_tagger.tag_document)
  Agent 5: ESG Scorer           (esg_scorer.score_document)
  Agent 6: Validator            (validator.validate_document)

Each agent's output feeds the next. Results are saved to CSV.
Human review is handled by app.py (Streamlit UI).
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Optional

import pandas as pd
from tqdm import tqdm

from config import (
    PDF_DIR, OUTPUT_DIR, EXTRACTED_CSV, ESG_CSV, NACE_CSV,
    FITCH_FACTORS_CSV, FORWARD_LOOKING_CSV, REGULATORY_GAPS_CSV,
    ANTHROPIC_API_KEY,
)
from table_extractor import find_segment_pages, page_context, extract_text_from_page, extract_tables_from_page
from llm_extractor import extract_segments
from nace_tagger import tag_document, extract_company_context
from esg_scorer import score_document, extract_full_text
from validator import run_full_validation, print_report, load_ground_truth, GROUND_TRUTH_PATH

# ── Geographic keywords for fallback page search ──────────────────────────────
_GEO_KEYWORDS = {
    "by market", "by region", "by geography", "by country",
    "retail sales", "sales by market", "sales by region",
    "revenue by market", "revenue by region", "revenue by geography",
    "net revenue by", "geographic breakdown", "geographic information",
    "geographic segment", "geographic area",
    "top 10 market", "top 10 retail", "market breakdown",
    "regional breakdown", "regional revenue",
}


def _geographic_fallback(pdf_path: Path, verbose: bool = False) -> dict | None:
    """
    Fallback for single-segment companies: scan for geographic / market breakdowns
    and extract them via the LLM with a geographic-aware prompt.
    Returns an extraction dict (same shape as extract_segments) or None.
    """
    import pdfplumber
    from llm_extractor import extract_segments

    geo_candidates = []
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            total = len(pdf.pages)
            for i, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                lower = text.lower()
                hits = sum(1 for kw in _GEO_KEYWORDS if kw in lower)
                if hits >= 1:
                    tables = []
                    try:
                        raw_tables = page.extract_tables() or []
                        for tbl in raw_tables:
                            if tbl and len(tbl) >= 2:
                                rows = [[str(c or "").strip() for c in row] for row in tbl]
                                tables.append(rows)
                    except Exception:
                        pass
                    geo_candidates.append({
                        "page_num": i + 1,
                        "text": text,
                        "score": hits,
                        "tables": tables,
                        "include_hits": hits,
                        "exclude_hits": 0,
                    })
    except Exception:
        return None

    if not geo_candidates:
        return None

    geo_candidates.sort(key=lambda x: x["score"], reverse=True)

    best = None
    best_page = None
    for cand in geo_candidates[:5]:
        ctx = page_context(cand)
        # Prepend a hint so the LLM extracts geographic data for single-segment companies
        ctx_patched = (
            "[NOTE: This company may operate as a single segment. "
            "Extract geographic/market revenue or sales data as segments if present.]\n\n"
            + ctx
        )
        extraction = extract_segments(ctx_patched)
        n_segs = len(extraction.get("segments", []))
        if n_segs > 0:
            if best is None or n_segs > len(best.get("segments", [])):
                best = extraction
                best_page = cand["page_num"]
        if verbose:
            print(f"  [Geo fallback] Page {cand['page_num']}: {n_segs} geographic segments found")

    if best and best.get("segments"):
        best["source_page"] = best_page
        if not best.get("extraction_notes"):
            best["extraction_notes"] = "Geographic/market breakdown (single operating segment)"
        return best
    return None


def process_one_pdf(
    pdf_path: Path,
    verbose: bool = False,
    force_page: int = None,
    on_step: "callable | None" = None,
) -> dict:
    """
    Run the full pipeline on a single PDF.
    Returns a unified result dict for that document.

    on_step(label, detail) — optional callback called at each agent boundary
    so the UI can show live step progress.
    """
    def _step(label: str, detail: str = "") -> None:
        if on_step:
            try:
                on_step(label, detail)
            except Exception:
                pass
        if verbose:
            print(f"  [{label}] {detail}")

    doc_name = pdf_path.name
    if verbose:
        print(f"\n[Pipeline] Processing: {doc_name}")

    result = {
        "doc": doc_name,
        "pdf_path": str(pdf_path),
        "segments": [],
        "currency": "",
        "unit": "",
        "reporting_period": "",
        "extraction_confidence": 0.0,
        "extraction_notes": "",
        "esg": None,
        "fitch_factors": None,
        "forward_looking": None,
        "regulatory_gaps": None,
        "error": None,
    }

    # ── Agent 1+2: Find best candidate pages ─────────────────────────────────
    _step("Scanning", "Finding segment/revenue table pages…")
    if force_page:
        # Analyst-specified page override
        text = extract_text_from_page(pdf_path, force_page)
        candidates = [{
            "page_num": force_page, "text": text, "score": 99,
            "include_hits": 99, "exclude_hits": 0,
            "tables": extract_tables_from_page(pdf_path, force_page),
        }]
    else:
        candidates = find_segment_pages(pdf_path, top_n=7)

    result["candidate_pages"] = [c["page_num"] for c in candidates]

    if not candidates:
        result["error"] = "No candidate pages found"
        if verbose:
            print(f"  [Agent 1] No candidates — skipping")
        return result

    if verbose:
        print(f"  [Agent 1] Found {len(candidates)} candidate pages: {[c['page_num'] for c in candidates]}")

    # ── Agent 3: LLM extraction — try top candidate pages ────────────────────
    _step("Extracting segments", f"Running LLM extraction on {len(candidates)} candidate page(s)…")
    best_extraction = None
    best_page = None

    for candidate in candidates:
        ctx = page_context(candidate)
        extraction = extract_segments(ctx)
        n_segs = len(extraction.get("segments", []))
        conf = extraction.get("confidence", 0)

        if verbose:
            print(f"  [Agent 3] Page {candidate['page_num']}: {n_segs} segments, confidence={conf:.2f}")

        # Selection: prefer more segments when confidence is adequate (>=0.65).
        # Only prefer fewer segments if new confidence is >0.15 higher AND new count >= 3.
        current_conf = best_extraction.get("confidence", 0) if best_extraction else -1
        current_segs = len(best_extraction.get("segments", [])) if best_extraction else 0
        is_better = False
        if n_segs > current_segs and conf >= 0.65:
            is_better = True  # more segments at adequate confidence → prefer
        elif conf > current_conf + 0.15 and n_segs >= max(current_segs, 3):
            is_better = True  # much higher confidence AND comparable count
        elif conf > current_conf and n_segs >= current_segs:
            is_better = True  # strictly better on both
        if is_better:
            best_extraction = extraction
            best_page = candidate["page_num"]

        # Stop early only on very high confidence with reasonable segment count
        if conf >= 0.95 and n_segs >= 4:
            break

    if not best_extraction or not best_extraction.get("segments"):
        # ── Geographic / market fallback ─────────────────────────────────────
        geo_extraction = _geographic_fallback(pdf_path, verbose=verbose)
        if geo_extraction and geo_extraction.get("segments"):
            best_extraction = geo_extraction
            best_page = geo_extraction.get("source_page")
            if verbose:
                print(f"  [Agent 3 fallback] Geographic data found — "
                      f"{len(geo_extraction['segments'])} markets on page {best_page}")
        else:
            result["error"] = "LLM could not extract segments"
            return result

    result["segments"] = best_extraction.get("segments", [])
    result["currency"] = best_extraction.get("currency", "")
    result["unit"] = best_extraction.get("unit", "")
    result["reporting_period"] = best_extraction.get("reporting_period", "")
    result["extraction_confidence"] = best_extraction.get("confidence", 0)
    result["extraction_notes"] = best_extraction.get("extraction_notes", "")
    result["source_page"] = best_page

    _step("NACE classification", f"Tagging {len(result['segments'])} segments with EU taxonomy codes…")
    # ── Agent 4: NACE tagging ─────────────────────────────────────────────────
    first_page_text = extract_text_from_page(pdf_path, 1)
    company_ctx = extract_company_context(first_page_text)
    tag_document(result["segments"], company_ctx)

    if verbose:
        nace_codes = list({s.get("nace_section", "?") for s in result["segments"]})
        print(f"  [Agent 4] NACE sections assigned: {nace_codes}")

    _step("ESG scoring", "Scoring Environmental, Social & Governance pillars across full text…")
    # ── Agent 5: ESG scoring ──────────────────────────────────────────────────
    full_text = extract_full_text(pdf_path)
    esg = score_document(full_text, doc_name)
    result["esg"] = esg.to_dict()

    if verbose:
        print(f"  [Agent 5] ESG composite={esg.composite}, rating={esg.rating}, "
              f"greenwashing_penalty={esg.greenwashing_penalty:.1f}")
        if esg.greenwashing_flags:
            print(f"  [Agent 5] Greenwashing flags: {'; '.join(esg.greenwashing_flags)}")

    _step("Fitch factors", "Scoring 15-factor Fitch ESG relevance framework…")
    # ── Agent 5b: Fitch Factor Scoring ───────────────────────────────────────
    try:
        from fitch_scorer import score_fitch_factors, save_fitch_scores
        fitch_factors = score_fitch_factors(full_text, doc_name)
        result["fitch_factors"] = fitch_factors
        save_fitch_scores(fitch_factors, doc_name)
        if verbose:
            avg = sum(f["score"] for f in fitch_factors) / len(fitch_factors) if fitch_factors else 0
            print(f"  [Agent 5b] Fitch factors scored: {len(fitch_factors)} factors, avg={avg:.1f}/5")
    except Exception as e:
        if verbose:
            print(f"  [Agent 5b] Fitch scoring skipped: {e}")

    _step("Forward-looking intelligence", "Extracting net-zero commitments, capital plans, key risks…")
    # ── Agent 5c: Forward-looking Intelligence ────────────────────────────────
    try:
        from forward_looking import extract_forward_looking, save_forward_looking
        fwd = extract_forward_looking(full_text, doc_name)
        result["forward_looking"] = fwd
        save_forward_looking(fwd, doc_name)
        if verbose:
            nz = fwd.get("net_zero_year")
            risks = len(fwd.get("key_risks") or [])
            print(f"  [Agent 5c] Forward-looking: net_zero={nz}, risks={risks}")
    except Exception as e:
        if verbose:
            print(f"  [Agent 5c] Forward-looking skipped: {e}")

    _step("Regulatory alignment", "Checking CSRD / ESRS, TCFD, and EU Taxonomy compliance gaps…")
    # ── Agent 5d: Regulatory Alignment Check ─────────────────────────────────
    try:
        from regulatory_checker import check_regulatory_alignment, save_regulatory_gaps
        reg = check_regulatory_alignment(full_text, doc_name)
        result["regulatory_gaps"] = reg
        save_regulatory_gaps(reg, doc_name)
        if verbose:
            csrd_pct = reg.get("csrd", {}).get("overall_pct", 0)
            tcfd_pct = reg.get("tcfd", {}).get("overall_pct", 0)
            print(f"  [Agent 5d] Regulatory: CSRD={csrd_pct:.0f}%, TCFD={tcfd_pct:.0f}%")
    except Exception as e:
        if verbose:
            print(f"  [Agent 5d] Regulatory check skipped: {e}")

    _step("Complete", f"Extraction complete — {len(result['segments'])} segments found.")
    return result


def save_extracted(results: list[dict]) -> None:
    """Flatten segment-level data and save to CSV."""
    rows = []
    for r in results:
        for seg in r.get("segments", []):
            rows.append({
                "doc": r["doc"],
                "source_page": r.get("source_page", ""),
                "segment": seg.get("segment", ""),
                "value_label": seg.get("value_label", ""),
                "value": seg.get("value", ""),
                "is_total": seg.get("is_total", False),
                "currency": r.get("currency", ""),
                "unit": r.get("unit", ""),
                "reporting_period": r.get("reporting_period", ""),
                "extraction_confidence": r.get("extraction_confidence", ""),
                "extraction_notes": r.get("extraction_notes", ""),
                "nace_section": seg.get("nace_section", ""),
                "nace_division": seg.get("nace_division", ""),
                "nace_description": seg.get("nace_description", ""),
                "nace_confidence": seg.get("nace_confidence", ""),
            })
    if rows:
        pd.DataFrame(rows).to_csv(str(EXTRACTED_CSV), index=False)
        print(f"Extracted segments saved to {EXTRACTED_CSV}")


def save_esg(results: list[dict]) -> None:
    """Save ESG scores to CSV."""
    esg_rows = [r["esg"] for r in results if r.get("esg")]
    if esg_rows:
        pd.DataFrame(esg_rows).to_csv(str(ESG_CSV), index=False)
        print(f"ESG scores saved to {ESG_CSV}")


def run_pipeline(
    pdf_paths: Optional[list[Path]] = None,
    validate: bool = True,
    verbose: bool = True,
    max_pdfs: Optional[int] = None,
) -> dict:
    """
    Run the full pipeline on all (or specified) PDFs.

    Args:
        pdf_paths: list of PDF paths to process. If None, use all PDFs in PDF_DIR.
        validate: whether to run accuracy validation against ground truth.
        verbose: print progress per document.
        max_pdfs: limit number of PDFs (useful for quick testing).
    """
    if pdf_paths is None:
        pdf_paths = sorted(PDF_DIR.glob("*.pdf"))

    if max_pdfs:
        pdf_paths = pdf_paths[:max_pdfs]

    print(f"\n{'='*60}")
    print(f"Starting pipeline: {len(pdf_paths)} PDF(s)")
    print(f"Model: {__import__('config').EXTRACTION_MODEL}")
    print(f"API key: {'SET' if __import__('config').ANTHROPIC_API_KEY else 'NOT SET — using rule-based fallback'}")
    print(f"{'='*60}\n")

    results = []
    errors = []

    for pdf_path in tqdm(pdf_paths, desc="Processing PDFs"):
        try:
            result = process_one_pdf(pdf_path, verbose=verbose)
            results.append(result)
            if result.get("error"):
                errors.append((pdf_path.name, result["error"]))
        except Exception as e:
            errors.append((pdf_path.name, str(e)))
            results.append({"doc": pdf_path.name, "segments": [], "error": str(e)})

    # Save outputs
    save_extracted(results)
    save_esg(results)

    # ── Agent 6: Validation ───────────────────────────────────────────────────
    validation = None
    if validate and GROUND_TRUTH_PATH.exists():
        gt_df = load_ground_truth()
        gt_docs = set(gt_df["doc"].unique())
        validated_results = [r for r in results if r["doc"] in gt_docs]
        if validated_results:
            validation = run_full_validation(results)
            print_report(validation)
        else:
            print("No results matched ground truth document names — skipping validation.")

    if errors:
        print(f"\nErrors on {len(errors)} documents:")
        for name, err in errors:
            print(f"  {name}: {err}")

    return {
        "results": results,
        "validation": validation,
        "errors": errors,
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Financial PDF segment extraction pipeline")
    parser.add_argument("--pdfs", nargs="*", help="Specific PDF filenames to process")
    parser.add_argument("--max", type=int, default=None, help="Max number of PDFs to process")
    parser.add_argument("--no-validate", action="store_true", help="Skip ground truth validation")
    parser.add_argument("--quiet", action="store_true", help="Suppress per-doc verbose output")
    args = parser.parse_args()

    if args.pdfs:
        paths = [PDF_DIR / p for p in args.pdfs]
    else:
        # Default: process ground truth PDFs first for quick testing
        gt_docs = ["82_Orsted Annual Report 2025.pdf",
                   "726_Alliander_Annual_Report_2024 (4).pdf",
                   "728_2025 Annual report.pdf",
                   "766_2024 annual report.pdf",
                   "11140_2025 Consolidated Financial Statements (Dec 2025).pdf"]
        paths = [PDF_DIR / d for d in gt_docs if (PDF_DIR / d).exists()]
        if not paths:
            paths = None  # fall back to all PDFs

    run_pipeline(
        pdf_paths=paths,
        validate=not args.no_validate,
        verbose=not args.quiet,
        max_pdfs=args.max,
    )
