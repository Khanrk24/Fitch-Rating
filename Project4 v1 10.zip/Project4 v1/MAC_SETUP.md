# Mac Setup Guide — FinExtract AI

Complete setup from scratch on a MacBook Pro.

---

## Step 1 — Transfer the project files to your Mac

You need to move two things from your Windows PC:

### Option A — Google Drive (easiest)

1. On your Windows PC, zip the entire `Project4` folder
2. Upload the zip to Google Drive
3. Also upload `sample_ground_truth.xlsx` to Google Drive
4. On your Mac, download both from drive.google.com

### Option B — AirDrop

1. Right-click the `Project4` folder on Windows → "Compress"
2. AirDrop the zip to your Mac
3. AirDrop `sample_ground_truth.xlsx` to your Mac

### Option C — USB drive

Copy both to a USB drive, plug into Mac, copy to Downloads.

**Where to put them on Mac:**

- Unzip `Project4` → move the folder to your Desktop
- Move `sample_ground_truth.xlsx` → your Downloads folder

Your Mac folder should look like:

```
/Users/yourname/Desktop/Project4/
    app.py
    pipeline.py
    config.py
    .env
    requirements.txt
    [all the PDF files]
    ...
```

---

## Step 2 — Install Homebrew (Mac's package manager)

Open **Terminal** (press `Cmd + Space`, type "Terminal", hit Enter).

Paste this and press Enter:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Follow the on-screen instructions. It will ask for your Mac password.

> If you already have Homebrew, skip this step.

---

## Step 3 — Install Python 3

In Terminal:

```bash
brew install python@3.11
```

Verify it worked:

```bash
python3 --version
```

Should print something like `Python 3.11.x`

---

## Step 4 — Go to your project folder

```bash
cd ~/Desktop/Project4
```

Verify the files are there:

```bash
ls
```

You should see `app.py`, `pipeline.py`, `requirements.txt`, etc.

---

## Step 5 — Install Python packages

```bash
pip3 install -r requirements.txt
```

This will take 1–2 minutes. You'll see a lot of text scrolling — that's normal.

---

## Step 6 — Set up your API key

Create the `.env` file:

```bash
nano .env
```

This opens a text editor in Terminal. Type this (replace with your actual key):

```
ANTHROPIC_API_KEY=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
```

Save and exit: press `Ctrl + X`, then `Y`, then `Enter`.

Verify it saved:

```bash
cat .env
```

Should show your API key.

---

## Step 7 — Verify everything works

```bash
python3 -c "from pipeline import process_one_pdf; print('Setup OK')"
```

Should print `Setup OK`. If you see errors, see Troubleshooting below.

---

## Step 8 — Start the app

```bash
python3 -m streamlit run app.py
```

Your browser should open automatically to **[http://localhost:8501](http://localhost:8501)**

If it doesn't open automatically, open your browser and go to: `http://localhost:8501`

> Keep the Terminal window open while using the app. Press `Ctrl + C` in Terminal to stop it.

---

## Every time you want to use it

Open Terminal and run:

```bash
cd ~/Desktop/Project4
python3 -m streamlit run app.py
```

Then go to **[http://localhost:8501](http://localhost:8501)**

---

## Running the pipeline from Terminal (batch processing)

```bash
# Process the 5 ground truth PDFs
python3 pipeline.py

# Process all PDFs in the folder
python3 pipeline.py

# Process first 10 only (for testing)
python3 pipeline.py --max 10

# Process a specific file
python3 pipeline.py --pdfs "82_Orsted Annual Report 2025.pdf"
```

---

## Troubleshooting

### "command not found: python3"

Python isn't installed. Go back to Step 3.

### "command not found: brew"

Homebrew isn't installed. Go back to Step 2.

### "ModuleNotFoundError: No module named 'fitz'"

Packages aren't installed. Run:

```bash
pip3 install -r requirements.txt
```

### "No such file or directory: Project4"

You're in the wrong folder. Run:

```bash
cd ~/Desktop/Project4
```

### App opens but shows errors about ground truth file

The `sample_ground_truth.xlsx` isn't in the right place. Either:

1. Move it to `~/Downloads/sample_ground_truth.xlsx`, OR
2. Add this to your `.env` file:

```
GROUND_TRUTH_PATH=/Users/yourname/Desktop/Project4/sample_ground_truth.xlsx
```

### Port 8501 already in use

```bash
python3 -m streamlit run app.py --server.port 8502
```

Then go to [http://localhost:8502](http://localhost:8502)

### pip3 not found

```bash
python3 -m pip install -r requirements.txt
```

---

## Quick Reference (Mac)

```bash
# Navigate to project
cd ~/Desktop/Project4

# Start web app
python3 -m streamlit run app.py

# Run pipeline (command line)
python3 pipeline.py

# Install/update packages
pip3 install -r requirements.txt

# Check API key is set
cat .env
```

---

## What's different on Mac vs Windows


| Thing           | Windows                     | Mac                        |
| --------------- | --------------------------- | -------------------------- |
| Python command  | `python`                    | `python3`                  |
| Pip command     | `pip` or `python -m pip`    | `pip3` or `python3 -m pip` |
| Terminal app    | Command Prompt / PowerShell | Terminal                   |
| File paths      | `C:\Users\name\Desktop\`    | `/Users/name/Desktop/`     |
| Everything else | Same                        | Same                       |


The project code itself is fully cross-platform — only the commands to run it differ.