"""
table_extractor.py — Agent 1 / 2
Extracts raw text and table structures from PDF pages flagged as segment candidates.
Uses PyMuPDF for text + pdfplumber for table detection. No LLM cost here.
"""
from __future__ import annotations

import re
import json
from pathlib import Path
from typing import Optional
import pdfplumber
import fitz
from config import PDF_DIR


# ── keyword sets ──────────────────────────────────────────────────────────────
SEGMENT_INCLUDE = {
    # General
    "segment", "operating segment", "business segment", "reportable segment",
    "segment information", "segment data", "segment revenue",
    # Revenue labels
    "revenue", "revenues", "net revenues", "net sales", "total revenues",
    "sales", "net revenue", "total income", "operating income",
    "total operating income", "income from operations",
    # Turnover (common in European/UK reports)
    "turnover", "net turnover", "business turnover", "net business turnover",
    # SEC 10-K specific
    "note", "notes to", "disaggregation", "business unit",
    "division", "product line", "service line",
}
GEO_EXCLUDE = {
    # Only exclude if STRONGLY geographic (no segment hits)
    "by geography", "geographic breakdown", "revenue by country",
    "revenue by region", "by destination", "by location",
}


def score_page(text: str) -> tuple[int, int]:
    lower = text.lower()
    inc = sum(1 for kw in SEGMENT_INCLUDE if kw in lower)
    exc = sum(1 for kw in GEO_EXCLUDE if kw in lower)
    return inc, exc


def is_candidate(text: str, min_include: int = 1, max_exclude: int = 3) -> bool:
    inc, exc = score_page(text)
    return inc >= min_include and exc <= max_exclude


def clean(text: str) -> str:
    text = text.replace("\x00", " ")
    return re.sub(r"\s+", " ", text).strip()


# ── pdfplumber table extraction ───────────────────────────────────────────────

def extract_tables_from_page(pdf_path: Path, page_num: int) -> list[list[list[str | None]]]:
    """Return list of tables (each table = list of rows = list of cells)."""
    tables = []
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            page = pdf.pages[page_num - 1]  # 1-indexed
            raw = page.extract_tables()
            if raw:
                tables = raw
    except Exception:
        pass
    return tables


def extract_text_from_page(pdf_path: Path, page_num: int) -> str:
    """PyMuPDF text extraction from a single page."""
    try:
        doc = fitz.open(str(pdf_path))
        page = doc[page_num - 1]
        text = clean(page.get_text())
        doc.close()
        return text
    except Exception:
        return ""


# ── page finder ───────────────────────────────────────────────────────────────

def find_segment_pages(pdf_path: Path, top_n: int = 5) -> list[dict]:
    """
    Scan every page and return the best candidate pages for segment revenue tables.
    Returns list of dicts: {page_num, text, tables, include_hits, exclude_hits, score}
    """
    results = []
    try:
        doc = fitz.open(str(pdf_path))
        total = len(doc)
        doc.close()
    except Exception:
        return []

    for page_num in range(1, total + 1):
        text = extract_text_from_page(pdf_path, page_num)
        if len(text) < 50:
            continue
        inc, exc = score_page(text)
        if inc == 0:
            continue
        # Weight includes heavily; exclude penalty only matters if very few includes
        score = inc * 3 - exc
        if score > 0:
            results.append({
                "page_num": page_num,
                "text": text,
                "include_hits": inc,
                "exclude_hits": exc,
                "score": score,
            })

    # Sort by score and return top candidates
    results.sort(key=lambda x: x["score"], reverse=True)
    top = results[:top_n]

    # Also include pages immediately after the highest-scoring page — segment
    # data often spills onto the very next page (e.g. intro on p.N, table on p.N+1)
    scored_page_nums = {r["page_num"] for r in results}
    if top:
        best_page_num = top[0]["page_num"]
        for adj in (best_page_num + 1, best_page_num + 2):
            if adj not in scored_page_nums:
                text = extract_text_from_page(pdf_path, adj)
                if len(text) >= 50:
                    inc, exc = score_page(text)
                    top.append({
                        "page_num": adj,
                        "text": text,
                        "include_hits": inc,
                        "exclude_hits": exc,
                        "score": inc * 3 - exc,
                    })

    # Attach pdfplumber tables for top pages
    for r in top:
        r["tables"] = extract_tables_from_page(pdf_path, r["page_num"])

    return top


def tables_to_text(tables: list) -> str:
    """Serialise pdfplumber table objects to readable text for the LLM."""
    lines = []
    for i, table in enumerate(tables, 1):
        lines.append(f"[TABLE {i}]")
        for row in table:
            cells = [str(c).strip() if c is not None else "" for c in row]
            lines.append(" | ".join(cells))
        lines.append("")
    return "\n".join(lines)


def page_context(candidate: dict) -> str:
    """
    Build a combined text+table context string for a page.
    Text comes first — PyMuPDF preserves row layout better than pdfplumber
    for multi-column segment tables.
    """
    parts = []
    parts.append("=== PAGE TEXT (primary source) ===")
    parts.append(candidate["text"][:5000])
    # Include pdfplumber tables as secondary reference only if non-trivial
    tables = candidate.get("tables", [])
    if tables and any(len(t) > 2 for t in tables):
        parts.append("\n=== STRUCTURED TABLES (secondary) ===")
        parts.append(tables_to_text(tables)[:2000])
    return "\n".join(parts)


if __name__ == "__main__":
    import sys
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else next(PDF_DIR.glob("82_Orsted*.pdf"))
    candidates = find_segment_pages(path)
    for c in candidates:
        print(f"Page {c['page_num']} | score={c['score']} | tables={len(c.get('tables',[]))}")
        print(c["text"][:300])
        print("---")
