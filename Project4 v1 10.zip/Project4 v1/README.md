# Fitch Ratings Analytics Platform

A professional-grade ESG and credit analytics tool that reads uploaded annual reports and sustainability PDFs, extracts structured data using Claude AI, scores companies across ESG dimensions and Fitch rating factors, checks regulatory compliance, and generates a boardroom-quality report — all from a browser.

---

## Table of Contents

1. [What It Does](#what-it-does)
2. [What Problem It Solves](#what-problem-it-solves)
3. [How It Works](#how-it-works)
4. [Quick Start (Mac)](#quick-start-mac)
5. [Quick Start (Windows)](#quick-start-windows)
6. [API Key Setup](#api-key-setup)
7. [Sharing This App With Someone](#sharing-this-app-with-someone)
8. [Project Structure](#project-structure)
9. [Feature Reference](#feature-reference)
10. [Configuration Options](#configuration-options)
11. [Troubleshooting](#troubleshooting)

---

## What It Does


| Feature                      | Description                                                                                   |
| ---------------------------- | --------------------------------------------------------------------------------------------- |
| **PDF Ingestion**            | Upload one or multiple annual reports / sustainability filings (10-K, CSRD, etc.)             |
| **AI Extraction**            | Claude reads every page and extracts ESG metrics, emissions data, governance info, financials |
| **ESG Scoring**              | Scores companies 0–100 across Environmental, Social, and Governance pillars                   |
| **Fitch Factor Analysis**    | Maps disclosures against Fitch's 13 rating factors with per-factor scoring                    |
| **Greenwashing Detection**   | Flags vague language, missing Scope 3 disclosures, and unsubstantiated claims                 |
| **Regulatory Mapping**       | Checks alignment with TCFD, CSRD, GRI, EU Taxonomy, SASB, and SEC rules                       |
| **Online Enrichment**        | Supplements PDF gaps with live online research (news, peer data, regulatory context)          |
| **Forward-Looking Analysis** | Extracts and evaluates future-oriented ESG commitments and targets                            |
| **Live Market Data**         | Real-time stock prices for the uploaded company + broader market ticker                       |
| **Live News Feed**           | Scrolling news banner prioritizing coverage of the uploaded company                           |
| **Analyst Chatbot**          | Ask questions about any uploaded document in a JP Morgan-style chat interface                 |
| **Report Generation**        | One-click executive HTML report with charts, scores, and sourced disclosures                  |
| **CSV Export**               | Download all extracted data as a spreadsheet                                                  |
| **Globe Intro**              | Cinematic Fitch globe animation on every page load                                            |


---

## What Problem It Solves

ESG analysis today requires analysts to:

- Manually read hundreds of pages of annual reports
- Cross-reference multiple regulatory frameworks
- Verify claims against external data sources
- Produce consistent, comparable scoring across companies

This platform automates all of that in under 2 minutes per filing. A task that takes a junior analyst a full day is reduced to uploading a PDF.

**Target users:** ESG analysts, credit risk teams, institutional investors, compliance officers, and sustainability researchers.

---

## How It Works

```
PDF Upload
    │
    ▼
Page Segmentation          ← Identifies ESG-relevant pages vs. boilerplate
    │
    ▼
Claude AI Extraction       ← Reads each segment; pulls structured data fields
    │
    ▼
┌─────────────────────────────────────────────────────┐
│  Parallel Analysis Pipeline                         │
│                                                     │
│  ESG Scorer  ·  Fitch Factors  ·  Forward-Looking  │
│  NACE Tagger ·  Regulatory Checker ·  Validator     │
└─────────────────────────────────────────────────────┘
    │
    ▼
Online Enrichment          ← Fills gaps using DuckDuckGo search + summarization
    │
    ▼
Report Generator           ← Assembles HTML report with charts and disclosures
    │
    ▼
Streamlit UI               ← Interactive dashboard with chatbot and live market data
```

**AI Model Usage:**

- `claude-haiku-4-5` — fast extraction and scoring (most calls)
- `claude-sonnet-4-6` — complex reasoning, report generation, chatbot

**Data Sources:**

- Uploaded PDFs (primary)
- DuckDuckGo Search API (news and regulatory enrichment)
- Yahoo Finance via `yfinance` (live stock prices)

---

## Quick Start (Mac)

### Prerequisites

- Python 3.10 or higher
- An Anthropic API key (get one free at [console.anthropic.com](https://console.anthropic.com))

### Steps

```bash
# 1. Download / clone the project folder to your Desktop
cd ~/Desktop
# (place the "Project4 v1" folder here)

# 2. Enter the project directory
cd "Project4 v1"

# 3. Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Set up your API key (see API Key Setup section below)
cp .env.example .env
# Open .env in any text editor and paste your Anthropic key

# 6. Launch the app
streamlit run app.py
```

The app opens automatically at **[http://localhost:8501](http://localhost:8501)**

---

## Quick Start (Windows)

### Prerequisites

- Python 3.10+ from [python.org](https://python.org) — check "Add Python to PATH" during install
- An Anthropic API key from [console.anthropic.com](https://console.anthropic.com)

### Steps

Open **Command Prompt** or **PowerShell** and run:

```cmd
# 1. Navigate to the project folder
cd "%USERPROFILE%\Desktop\Project4 v1"

# 2. Create a virtual environment
python -m venv venv
venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set up your API key
copy .env.example .env
# Open .env in Notepad and paste your Anthropic key

# 5. Launch the app
streamlit run app.py
```

App opens at **[http://localhost:8501](http://localhost:8501)**

---

## API Key Setup

Your API key comes from Anthropic (the company that makes Claude AI). It is **not free forever** — you pay per use, but costs are low (typically $0.01–$0.10 per PDF analysis).

### Where to get one

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up / log in
3. Click **API Keys** → **Create Key**
4. Copy the key (it starts with `sk-ant-api03-...`)

### Where it lives in this project

Your key is stored in a file called `**.env`** in the project root:

```
Project4 v1/
    .env          ← YOUR SECRET KEY IS HERE (never share this file)
    .env.example  ← Safe template without any real key (safe to share)
```

The `.env` file looks like this:

```
ANTHROPIC_API_KEY=sk-ant-api03-xxxxxxxxxxxxxxxx
```

The app reads this automatically at startup via `python-dotenv`. You never type the key into the UI.

### Security rules

- **Never commit `.env` to git** — the `.gitignore` file should already exclude it
- **Never email or paste the key in a shared document**
- If you accidentally expose a key, go to [console.anthropic.com](https://console.anthropic.com) and rotate (delete + recreate) it immediately

---

## Sharing This App With Someone

### Option A — They use their own API key (recommended)

Share **everything except the `.env` file**. The recipient creates their own `.env` from the included template:

**What to share (zip these files/folders):**

```
✅ app.py
✅ chatbot.py
✅ config.py
✅ pipeline.py
✅ llm_extractor.py
✅ fitch_scorer.py
✅ esg_scorer.py
✅ forward_looking.py
✅ regulatory_checker.py
✅ company_search.py
✅ report_generator.py
✅ validator.py
✅ nace_tagger.py
✅ table_extractor.py
✅ extract_all_pages.py
✅ requirements.txt
✅ .env.example          ← safe template, no real key
✅ README.md
❌ .env                  ← NEVER SHARE — contains your real API key
❌ outputs/              ← your personal analysis outputs
❌ *.pdf                 ← your personal uploaded documents
```

The recipient then:

1. Copies `.env.example` → `.env`
2. Pastes their own Anthropic API key into `.env`
3. Runs `pip install -r requirements.txt && streamlit run app.py`

---

### Option B — You share your API key with a trusted colleague

Only do this with someone you fully trust. Send the key through a **secure, private** channel:


| Channel                                | Safety                       |
| -------------------------------------- | ---------------------------- |
| Encrypted messaging (Signal, iMessage) | ✅ Safe                       |
| Direct Slack DM (private workspace)    | ✅ Acceptable                 |
| Email                                  | ⚠️ Risky — avoid if possible |
| Shared Google Doc                      | ❌ Never                      |
| GitHub / code comments                 | ❌ Never                      |


Tell them to paste it into their own `.env` file (never hardcode it in any Python file).

**Budget protection:** Set a monthly spending limit at [console.anthropic.com](https://console.anthropic.com) → Billing → Usage Limits before sharing.

---

## Project Structure

```
Project4 v1/
├── app.py                  Main Streamlit application and UI
├── pipeline.py             Orchestrates the full analysis pipeline
├── config.py               All settings, paths, model names
├── .env                    Your secret API keys (never share)
├── .env.example            Safe template for new users
├── requirements.txt        Python package dependencies
│
├── llm_extractor.py        Extracts structured ESG data from PDF text
├── esg_scorer.py           Scores Environmental, Social, Governance pillars
├── fitch_scorer.py         Maps disclosures to Fitch rating factors
├── forward_looking.py      Analyzes future commitments and targets
├── regulatory_checker.py   Checks TCFD, CSRD, GRI, EU Taxonomy, SASB, SEC
├── nace_tagger.py          Tags company with EU NACE industry code
├── table_extractor.py      Parses tables from PDF pages
├── extract_all_pages.py    Full-document page extraction utility
├── validator.py            Cross-checks extracted data for accuracy
├── company_search.py       Online research: news, peers, regulatory context
├── report_generator.py     Assembles the final HTML report
├── chatbot.py              Analyst Intelligence chatbot (Claude-powered)
│
└── outputs/                Generated analysis files (auto-created)
    ├── extracted_segments.csv
    ├── esg_scores.csv
    ├── fitch_factors.csv
    ├── forward_looking.csv
    ├── regulatory_gaps.csv
    ├── nace_tags.csv
    └── validation_results.csv
```

---

## Feature Reference

### Upload & Process

- Drag and drop one or multiple PDFs into the sidebar
- The pipeline runs automatically after each upload
- Each document is named by the actual company name (auto-detected), not the filename
- Remove any document with the × button in the sidebar

### Dashboard Pages


| Page                     | What You See                                              |
| ------------------------ | --------------------------------------------------------- |
| **Overview**             | ESG score gauge, confidence bar, extraction summary       |
| **ESG Analysis**         | Environmental / Social / Governance breakdown with charts |
| **Fitch Factors**        | 13-factor credit scoring grid with per-factor ratings     |
| **Regulatory Mapping**   | TCFD, CSRD, GRI, EU Taxonomy compliance status            |
| **Forward-Looking**      | Targets, commitments, and scenario analysis disclosures   |
| **Research Analysis**    | AI-curated news, peer comparisons, online context         |
| **Generate Report**      | One-click executive HTML report download                  |
| **Analyst Intelligence** | Chat with Claude about the uploaded documents             |


### Market Banner (top of every page)

- **Row 1 — MARKETS:** Live prices for SPY, QQQ, TSLA, NVDA, AAPL + the uploaded company's stock pinned with a "FILING" badge
- **Row 2 — LIVE NEWS:** Scrolling headlines prioritizing coverage of the uploaded company
- **Row 3 — LIVE:** ESG aggregate stats and document count

---

## Configuration Options

All settings are in `config.py`. You can override any of these in `.env`:


| Variable              | Default                                | Description                               |
| --------------------- | -------------------------------------- | ----------------------------------------- |
| `ANTHROPIC_API_KEY`   | *(required)*                           | Your Anthropic API key                    |
| `EXTRACTION_MODEL`    | `claude-haiku-4-5`                     | Model for fast extraction tasks           |
| `COMPLEX_MODEL`       | `claude-sonnet-4-6`                    | Model for complex reasoning and chat      |
| `FITCH_SCORING_MODEL` | `claude-haiku-4-5`                     | Model for Fitch factor scoring            |
| `REGULATORY_TEXT_CAP` | `60000`                                | Max characters fed to regulatory checker  |
| `GROUND_TRUTH_PATH`   | `~/Downloads/sample_ground_truth.xlsx` | Path to validation spreadsheet (optional) |


---

## Troubleshooting

**App won't start**

```
ModuleNotFoundError: No module named 'anthropic'
```

→ Run `pip install -r requirements.txt` inside your activated virtual environment.

---

**"API key not found" or blank results**
→ Check that your `.env` file exists in the project root and contains:

```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Make sure there are no spaces around the `=` sign.

---

**Globe animation not showing**
→ The globe requires JavaScript. Make sure you are running the app locally at `localhost:8501`, not through a corporate proxy or iframe embed that blocks scripts.

---

**Stock prices show "N/A"**
→ `yfinance` occasionally throttles requests. Wait 60 seconds and refresh — prices are cached for 60 seconds.

---

**PDF produces empty results**
→ Some PDFs are scanned images (not text-searchable). The extractor requires text-layer PDFs. Try a version downloaded directly from the company's investor relations website.

---

**Windows: `streamlit` not recognized**
→ Either the virtual environment is not activated, or Python's Scripts folder is not on PATH.
Run: `where python` — if it shows the venv path, try `python -m streamlit run app.py`.