"""
chatbot.py — AI document & company Q&A
Streams responses from Anthropic Claude using all available context:
  - Extracted segment data
  - ESG scores
  - Recent news summary
  - PDF text excerpts
"""
from __future__ import annotations

from typing import Generator

from config import ANTHROPIC_API_KEY, COMPLEX_MODEL


# ── System prompt builder ─────────────────────────────────────────────────────

def build_system_prompt(
    company_name: str = "",
    segments: list[dict] | None = None,
    esg: dict | None = None,
    news_summary: str = "",
    pdf_text_snippets: str = "",
    currency: str = "",
    unit: str = "",
    reporting_period: str = "",
) -> str:
    """
    Build the system prompt with all available context injected.
    """
    lines: list[str] = [
        "You are FinExtract AI — a senior financial analyst at Fitch Ratings with 20+ years "
        "of experience in ESG assessment, credit risk, structured finance, and global capital markets.",
        "",
        "## Operating Instructions",
        "- Always provide THOROUGH, DETAILED, ANALYST-GRADE responses. Never truncate analysis.",
        "- Structure every response with clear headers, bullet points, and numbered lists where appropriate.",
        "- Lead with the most material finding, then drill down into supporting evidence.",
        "- Cite specific numbers from the extracted data (revenues, ESG scores, Fitch factors, etc.).",
        "- When data is missing, explicitly state what gap exists and why it matters to ratings.",
        "- Apply Fitch ESG Relevance Score (ERS) framework: score 1-5 per factor with rationale.",
        "- Always include a 'Bottom Line / Analyst View' section summarising the key takeaway.",
        "- For sector/peer comparisons, draw on your expertise and the provided news context.",
        "- Use markdown: **bold** for key metrics, `code` for tickers, > blockquote for direct quotes.",
        "- Minimum response length for analytical questions: 300 words. Do not give one-line answers.",
        "",
    ]

    if company_name:
        lines += [f"# Company Under Analysis: {company_name}", ""]

    # ── Segment data ──
    if segments:
        non_totals = [s for s in segments if not s.get("is_total")]
        totals = [s for s in segments if s.get("is_total")]
        ccy = f" {currency}" if currency else ""
        u = f" {unit}" if unit else ""
        period = f" (period ending {reporting_period})" if reporting_period else ""

        lines.append(f"## Extracted Segment Revenue{ccy}{u}{period}")
        for s in non_totals[:20]:
            lines.append(f"- **{s.get('segment')}**: {s.get('value', 0):,.0f} ({s.get('value_label', 'Revenue')})")
        for t in totals[:3]:
            lines.append(f"- **{t.get('segment')} [TOTAL]**: {t.get('value', 0):,.0f}")
        lines.append("")

    # ── ESG scores ──
    if esg:
        rating = esg.get("rating", "—")
        comp = esg.get("composite", 0)
        e, s, g = esg.get("e_score", 0), esg.get("s_score", 0), esg.get("g_score", 0)
        lines += [
            "## ESG Analysis (extracted from annual report)",
            f"- **Fitch-style rating**: {rating} | Composite: {comp:.0f}/100",
            f"- Environmental: {e:.0f}/100 | Social: {s:.0f}/100 | Governance: {g:.0f}/100",
            f"- Scope 1 disclosed: {'✓' if esg.get('has_scope1') else '✗'} | "
            f"Scope 2: {'✓' if esg.get('has_scope2') else '✗'} | "
            f"Scope 3: {'✓' if esg.get('has_scope3') else '✗'}",
            f"- Third-party assurance: {'✓' if esg.get('has_third_party_assurance') else '✗'} | "
            f"Net-zero target: {'✓' if esg.get('has_net_zero_target') else '✗'}",
        ]
        gw = esg.get("greenwashing_penalty", 0)
        if gw > 0:
            lines.append(f"- ⚠️ **Greenwashing risk**: -{gw:.0f} pts | Flags: {esg.get('greenwashing_flags', '')}")
        vague = esg.get("vague_phrase_count", 0)
        if vague:
            lines.append(f"- Vague ESG language detected: {int(vague)} phrases")
        lines.append("")

    # ── News context ──
    if news_summary:
        lines += ["## Recent News & Market Context (live web intelligence)", news_summary, ""]

    # ── PDF excerpts ──
    if pdf_text_snippets:
        lines += [
            "## Document Excerpts (from annual report)",
            pdf_text_snippets[:3000],
            "",
        ]

    # ── Instructions ──
    lines += [
        "## Analytical Framework",
        "- **Financial Analysis**: Segment concentration, growth drivers, margin trends, working capital",
        "- **ESG Materiality**: Use Fitch ERS framework — rate each E, S, G factor 1-5 with evidence",
        "- **Credit Relevance**: Connect ESG/financial findings to rating implications (upgrade/downgrade triggers)",
        "- **Regulatory Risk**: Flag CSRD, TCFD, EU Taxonomy, SEC climate disclosure gaps",
        "- **Greenwashing Radar**: Identify vague pledges, missing baselines, unverified claims",
        "- **Peer Context**: Compare where possible using sector benchmarks and training knowledge",
        "- **Data Gaps**: Be explicit — 'Scope 3 not disclosed = negative ESG signal per Fitch methodology'",
        "- **Forward View**: Incorporate net-zero targets, capex guidance, transition plans into outlook",
        "",
        "When writing summaries or reports, follow this structure:",
        "1. Executive Overview (2-3 sentences)",
        "2. Financial Profile",
        "3. ESG Assessment with factor-by-factor breakdown",
        "4. Key Risks & Credit Considerations",
        "5. Data Gaps & Limitations",
        "6. Analyst View / Rating Outlook",
    ]

    return "\n".join(lines)


# ── Streaming chat ────────────────────────────────────────────────────────────

def stream_chat_response(
    message: str,
    history: list[dict],
    system_prompt: str,
) -> Generator[str, None, None]:
    """
    Stream a chat completion from Anthropic Claude.
    history: list of {role: 'user'|'assistant', content: str}
    Yields text chunks as they arrive.
    """
    if not ANTHROPIC_API_KEY:
        yield "⚠️ No API key found. Please add ANTHROPIC_API_KEY to your .env file."
        return

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    messages = list(history) + [{"role": "user", "content": message}]

    try:
        with client.messages.stream(
            model=COMPLEX_MODEL,
            max_tokens=4096,
            system=system_prompt,
            messages=messages,
        ) as stream:
            for text in stream.text_stream:
                yield text
    except Exception as e:
        yield f"\n\n⚠️ Chat error: {e}"


# ── Suggested starter questions ───────────────────────────────────────────────

def get_suggested_questions(
    company_name: str,
    has_segments: bool,
    has_esg: bool,
    has_news: bool,
    segments: list[dict] | None = None,
    esg: dict | None = None,
    fitch_factors: list[dict] | None = None,
    reg: dict | None = None,
) -> list[str]:
    """Return highly specific, data-driven starter questions based on actual loaded context."""
    name = company_name or "this company"
    questions: list[str] = []

    # ── Segment-specific questions ─────────────────────────────────────────────
    if has_segments and segments:
        non_totals = [s for s in segments if not s.get("is_total")]
        if non_totals:
            top = max(non_totals, key=lambda s: s.get("value", 0) or 0)
            top_name = top.get("segment", "the largest segment")
            questions.append(
                f"**{top_name}** is {name}'s largest segment — what are the key growth drivers "
                f"and concentration risks for this business?"
            )
        if len(non_totals) >= 3:
            questions.append(
                f"Rank {name}'s {len(non_totals)} revenue segments by strategic importance "
                f"and assign a Fitch-style outlook (Positive/Stable/Negative) to each."
            )

    # ── ESG-specific questions ─────────────────────────────────────────────────
    if has_esg and esg:
        rating = esg.get("rating", "")
        composite = esg.get("composite", 0)
        has_scope3 = esg.get("has_scope3", False)
        has_assurance = esg.get("has_third_party_assurance", False)
        gw_penalty = esg.get("greenwashing_penalty", 0)

        questions.append(
            f"{name} received a **{rating}** ESG rating ({composite:.0f}/100). "
            f"Write a detailed factor-by-factor breakdown and identify the top 3 improvement levers."
        )
        if not has_scope3:
            questions.append(
                f"{name} has not disclosed Scope 3 emissions. Quantify the credit rating impact "
                f"and what a Fitch analyst would require to remove this negative flag."
            )
        if not has_assurance:
            questions.append(
                f"{name} lacks third-party ESG assurance. How does this affect investor confidence "
                f"and what's the standard for investment-grade issuers in this sector?"
            )
        if gw_penalty > 5:
            questions.append(
                f"{name} triggered {gw_penalty:.0f} greenwashing penalty points. "
                f"Identify the specific language flags and assess litigation/reputational risk."
            )

    # ── Fitch factor–specific questions ───────────────────────────────────────
    if fitch_factors:
        weak = [f for f in fitch_factors if f.get("score", 5) <= 2]
        strong = [f for f in fitch_factors if f.get("score", 0) >= 4]
        if weak:
            weak_names = ", ".join(f["name"] for f in weak[:2])
            questions.append(
                f"{name} scored poorly on **{weak_names}**. What would best-practice "
                f"disclosure look like and how much could scores improve with full compliance?"
            )
        if strong:
            strong_name = strong[0]["name"]
            questions.append(
                f"{name} scores well on **{strong_name}** — is this a genuine competitive "
                f"advantage or standard practice for the sector?"
            )

    # ── Regulatory questions ────────────────────────────────────────────────────
    if reg:
        csrd_pct = reg.get("csrd", {}).get("overall_pct", 0)
        tcfd_pct = reg.get("tcfd", {}).get("overall_pct", 0)
        if csrd_pct < 60:
            questions.append(
                f"{name} is only {csrd_pct:.0f}% aligned with CSRD/ESRS. "
                f"What are the highest-priority gaps and what's the regulatory timeline risk?"
            )
        if tcfd_pct < 70:
            questions.append(
                f"With {tcfd_pct:.0f}% TCFD alignment, what climate-related financial disclosures "
                f"is {name} missing and how will institutional investors respond?"
            )

    # ── News / market questions ────────────────────────────────────────────────
    if has_news:
        questions.append(
            f"Summarise the most important recent news for **{name}** and assess the credit implications."
        )

    # ── Always-available deep-dive questions ──────────────────────────────────
    questions += [
        f"Write a full Fitch-style analyst research note for **{name}** including rating rationale, "
        f"key risks, and a 12-month outlook.",
        f"What are the top 5 ESG risks that could trigger a rating downgrade for {name}, "
        f"ranked by probability and magnitude?",
    ]

    # Return the 6 most context-specific questions first
    return questions[:6]
