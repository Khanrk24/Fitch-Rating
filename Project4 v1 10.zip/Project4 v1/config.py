import os
import sys
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(override=True)

BASE_DIR = Path(__file__).parent
PDF_DIR = BASE_DIR
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# Cross-platform ground truth path — works on Windows and Mac
# Override by setting GROUND_TRUTH_PATH in your .env file
_default_gt = Path.home() / "Downloads" / "sample_ground_truth.xlsx"
GROUND_TRUTH_PATH = Path(os.getenv("GROUND_TRUTH_PATH", str(_default_gt)))

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# Model selection — all Claude via Anthropic
EXTRACTION_MODEL = os.getenv("EXTRACTION_MODEL", "claude-haiku-4-5")
COMPLEX_MODEL    = os.getenv("COMPLEX_MODEL",    "claude-sonnet-4-6")

# Segment page detection thresholds
MIN_INCLUDE_HITS = 1
MAX_EXCLUDE_PENALTY = 2   # allow up to 2 geo hits if segment hits are strong

# Extraction accuracy target
TARGET_ACCURACY = 0.90

# ESG greenwashing flag thresholds
GREENWASHING_VAGUE_THRESHOLD = 3   # vague phrases before flagging
GREENWASHING_MISSING_SCOPE3_PENALTY = 10  # ESG score penalty

# Output files
EXTRACTED_CSV = OUTPUT_DIR / "extracted_segments.csv"
VALIDATION_CSV = OUTPUT_DIR / "validation_results.csv"
ESG_CSV = OUTPUT_DIR / "esg_scores.csv"
NACE_CSV = OUTPUT_DIR / "nace_tags.csv"
FITCH_FACTORS_CSV = OUTPUT_DIR / "fitch_factors.csv"
FORWARD_LOOKING_CSV = OUTPUT_DIR / "forward_looking.csv"
REGULATORY_GAPS_CSV = OUTPUT_DIR / "regulatory_gaps.csv"

# Deep analysis models
FITCH_SCORING_MODEL = os.getenv("FITCH_SCORING_MODEL", "claude-haiku-4-5")
REGULATORY_TEXT_CAP = int(os.getenv("REGULATORY_TEXT_CAP", "60000"))

# NACE Rev 2.1 — top-level sections used for tagging
NACE_SECTIONS = {
    "A": "Agriculture, forestry and fishing",
    "B": "Mining and quarrying",
    "C": "Manufacturing",
    "D": "Electricity, gas, steam and air conditioning supply",
    "E": "Water supply; sewerage, waste management",
    "F": "Construction",
    "G": "Wholesale and retail trade",
    "H": "Transportation and storage",
    "I": "Accommodation and food service activities",
    "J": "Information and communication",
    "K": "Financial and insurance activities",
    "L": "Real estate activities",
    "M": "Professional, scientific and technical activities",
    "N": "Administrative and support service activities",
    "O": "Public administration and defence",
    "P": "Education",
    "Q": "Human health and social work activities",
    "R": "Arts, entertainment and recreation",
    "S": "Other service activities",
    "T": "Activities of households",
    "U": "Activities of extraterritorial organisations",
}
