"""
company_search.py — Live web intelligence module
- Finds the latest annual report / 10-K PDF for any company via DuckDuckGo
- Suggests peer/comparable companies for Fitch-style analysis
- Fetches and summarises recent news (financial + ESG)
- Attempts direct PDF download when URL is known
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Optional

import requests

from config import ANTHROPIC_API_KEY, COMPLEX_MODEL


# ── DuckDuckGo helpers ────────────────────────────────────────────────────────

def _ddg_text(query: str, max_results: int = 10) -> list[dict]:
    """DuckDuckGo text search. Returns list of {title, href, body}."""
    try:
        from ddgs import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        return results
    except Exception:
        return []


def _ddg_news(query: str, max_results: int = 10) -> list[dict]:
    """DuckDuckGo news search. Returns list of {title, url, date, body, source}."""
    try:
        from ddgs import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.news(query, max_results=max_results))
        return results
    except Exception:
        return []


# ── Annual report finder ──────────────────────────────────────────────────────

def search_annual_report(company_name: str) -> dict:
    """
    Find the latest annual report / 10-K / 20-F for a company.
    Returns dict with url, filing_type, year, confidence, and raw search results.
    """
    queries = [
        f'"{company_name}" annual report 2024 OR 2025 filetype:pdf',
        f'"{company_name}" annual report 2025 investor relations PDF',
        f'"{company_name}" 10-K 2024 OR 2025 SEC filing',
        f'{company_name} investor relations annual report download',
    ]

    all_results = []
    for q in queries[:2]:          # cap at 2 searches to avoid DDG rate-limits
        results = _ddg_text(q, max_results=8)
        all_results.extend(results)
        time.sleep(0.3)

    if not all_results:
        return {
            "error": "No search results found. Try a more specific company name.",
            "company_name": company_name,
            "url": "",
        }

    results_text = "\n".join([
        f"{i+1}. [{r.get('title', '')}] {r.get('href', '')} — {r.get('body', '')[:200]}"
        for i, r in enumerate(all_results[:15])
    ])

    if not ANTHROPIC_API_KEY:
        first = all_results[0]
        return {
            "company_name": company_name,
            "url": first.get("href", ""),
            "title": first.get("title", ""),
            "filing_type": "Annual Report",
            "year": 2024,
            "is_direct_pdf": first.get("href", "").lower().endswith(".pdf"),
            "confidence": 0.3,
            "notes": "No API key — returning first search result",
            "search_results": all_results[:5],
        }

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    prompt = f"""You are a financial research assistant. Given these search results for "{company_name}" annual report, identify the single best link to their MOST RECENT annual report or 10-K/20-F filing.

Prefer:
1. Direct PDF links (url ending in .pdf)
2. Official investor relations pages
3. SEC EDGAR filings (sec.gov)
4. Most recent year available

Search results:
{results_text}

Return ONLY valid JSON, no commentary:
{{
  "company_name": "<official company name as it appears in results>",
  "url": "<best URL — direct PDF preferred>",
  "filing_type": "<Annual Report|10-K|20-F|Integrated Report|Financial Statements>",
  "year": <most recent year as integer, e.g. 2024>,
  "is_direct_pdf": <true if URL ends in .pdf>,
  "confidence": <0.0-1.0 — how confident you are this is the right filing>,
  "notes": "<one sentence about the source>"
}}

If no suitable result exists, set url to "" and confidence to 0."""

    try:
        response = client.messages.create(
            model=COMPLEX_MODEL,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = response.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)
        result = json.loads(raw)
        result["search_results"] = all_results[:5]
        return result
    except Exception as e:
        return {
            "company_name": company_name,
            "url": all_results[0].get("href", "") if all_results else "",
            "title": all_results[0].get("title", "") if all_results else "",
            "filing_type": "Annual Report",
            "year": 2024,
            "is_direct_pdf": False,
            "confidence": 0.25,
            "notes": f"API parse error — returning top search result",
            "search_results": all_results[:5],
        }


# ── Peer company suggestions ──────────────────────────────────────────────────

def suggest_peer_companies(company_name: str, industry_hint: str = "") -> list[dict]:
    """
    Suggest 6 comparable peer companies a Fitch analyst would benchmark against.
    Returns list of {name, reason, region, ticker}.
    """
    if not ANTHROPIC_API_KEY:
        return []

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    context = f" ({industry_hint})" if industry_hint else ""

    prompt = f"""You are a senior Fitch credit analyst. For the company "{company_name}"{context}, suggest exactly 6 comparable peer companies for ESG benchmarking and credit analysis.

Choose peers that:
- Operate in the same or adjacent sector
- Are of broadly similar scale
- Would appear in the same Fitch peer comparison group
- Cover a mix of geographies where relevant

Return ONLY valid JSON — an array of 6 objects:
[
  {{
    "name": "<Official Company Name>",
    "ticker": "<stock ticker if known, else empty string>",
    "reason": "<one sentence — why they are comparable>",
    "region": "<Europe|North America|Asia Pacific|Global|Middle East>"
  }},
  ...
]"""

    try:
        response = client.messages.create(
            model=COMPLEX_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = response.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)
        return json.loads(raw)
    except Exception:
        return []


# ── News fetcher ──────────────────────────────────────────────────────────────

def fetch_company_news(company_name: str, num_results: int = 10) -> list[dict]:
    """
    Fetch recent news headlines about a company — financial + ESG angle.
    Returns deduplicated list of news items.
    """
    queries = [
        f"{company_name} financial results revenue earnings 2025",
        f"{company_name} ESG sustainability environment 2025",
    ]
    news: list[dict] = []
    for q in queries:
        items = _ddg_news(q, max_results=num_results // 2 + 3)
        news.extend(items)
        time.sleep(0.3)

    # Deduplicate by title
    seen: set[str] = set()
    unique: list[dict] = []
    for item in news:
        title = item.get("title", "")
        if title and title not in seen:
            seen.add(title)
            unique.append(item)

    return unique[:num_results]


# ── Context summary ───────────────────────────────────────────────────────────

def summarize_company_context(
    company_name: str,
    news_items: list[dict],
    segments: list[dict] | None = None,
    esg: dict | None = None,
) -> str:
    """
    Use Claude to produce a Fitch-style analyst brief combining news + extracted data.
    Returns a markdown-formatted string suitable for display or use as chatbot context.
    """
    if not ANTHROPIC_API_KEY or not news_items:
        return ""

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    news_text = "\n".join([
        f"- [{item.get('date', 'recent')}] **{item.get('title', '')}** ({item.get('source', '')}): "
        f"{item.get('body', '')[:300]}"
        for item in news_items[:8]
    ])

    seg_text = ""
    if segments:
        non_totals = [s for s in segments if not s.get("is_total")]
        seg_text = "\nExtracted segment revenue data:\n" + "\n".join([
            f"- {s.get('segment')}: {s.get('value'):,.0f} ({s.get('value_label', 'Revenue')})"
            for s in non_totals[:10]
        ])

    esg_text = ""
    if esg:
        esg_text = (
            f"\nESG composite: {esg.get('composite', 0):.0f}/100 ({esg.get('rating', '—')}) | "
            f"E: {esg.get('e_score', 0):.0f} | S: {esg.get('s_score', 0):.0f} | "
            f"G: {esg.get('g_score', 0):.0f}\n"
            f"Scope 3 disclosed: {'Yes' if esg.get('has_scope3') else 'No'} | "
            f"Third-party assurance: {'Yes' if esg.get('has_third_party_assurance') else 'No'}"
        )
        if esg.get("greenwashing_penalty", 0) > 0:
            esg_text += f"\n⚠️ Greenwashing risk: -{esg.get('greenwashing_penalty', 0):.0f} pts"

    prompt = f"""You are a senior Fitch analyst. Based on the following data, write a concise analyst brief for {company_name} with three sections:

**1. Business Performance & Strategy** — recent results, segment trends, strategic direction
**2. ESG Profile & Disclosure Quality** — environmental commitments, social factors, governance, greenwashing concerns, Fitch ESG Relevance Score implications
**3. Credit-Relevant Factors** — key risks, liquidity signals, sector outlook, peer comparison context

Recent news:
{news_text}
{seg_text}
{esg_text}

Write in Fitch analyst style: factual, concise, use specific figures. Use markdown headers and bullet points. Flag any data gaps."""

    try:
        response = client.messages.create(
            model=COMPLEX_MODEL,
            max_tokens=1200,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text.strip()
    except Exception as e:
        return f"Could not generate summary: {e}"


# ── Regulatory gap online enrichment ─────────────────────────────────────────

def search_regulatory_context(company_name: str, framework: str, missing_topics: list[str]) -> list[dict]:
    """
    For a list of regulatory topics not found in the PDF, search online for
    company-specific disclosures.

    Returns list of {topic, title, url, snippet, date} items (one per found topic).
    """
    results: list[dict] = []
    if not company_name or not missing_topics:
        return results

    # Batch topics into a single search to avoid DDG rate limits
    topic_str = ", ".join(missing_topics[:4])
    queries = [
        f'"{company_name}" {framework} disclosure {topic_str} 2024 OR 2025',
        f'"{company_name}" sustainability report {framework} {missing_topics[0] if missing_topics else ""}',
    ]

    all_hits: list[dict] = []
    for q in queries[:2]:
        hits = _ddg_text(q, max_results=6)
        all_hits.extend(hits)
        time.sleep(0.3)

    seen_urls: set[str] = set()
    for hit in all_hits:
        url = hit.get("href", "")
        if url in seen_urls:
            continue
        seen_urls.add(url)
        results.append({
            "topic": topic_str[:80],
            "title": hit.get("title", "")[:120],
            "url": url,
            "snippet": hit.get("body", "")[:300],
            "date": "",
        })

    return results[:6]


def summarize_regulatory_gaps_online(
    company_name: str,
    framework: str,
    missing_requirements: list[dict],
    online_hits: list[dict],
) -> str:
    """
    Use Claude to interpret online search results and identify which missing
    regulatory requirements have evidence online, and what the evidence says.

    Returns a markdown-formatted summary with per-requirement findings.
    """
    if not ANTHROPIC_API_KEY or not online_hits:
        return ""

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    reqs_text = "\n".join([
        f"- {r.get('id', r.get('requirement_id', ''))}: {r.get('requirement', r.get('topic', ''))[:150]}"
        for r in missing_requirements[:10]
    ])
    hits_text = "\n".join([
        f"{i+1}. [{h.get('title', '')}] ({h.get('url', '')})\n   {h.get('snippet', '')[:250]}"
        for i, h in enumerate(online_hits[:6])
    ])

    prompt = f"""You are a senior ESG analyst. For {company_name}, the following {framework} requirements were NOT FOUND in their uploaded PDF filing.

MISSING REQUIREMENTS:
{reqs_text}

ONLINE SEARCH RESULTS (publicly available):
{hits_text}

For each missing requirement, determine if any of the online sources provide relevant evidence. Write a concise analyst note:
- Only mention requirements where you found actual evidence online
- Quote or paraphrase the specific data found
- Note the source URL
- Be conservative: only report what is explicitly stated in the snippets

Format as markdown bullet points. If no evidence found for any requirement, say so clearly."""

    try:
        response = client.messages.create(
            model=COMPLEX_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text.strip()
    except Exception:
        return ""


# ── PDF downloader ────────────────────────────────────────────────────────────

def try_download_pdf(url: str, dest_dir: Path, filename: str | None = None) -> Optional[Path]:
    """
    Attempt to download a PDF from a direct URL.
    Returns Path on success, None if URL is not a direct PDF or download fails.
    """
    if not url:
        return None

    url_lower = url.lower().split("?")[0]
    if not url_lower.endswith(".pdf"):
        return None

    try:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "application/pdf,*/*",
        }
        resp = requests.get(url, headers=headers, timeout=30, stream=True)
        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "").lower()
        if "pdf" not in content_type and "octet-stream" not in content_type:
            return None

        if filename is None:
            filename = url.split("/")[-1].split("?")[0] or "downloaded_report.pdf"
            if not filename.lower().endswith(".pdf"):
                filename += ".pdf"

        dest = dest_dir / filename
        with open(dest, "wb") as f:
            downloaded = 0
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
                downloaded += len(chunk)
                if downloaded > 100 * 1024 * 1024:   # 100MB cap
                    break

        if dest.stat().st_size < 50_000:               # < 50KB → probably not a real PDF
            dest.unlink()
            return None

        return dest
    except Exception:
        return None
