"""
app.py — Financial PDF Extraction UI
Upload PDFs → AI extracts segment data → ESG scores → NACE tags → review & export
Now includes: Company Search, AI Chatbot, Live News Context
"""
from __future__ import annotations

import base64
import json
import re as _re
import tempfile
import shutil
from pathlib import Path

import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

from config import (
    PDF_DIR, OUTPUT_DIR, EXTRACTED_CSV, ESG_CSV, VALIDATION_CSV,
    FITCH_FACTORS_CSV, FORWARD_LOOKING_CSV, REGULATORY_GAPS_CSV,
    GROUND_TRUTH_PATH, NACE_SECTIONS,
)
from table_extractor import extract_text_from_page

# ── Page config & custom CSS ──────────────────────────────────────────────────

st.set_page_config(page_title="FinExtract — Fitch Ratings Analytics", page_icon="📊", layout="wide", initial_sidebar_state="expanded")

# ── Globe intro splash (plays on every fresh load / refresh) ──────────────────
# session_state resets on browser refresh, so this naturally re-plays each time.
# We inject a full-screen iframe into window.parent.document (same-origin on
# localhost) so position:fixed covers the real viewport, not a shadow DOM slot.
if not st.session_state.get("_intro_done"):
    st.session_state["_intro_done"] = True

    # ── The standalone globe HTML (base64-encoded → data URL for the iframe) ──
    _GLOBE_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Cormorant+Garamond:wght@400;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
html,body{width:100%;height:100%;background:#0c0e14;overflow:hidden;}
#_gi{position:fixed;inset:0;background:#0c0e14;
  display:flex;align-items:center;justify-content:center;
  font-family:'DM Sans',system-ui,sans-serif;
  transition:opacity 1.6s ease;overflow:hidden;}
#_gi.fade-out{opacity:0;pointer-events:none;}
#_gi_scene{position:relative;display:flex;flex-direction:column;align-items:center;z-index:1;}
#_gi_wrap{position:relative;width:400px;height:400px;}
#_gi canvas{display:block;}
#_gi_globecanvas{border-radius:50%;}
#_gi_glow{position:absolute;inset:-60px;border-radius:50%;
  background:radial-gradient(circle,rgba(100,160,220,0.06) 0%,rgba(100,160,220,0.02) 40%,transparent 70%);
  pointer-events:none;animation:_gi_pulse 6s ease-in-out infinite alternate;}
@keyframes _gi_pulse{0%{opacity:.7;transform:scale(1)}100%{opacity:1;transform:scale(1.04)}}
.gi_ring{position:absolute;border-radius:50%;border:1px solid rgba(255,255,255,0.04);pointer-events:none;}
#_gi_r1{inset:-30px;animation:_gi_rot 14s linear infinite;}
#_gi_r2{inset:-50px;animation:_gi_rot 22s linear infinite reverse;border-color:rgba(255,255,255,0.025);}
#_gi_r3{inset:-18px;animation:_gi_rot 9s linear infinite;border-color:rgba(255,255,255,0.03);}
@keyframes _gi_rot{to{transform:rotate(360deg)}}
.gi_ring::before,.gi_ring::after{content:'';position:absolute;width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,0.12);}
#_gi_r1::before{top:12%;left:4%;}#_gi_r1::after{bottom:20%;right:2%;}
#_gi_r2::before{top:6%;right:18%;}#_gi_r2::after{bottom:8%;left:14%;}
#_gi_r3::before{top:50%;left:-1px;}#_gi_r3::after{bottom:10%;right:8%;}
#_gi_brand{margin-top:48px;text-align:center;white-space:nowrap;}
#_gi_bf,#_gi_br{font-family:'Cormorant Garamond',Georgia,serif;font-size:38px;
  opacity:0;transition:opacity 1.2s ease;display:inline;}
#_gi_bf{font-weight:700;color:#d4a853;}
#_gi_br{font-weight:400;color:rgba(255,255,255,0.7);margin-left:6px;}
#_gi_bs{display:block;font-size:11px;letter-spacing:3.5px;text-transform:uppercase;
  color:rgba(255,255,255,0.28);margin-top:14px;opacity:0;transition:opacity 1.2s ease;
  font-family:'DM Sans',system-ui,sans-serif;font-weight:500;}
#_gi_skip{display:none;}
</style>
</head>
<body>

<div id="_gi">
  <canvas id="_gi_stars" style="position:absolute;inset:0;pointer-events:none;width:100%;height:100%;"></canvas>
  <div id="_gi_scene">
    <div id="_gi_wrap">
      <div id="_gi_glow"></div>
      <div class="gi_ring" id="_gi_r1"></div>
      <div class="gi_ring" id="_gi_r2"></div>
      <div class="gi_ring" id="_gi_r3"></div>
      <canvas id="_gi_globecanvas" width="400" height="400"></canvas>
    </div>
    <div id="_gi_brand">
      <span id="_gi_bf">Fitch</span><span id="_gi_br">Ratings</span>
      <span id="_gi_bs">Global Credit Rating Analytics &nbsp;·&nbsp; 11 Offices Worldwide</span>
    </div>
  </div>
</div>

<script>
(function(){
/* ─── STARFIELD ─────────────────────────────────────────── */
const sc=document.getElementById('_gi_stars');
const sx=sc.getContext('2d');
function resizeStar(){sc.width=innerWidth;sc.height=innerHeight;drawStar();}
function drawStar(){
  sx.clearRect(0,0,sc.width,sc.height);
  for(let i=0;i<120;i++){
    const x=Math.random()*sc.width,y=Math.random()*sc.height;
    const r=Math.random()*1.2+0.2,a=Math.random()*0.25+0.03;
    sx.beginPath();sx.arc(x,y,r,0,Math.PI*2);
    sx.fillStyle=`rgba(255,255,255,${a})`;sx.fill();
  }
}
window.addEventListener('resize',resizeStar);resizeStar();

/* ─── GLOBE ─────────────────────────────────────────────── */
const canvas=document.getElementById('_gi_globecanvas');
const gc=canvas.getContext('2d');
const CX=200,CY=200,R=176;
let rot=0,raf,zoomFired=false;
const T0=performance.now();

const LAND=[
  [[-124,49],[-117,49],[-110,49],[-100,49],[-97,49],[-90,47],[-83,46],[-76,45],[-71,45],[-67,47],[-70,43],[-70,41],[-74,40],[-75,38],[-76,35],[-77,34],[-80,32],[-81,30],[-82,29],[-85,30],[-87,30],[-89,29],[-90,29],[-93,30],[-94,30],[-97,26],[-97,28],[-100,28],[-104,29],[-106,32],[-109,31],[-111,31],[-114,32],[-117,32],[-118,34],[-120,35],[-122,37],[-124,38],[-124,41],[-124,44],[-124,47],[-124,49]],
  [[-141,60],[-141,68],[-156,72],[-163,63],[-168,60],[-166,54],[-160,55],[-153,57],[-149,60],[-145,60],[-141,60]],
  [[-140,60],[-110,60],[-90,57],[-80,57],[-75,56],[-65,47],[-64,45],[-67,47],[-71,45],[-76,45],[-83,46],[-90,47],[-97,49],[-110,49],[-117,49],[-124,49],[-130,55],[-137,59],[-140,60]],
  [[-73,83],[-55,82],[-22,76],[-18,70],[-25,65],[-45,60],[-53,66],[-65,67],[-70,75],[-73,83]],
  [[-97,26],[-90,21],[-89,18],[-85,10],[-78,8],[-77,8],[-82,10],[-84,20],[-87,21],[-90,22],[-92,19],[-95,22],[-97,26]],
  [[-79,8],[-65,11],[-63,10],[-52,4],[-50,2],[-36,-6],[-35,-10],[-38,-15],[-40,-22],[-44,-23],[-48,-28],[-52,-34],[-58,-38],[-62,-45],[-65,-55],[-68,-55],[-75,-50],[-72,-42],[-72,-35],[-72,-28],[-70,-20],[-75,-14],[-80,-4],[-79,8]],
  [[-5,50],[2,51],[0,52],[0,53],[-3,54],[-5,58],[-2,58],[-3,56],[-4,54],[-3,53],[-5,50]],
  [[-10,52],[-6,52],[-6,55],[-8,55],[-10,54],[-10,52]],
  [[5,58],[8,58],[10,57],[14,56],[18,57],[20,60],[26,65],[28,71],[30,70],[28,65],[24,64],[20,63],[16,62],[14,58],[10,57],[5,58]],
  [[-24,63],[-14,63],[-13,65],[-18,66],[-24,65],[-24,63]],
  [[-9,38],[-9,44],[-3,44],[0,47],[-2,46],[-5,44],[-1,44],[3,45],[7,44],[8,46],[8,45],[13,44],[14,41],[16,38],[12,37],[14,38],[15,37],[12,37],[14,37],[15,38],[16,38],[14,41],[13,44],[8,46],[8,45],[7,44],[3,45],[0,47],[-2,46],[-5,44],[-1,44],[0,44],[3,42],[3,40],[1,39],[-1,39],[-2,37],[-5,36],[-9,37],[-9,38]],
  [[-9,44],[-9,38],[-5,36],[-2,37],[0,39],[3,40],[3,42],[0,44],[-9,44]],
  [[6,47],[8,48],[14,50],[18,50],[24,54],[20,54],[14,54],[10,54],[8,54],[6,52],[8,50],[8,48],[6,48],[6,47]],
  [[14,46],[18,47],[22,44],[26,42],[28,42],[30,42],[28,40],[26,38],[22,38],[20,40],[18,40],[14,44],[14,46]],
  [[22,60],[26,60],[28,62],[30,65],[28,68],[24,68],[20,65],[22,63],[22,60]],
  [[26,70],[36,70],[40,68],[50,66],[60,64],[56,58],[50,52],[44,46],[38,44],[32,46],[28,56],[22,60],[26,65],[28,71],[26,70]],
  [[60,64],[80,68],[100,72],[120,72],[140,70],[160,62],[168,60],[160,54],[150,48],[142,46],[138,46],[134,44],[130,42],[130,48],[126,50],[120,48],[110,44],[100,50],[90,56],[80,60],[70,62],[60,64]],
  [[-18,15],[-17,14],[-15,12],[-14,10],[-10,8],[-8,5],[-4,4],[0,5],[4,4],[8,4],[10,4],[14,4],[16,1],[18,1],[22,1],[30,0],[34,-2],[36,-2],[40,4],[42,10],[44,12],[44,18],[40,20],[36,22],[34,28],[32,32],[26,32],[30,30],[26,24],[22,22],[16,20],[14,12],[10,10],[8,4],[2,5],[0,5],[-4,4],[-8,5],[-14,10],[-18,15]],
  [[16,-34],[20,-36],[26,-34],[32,-30],[34,-22],[34,-28],[26,-24],[20,-30],[16,-34]],
  [[44,-14],[48,-16],[50,-20],[50,-25],[44,-26],[44,-20],[44,-14]],
  [[36,30],[42,30],[46,24],[50,24],[56,22],[58,20],[52,14],[44,12],[42,14],[40,16],[36,20],[36,30]],
  [[26,42],[30,42],[36,38],[40,38],[40,36],[36,36],[32,36],[28,38],[26,40],[26,42]],
  [[44,38],[48,38],[54,38],[60,34],[60,26],[56,24],[50,24],[46,24],[42,30],[42,36],[44,38]],
  [[60,24],[72,24],[80,24],[86,26],[92,24],[92,20],[88,20],[82,14],[80,10],[76,8],[72,8],[68,22],[60,22],[60,24]],
  [[80,10],[80,8],[82,6],[82,8],[80,10]],
  [[92,26],[96,28],[100,20],[100,6],[104,4],[108,2],[110,2],[110,10],[108,12],[104,14],[100,16],[98,18],[96,20],[92,22],[92,26]],
  [[78,36],[86,34],[92,32],[96,28],[100,20],[104,20],[108,20],[110,20],[116,22],[120,24],[122,30],[120,36],[116,40],[112,42],[108,42],[104,40],[100,36],[94,34],[88,34],[80,34],[78,36]],
  [[120,40],[124,40],[128,36],[126,34],[124,34],[122,36],[120,38],[120,40]],
  [[130,32],[134,34],[136,34],[140,38],[142,42],[140,44],[136,44],[132,44],[130,40],[130,38],[130,34],[130,32]],
  [[140,42],[144,44],[144,46],[142,44],[140,44],[140,42]],
  [[120,22],[122,24],[122,22],[120,22]],
  [[118,18],[122,18],[122,12],[118,10],[116,10],[116,14],[118,18]],
  [[108,2],[110,2],[114,2],[116,2],[118,2],[116,6],[114,6],[110,4],[108,2]],
  [[114,-22],[120,-24],[126,-24],[130,-16],[136,-14],[138,-16],[136,-16],[136,-12],[140,-12],[142,-10],[148,-14],[154,-20],[156,-24],[152,-30],[150,-38],[144,-38],[140,-36],[134,-32],[130,-34],[116,-34],[114,-28],[114,-22]],
  [[172,-36],[178,-38],[178,-40],[174,-42],[172,-40],[172,-36]],
  [[168,-44],[172,-46],[172,-46],[170,-46],[168,-45],[168,-44]],
  [[-180,-70],[-90,-72],[0,-72],[90,-72],[180,-70],[180,-76],[-180,-76],[-180,-70]],
];

const OFFICES=[
  {lon:-0.12,lat:51.51,name:'London',hq:false},
  {lon:2.35,lat:48.85,name:'Paris',hq:false},
  {lon:8.68,lat:50.11,name:'Frankfurt',hq:false},
  {lon:139.69,lat:35.69,name:'Tokyo',hq:false},
  {lon:114.17,lat:22.32,name:'Hong Kong',hq:false},
  {lon:103.82,lat:1.35,name:'Singapore',hq:false},
  {lon:72.88,lat:19.08,name:'Mumbai',hq:false},
  {lon:55.30,lat:25.20,name:'Dubai',hq:false},
  {lon:151.21,lat:-33.87,name:'Sydney',hq:false},
  {lon:-74.01,lat:40.71,name:'New York',hq:false},
  {lon:-87.63,lat:41.88,name:'Chicago',hq:true},
];

function project(lon,lat,rotDeg){
  const λ=(lon+rotDeg)*Math.PI/180,φ=lat*Math.PI/180;
  const tilt=-22*Math.PI/180;
  const x3=Math.cos(φ)*Math.sin(λ),y3=Math.sin(φ),z3=Math.cos(φ)*Math.cos(λ);
  const y3t=y3*Math.cos(tilt)-z3*Math.sin(tilt),z3t=y3*Math.sin(tilt)+z3*Math.cos(tilt);
  if(z3t<0.0)return null;
  return[CX+R*x3,CY-R*y3t,z3t];
}
function drawPoly(pts){
  let started=false;gc.beginPath();
  for(const[lo,la]of pts){
    const p=project(lo,la,rot);
    if(!p){started=false;continue;}
    if(!started){gc.moveTo(p[0],p[1]);started=true;}else gc.lineTo(p[0],p[1]);
  }gc.closePath();
}
function drawGraticule(){
  for(let lo=-180;lo<=180;lo+=30){gc.beginPath();let f=true;for(let la=-90;la<=90;la+=3){const p=project(lo,la,rot);if(!p){f=true;continue;}if(f){gc.moveTo(p[0],p[1]);f=false;}else gc.lineTo(p[0],p[1]);}gc.stroke();}
  for(let la=-60;la<=60;la+=30){gc.beginPath();let f=true;for(let lo=-180;lo<=180;lo+=3){const p=project(lo,la,rot);if(!p){f=true;continue;}if(f){gc.moveTo(p[0],p[1]);f=false;}else gc.lineTo(p[0],p[1]);}gc.stroke();}
}
function drawWhirl(t){
  const rings=[{rx:192,ry:40,s:0.18},{rx:192,ry:72,s:-0.12},{rx:192,ry:22,s:0.30}];
  rings.forEach((r,i)=>{gc.save();gc.translate(CX,CY);gc.rotate(t*r.s+i*1.1);gc.beginPath();gc.ellipse(0,0,r.rx,r.ry,0,0,Math.PI*2);gc.strokeStyle=`rgba(180,200,220,${0.04+i*0.015})`;gc.lineWidth=0.5;gc.setLineDash([2,10]);gc.stroke();gc.setLineDash([]);gc.restore();});
  for(let i=0;i<50;i++){const a=(i/50)*Math.PI*2+t*0.4;const px=CX+194*Math.cos(a),py=CY+194*Math.sin(a)*0.2,d=(Math.cos(a)+1)/2;gc.beginPath();gc.arc(px,py,0.6+d*1.2,0,Math.PI*2);gc.fillStyle=`rgba(212,168,83,${0.03+d*0.18})`;gc.fill();}
}

const TOUR=[
  {rot:3,   hold:1800,cities:['London','Paris','Frankfurt']},
  {rot:-55, hold:1200,cities:['Dubai']},
  {rot:-73, hold:1200,cities:['Mumbai']},
  {rot:-109,hold:1500,cities:['Singapore','Hong Kong']},
  {rot:-140,hold:1200,cities:['Tokyo']},
  {rot:-151,hold:1200,cities:['Sydney']},
  {rot:81,  hold:1800,cities:['New York','Chicago']},
];
const TRANSITION_MS=1200;
let tourTimeline=[],spotlightCities=[];
(function buildTimeline(){
  let t=500,prevRot=TOUR[0].rot;
  for(let i=0;i<TOUR.length;i++){
    const wp=TOUR[i],toRot=wp.rot,transDur=i===0?0:TRANSITION_MS;
    tourTimeline.push({startTime:t,transitionDur:transDur,holdDur:wp.hold,fromRot:prevRot,toRot,cities:wp.cities});
    t+=transDur+wp.hold;prevRot=toRot;
  }
})();
const TOUR_END=tourTimeline[tourTimeline.length-1].startTime+tourTimeline[tourTimeline.length-1].transitionDur+tourTimeline[tourTimeline.length-1].holdDur;
function easeInOut(t){return t<0.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;}
function getTourRot(elapsed){
  spotlightCities=[];
  for(let i=tourTimeline.length-1;i>=0;i--){
    const seg=tourTimeline[i];
    if(elapsed>=seg.startTime){
      const inTrans=elapsed-seg.startTime;
      if(inTrans<seg.transitionDur){return seg.fromRot+(seg.toRot-seg.fromRot)*easeInOut(inTrans/seg.transitionDur);}
      else{spotlightCities=seg.cities;return seg.toRot;}
    }
  }return TOUR[0].rot;
}
let zoomChi=false;
function drawOffices(elapsed){
  if(elapsed<400)return;
  const gf=Math.min(1,(elapsed-400)/1000);
  OFFICES.forEach(city=>{
    const p=project(city.lon,city.lat,rot);if(!p||p[2]<0.05)return;
    const depth=p[2],op=gf*(0.3+depth*0.7),pulse=(Math.sin(elapsed*0.004+city.lon*0.05)+1)/2;
    const isSpotlit=spotlightCities.includes(city.name);
    if(city.hq){
      gc.beginPath();gc.arc(p[0],p[1],(isSpotlit?18:14)+pulse*8,0,Math.PI*2);gc.strokeStyle=`rgba(212,168,83,${op*(isSpotlit?0.2:0.12)})`;gc.lineWidth=1;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],(isSpotlit?10:8)+pulse*4,0,Math.PI*2);gc.strokeStyle=`rgba(212,168,83,${op*(isSpotlit?0.45:0.3)})`;gc.lineWidth=1;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],isSpotlit?6:4.5,0,Math.PI*2);gc.fillStyle=`rgba(212,168,83,${op})`;gc.fill();
      const hg=gc.createRadialGradient(p[0],p[1],0,p[0],p[1],isSpotlit?28:20);hg.addColorStop(0,`rgba(212,168,83,${op*(isSpotlit?0.25:0.15)})`);hg.addColorStop(1,'rgba(212,168,83,0)');
      gc.beginPath();gc.arc(p[0],p[1],isSpotlit?28:20,0,Math.PI*2);gc.fillStyle=hg;gc.fill();
    }else{
      if(isSpotlit){gc.beginPath();gc.arc(p[0],p[1],10+pulse*6,0,Math.PI*2);gc.strokeStyle=`rgba(140,180,220,${op*0.2})`;gc.lineWidth=0.8;gc.stroke();}
      gc.beginPath();gc.arc(p[0],p[1],7+pulse*5,0,Math.PI*2);gc.strokeStyle=`rgba(140,180,220,${op*0.15})`;gc.lineWidth=0.6;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],isSpotlit?4:3,0,Math.PI*2);gc.fillStyle=`rgba(140,180,220,${op*(isSpotlit?1:0.9)})`;gc.fill();
      if(isSpotlit){const sg=gc.createRadialGradient(p[0],p[1],0,p[0],p[1],18);sg.addColorStop(0,`rgba(140,180,220,${op*0.12})`);sg.addColorStop(1,'rgba(140,180,220,0)');gc.beginPath();gc.arc(p[0],p[1],18,0,Math.PI*2);gc.fillStyle=sg;gc.fill();}
    }
    const showLabel=isSpotlit?(depth>0.15):(depth>0.4);
    if(showLabel&&elapsed>600){
      const lf=isSpotlit?Math.min(1,(depth-0.15)/0.2):Math.min(1,(depth-0.4)/0.3);
      if(lf>0.04){
        gc.save();
        const fontSize=isSpotlit?13:11;
        gc.font=`${city.hq?'700 ':'500 '}${fontSize}px "DM Sans",sans-serif`;
        const tw=gc.measureText(city.name).width,lx=p[0]+8>CX+R-tw-4?p[0]-tw-8:p[0]+8,ly=p[1],pad=5;
        gc.fillStyle=`rgba(12,14,20,${lf*(isSpotlit?0.92:0.85)})`;gc.strokeStyle=`rgba(255,255,255,${lf*(isSpotlit?0.1:0.06)})`;gc.lineWidth=0.5;
        gc.beginPath();const bx=lx-pad,by=ly-12,bw=tw+pad*2,bh=18,br=4;
        gc.moveTo(bx+br,by);gc.lineTo(bx+bw-br,by);gc.quadraticCurveTo(bx+bw,by,bx+bw,by+br);gc.lineTo(bx+bw,by+bh-br);gc.quadraticCurveTo(bx+bw,by+bh,bx+bw-br,by+bh);gc.lineTo(bx+br,by+bh);gc.quadraticCurveTo(bx,by+bh,bx,by+bh-br);gc.lineTo(bx,by+br);gc.quadraticCurveTo(bx,by,bx+br,by);
        gc.fill();gc.stroke();
        gc.fillStyle=city.hq?`rgba(212,168,83,${lf})`:isSpotlit?`rgba(220,230,240,${lf})`:`rgba(200,210,225,${lf*0.8})`;
        gc.fillText(city.name,lx,ly+2);
        gc.beginPath();gc.moveTo(city.hq?p[0]+6:p[0]+4,p[1]);gc.lineTo(p[0]>CX?lx:lx+tw,p[1]);gc.strokeStyle=city.hq?`rgba(212,168,83,${lf*0.3})`:`rgba(140,180,220,${lf*0.25})`;gc.lineWidth=0.5;gc.stroke();
        gc.restore();
      }
    }
  });
}

function frame(){
  const elapsed=performance.now()-T0;
  if(elapsed<TOUR_END){rot=getTourRot(elapsed);}
  else if(!zoomChi){
    zoomChi=true;
    const wrap=document.getElementById('_gi_wrap'),brand=document.getElementById('_gi_brand');
    const cpNA=project(-95,38,rot);
    if(cpNA){wrap.style.transition='transform 2.5s cubic-bezier(0.16,1,0.3,1)';wrap.style.transformOrigin=`${cpNA[0]}px ${cpNA[1]}px`;wrap.style.transform='scale(2.8)';}
    setTimeout(()=>{
      if(brand){brand.style.transition='opacity 0.6s';brand.style.opacity='0';}
      const cpChi=project(-87.63,41.88,rot);
      if(cpChi){wrap.style.transition='transform 2s cubic-bezier(0.16,1,0.3,1)';wrap.style.transformOrigin=`${cpChi[0]}px ${cpChi[1]}px`;wrap.style.transform='scale(7)';}
    },2800);
  }
  gc.clearRect(0,0,400,400);
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle='#141a24';gc.fill();
  const atm=gc.createRadialGradient(CX-40,CY-40,R*0.5,CX,CY,R);atm.addColorStop(0,'rgba(100,160,220,0.06)');atm.addColorStop(0.8,'rgba(60,100,160,0.03)');atm.addColorStop(1,'rgba(140,180,220,0.12)');
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle=atm;gc.fill();
  gc.save();gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.clip();
  gc.strokeStyle='rgba(255,255,255,0.04)';gc.lineWidth=0.4;drawGraticule();
  gc.fillStyle='rgba(200,210,225,0.18)';gc.strokeStyle='rgba(200,210,225,0.06)';gc.lineWidth=0.5;for(const poly of LAND){drawPoly(poly);gc.fill();gc.stroke();}
  gc.fillStyle='rgba(212,168,83,0.12)';gc.strokeStyle='rgba(212,168,83,0.08)';gc.lineWidth=0.6;drawPoly(LAND[0]);gc.fill();gc.stroke();
  const vig=gc.createRadialGradient(CX+R*0.25,CY-R*0.25,0,CX,CY,R);vig.addColorStop(0,'rgba(20,26,36,0)');vig.addColorStop(0.7,'rgba(20,26,36,0)');vig.addColorStop(1,'rgba(10,14,20,0.5)');
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle=vig;gc.fill();
  drawOffices(elapsed);gc.restore();
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.strokeStyle='rgba(140,180,220,0.1)';gc.lineWidth=1;gc.stroke();
  drawWhirl(rot*Math.PI/180);
  raf=requestAnimationFrame(frame);
}
frame();

setTimeout(()=>{['_gi_bf','_gi_br','_gi_bs'].forEach((id,i)=>{setTimeout(()=>{const e=document.getElementById(id);if(e)e.style.opacity='1';},i*300);});},800);

/* ─── DISMISS — notifies parent iframe to fade out ───────── */
window.dismissGlobeIntro=function(){
  cancelAnimationFrame(raf);
  try{window.parent.postMessage({type:'globeDone'},'*');}catch(e){}
};

/* Auto-dismiss after full animation: TOUR_END + ~7 500 ms */
setTimeout(window.dismissGlobeIntro, 25100);

})();
</script>
</body>
</html>
"""

    # Base64-encode the globe so it can be set as a data-URL src on an iframe
    # injected into window.parent.document — this avoids all string-escaping
    # issues and makes position:fixed cover the real viewport.
    _globe_b64 = base64.b64encode(_GLOBE_HTML.encode("utf-8")).decode("ascii")
    _globe_data_url = f"data:text/html;base64,{_globe_b64}"

    # Small invisible component whose only job is to inject the full-screen
    # globe iframe + skip button into the parent Streamlit document.
    import streamlit.components.v1 as _stc
    _stc.html(f"""<!DOCTYPE html>
<html><head><style>html,body{{margin:0;padding:0;height:0;overflow:hidden;background:transparent;}}</style></head>
<body><script>
(function(){{
  try {{
    var pdoc = window.parent.document;

    // Guard: don't inject twice on Streamlit reruns
    if (pdoc.getElementById('_gi_frame')) return;

    // ── Full-screen iframe containing the globe ──────────────────
    var fr = pdoc.createElement('iframe');
    fr.id = '_gi_frame';
    fr.src = '{_globe_data_url}';
    fr.style.cssText = 'position:fixed;inset:0;z-index:2147483647;border:none;width:100vw;height:100vh;background:#0c0e14;transition:opacity 1.6s ease;';
    fr.setAttribute('sandbox', 'allow-scripts allow-same-origin');
    pdoc.body.appendChild(fr);

    // ── Skip button in parent document (above the iframe) ───────
    var sk = pdoc.createElement('div');
    sk.id = '_gi_skip_btn';
    sk.textContent = 'SKIP  ›';
    sk.style.cssText = [
      'position:fixed;bottom:32px;right:40px;z-index:2147483648;',
      'font-size:10px;letter-spacing:2.5px;text-transform:uppercase;',
      'color:rgba(255,255,255,0.25);cursor:pointer;',
      'border:1px solid rgba(255,255,255,0.12);padding:7px 16px;',
      "font-family:'DM Sans',system-ui,sans-serif;font-weight:500;",
      'transition:color .25s,border-color .25s;border-radius:2px;'
    ].join('');
    sk.onmouseover = function(){{ sk.style.color='rgba(255,255,255,0.6)'; sk.style.borderColor='rgba(255,255,255,0.35)'; }};
    sk.onmouseout  = function(){{ sk.style.color='rgba(255,255,255,0.25)'; sk.style.borderColor='rgba(255,255,255,0.12)'; }};
    pdoc.body.appendChild(sk);

    function dismiss() {{
      fr.style.opacity = '0';
      sk.style.opacity = '0';
      setTimeout(function(){{ fr.remove(); sk.remove(); }}, 1700);
    }}

    sk.onclick = dismiss;

    // Listen for globeDone from the iframe
    function onMsg(e) {{
      if (e.data && e.data.type === 'globeDone') {{
        dismiss();
        window.removeEventListener('message', onMsg);
        window.parent.removeEventListener('message', onMsg);
      }}
    }}
    window.addEventListener('message', onMsg);
    window.parent.addEventListener('message', onMsg);

  }} catch(err) {{ console.warn('Globe intro failed:', err); }}
}})();
</script></body></html>""", height=0)

# ── Google Fonts + Design System ──────────────────────────────────────────────
# st.html() bypasses Streamlit 1.45.x remark-directive pipeline (avoids
# directiveAttributes crash triggered by CSS selectors like :root, :hover, etc.)
st.html("""
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<div style="display:none"><style>
/* ══════════════════════════════════════════════════════════════
   FITCH RATINGS DESIGN SYSTEM
   Deep navy institutional palette · Zero border-radius · Serif headers
══════════════════════════════════════════════════════════════ */
:root {
  --bg:          #04070f;
  --navy:        #060a16;
  --surface:     #08101f;
  --surface-2:   #0c1428;
  --surface-3:   #101b34;
  --surface-4:   #16223e;
  --surface-alt: #0c1428;
  --border:      rgba(255,255,255,0.055);
  --border-2:    rgba(255,255,255,0.10);
  --border-3:    rgba(255,255,255,0.18);
  --text:        #bdc7da;
  --text-2:      #6b7a96;
  --text-3:      #354060;
  --heading:     #dde4f0;
  --muted:       #6b7a96;
  --fitch-red:   #c41e24;
  --fitch-red-dim:  rgba(196,30,36,0.13);
  --fitch-red-glow: rgba(196,30,36,0.25);
  --fitch-slate: #4a5a6b;
  --gold:        #b8965a;
  --gold-dim:    rgba(184,150,90,0.13);
  --green:       #2d9e6b;
  --green-dim:   rgba(45,158,107,0.12);
  --yellow:      #c49a30;
  --yellow-dim:  rgba(196,154,48,0.12);
  --blue:        #4a8ccc;
  --purple:      #8b7acc;
  /* legacy compat */
  --bg-green:    rgba(45,158,107,0.12);
  --bg-yellow:   rgba(196,154,48,0.12);
  --bg-red:      rgba(196,30,36,0.13);
  --bg-blue:     rgba(74,140,204,0.12);
  --bg-orange:   rgba(184,150,90,0.12);
  --bg-risk:     rgba(196,30,36,0.08);
  --border-green: rgba(45,158,107,0.3);
  --border-blue:  rgba(74,140,204,0.3);
  --red:          #c41e24;
  --orange:       #b8965a;
  /* fitch factor cells */
  --f1-bg: rgba(196,30,36,0.13);  --f1-fg: #c41e24;
  --f2-bg: rgba(184,150,90,0.10); --f2-fg: #b08a24;
  --f3-bg: rgba(196,154,48,0.12); --f3-fg: #c49a30;
  --f4-bg: rgba(45,158,107,0.08); --f4-fg: #259463;
  --f5-bg: rgba(45,158,107,0.12); --f5-fg: #2d9e6b;
  --font-serif: 'Playfair Display', Georgia, serif;
  --font-ui:    'Inter', system-ui, sans-serif;
  --font-mono:  'JetBrains Mono', monospace;
}

/* ── Global resets ─────────────────────────────────────────── */
html, body, [data-testid="stAppViewContainer"] {
  font-family: var(--font-ui) !important;
  background: var(--bg) !important;
  color: var(--text) !important;
  -webkit-font-smoothing: antialiased;
}
* { box-sizing: border-box; }

/* ── Hide Streamlit chrome ─────────────────────────────────── */
#MainMenu, footer, header { visibility: hidden; }
[data-testid="stDecoration"] { display: none; }

/* ── Remove default top padding so header/ticker sit flush ── */
[data-testid="stMainBlockContainer"],
[data-testid="block-container"] {
  padding-top: 0 !important;
}

/* ── Sidebar ───────────────────────────────────────────────── */
[data-testid="stSidebar"] {
  background: var(--navy) !important;
  border-right: 1px solid var(--border) !important;
}
[data-testid="stSidebar"]:after {
  content: '';
  position: absolute; top: 0; right: 0; width: 1px; height: 100%;
  background: linear-gradient(to bottom, transparent, var(--fitch-red-dim) 40%, transparent);
  pointer-events: none;
}
[data-testid="stSidebarContent"] { padding-top: 0 !important; }

/* ── Sidebar radio nav ─────────────────────────────────────── */
[data-testid="stRadio"] > div { gap: 0 !important; flex-direction: column !important; }
[data-testid="stRadio"] label {
  display: flex !important;
  align-items: center !important;
  padding: 8px 20px !important;
  font-size: 12px !important;
  font-weight: 400 !important;
  color: var(--text-2) !important;
  font-family: var(--font-ui) !important;
  letter-spacing: 0.1px !important;
  cursor: pointer !important;
  transition: color 0.15s, background 0.15s !important;
  border-radius: 0 !important;
  margin: 0 !important;
  border-left: 2px solid transparent !important;
  min-height: 34px !important;
  width: 100% !important;
}
[data-testid="stRadio"] label:hover {
  color: var(--text) !important;
  background: rgba(255,255,255,0.03) !important;
}
[data-testid="stRadio"] label[data-checked="true"],
[data-testid="stRadio"] label[aria-checked="true"] {
  color: var(--text) !important;
  background: rgba(255,255,255,0.04) !important;
  border-left-color: var(--fitch-red) !important;
}
[data-testid="stRadio"] [data-testid="stMarkdownContainer"] p {
  font-size: 12px !important;
  color: inherit !important;
  font-family: var(--font-ui) !important;
}
/* Hide the radio circles */
[data-testid="stRadio"] input[type="radio"] { display: none !important; }
[data-testid="stRadio"] > div > label > div:first-child { display: none !important; }

/* Nav section group labels injected via HTML — keep gap before them */
.nav-section-label {
  font-size: 9px; font-weight: 600; letter-spacing: 1.4px; text-transform: uppercase;
  color: var(--text-3); padding: 14px 20px 5px; display: block;
}

/* ── Metric containers ─────────────────────────────────────── */
[data-testid="metric-container"] {
  background: var(--surface) !important;
  border: 1px solid var(--border) !important;
  border-radius: 0 !important;
  padding: 16px 20px !important;
  position: relative;
  overflow: hidden;
}
[data-testid="metric-container"]:after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(105deg,transparent 40%,rgba(255,255,255,0.015) 50%,transparent 60%);
  background-size: 200% 100%;
  animation: shimmer 4s ease-in-out infinite;
  pointer-events: none;
}
@keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
[data-testid="metric-container"] label {
  font-size: 9px !important;
  font-weight: 600 !important;
  letter-spacing: 1.3px !important;
  text-transform: uppercase !important;
  color: var(--text-3) !important;
  font-family: var(--font-ui) !important;
}
[data-testid="metric-container"] [data-testid="stMetricValue"] {
  font-size: 24px !important;
  font-weight: 500 !important;
  font-family: var(--font-mono) !important;
  color: var(--text) !important;
  line-height: 1 !important;
}
[data-testid="metric-container"] [data-testid="stMetricDelta"] {
  font-size: 10px !important;
  color: var(--text-2) !important;
  font-family: var(--font-mono) !important;
}

/* ── File uploader ─────────────────────────────────────────── */
[data-testid="stFileUploader"] {
  background: var(--surface) !important;
  border: 1px dashed var(--border-2) !important;
  border-radius: 0 !important;
  padding: 20px !important;
  position: relative;
  overflow: hidden;
}
[data-testid="stFileUploader"]:before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 70% 60% at 50% 110%, var(--fitch-red-dim), transparent);
  pointer-events: none;
  animation: uploadGlow 3s ease-in-out infinite;
}
@keyframes uploadGlow { 0%,100%{opacity:0.6} 50%{opacity:1} }
[data-testid="stFileUploader"]:hover { border-color: var(--fitch-red) !important; }

/* ── Buttons ───────────────────────────────────────────────── */
.stButton > button {
  background: var(--fitch-red) !important;
  color: #fff !important;
  border: 1px solid var(--fitch-red) !important;
  border-radius: 0 !important;
  font-weight: 500 !important;
  font-family: var(--font-ui) !important;
  font-size: 12px !important;
  letter-spacing: 0.3px !important;
  padding: 8px 20px !important;
  width: 100% !important;
  transition: all 0.15s !important;
}
.stButton > button:hover {
  background: #d42028 !important;
  border-color: #d42028 !important;
}

/* ── Tabs ──────────────────────────────────────────────────── */
[data-testid="stTabs"] [data-baseweb="tab-list"] {
  background: transparent !important;
  border-bottom: 1px solid var(--border) !important;
  gap: 0 !important;
}
[data-testid="stTabs"] [data-baseweb="tab"] {
  background: transparent !important;
  border-radius: 0 !important;
  border-bottom: 2px solid transparent !important;
  color: var(--text-2) !important;
  font-size: 11px !important;
  font-weight: 500 !important;
  font-family: var(--font-ui) !important;
  letter-spacing: 0.2px !important;
  padding: 8px 14px !important;
}
[data-testid="stTabs"] [data-baseweb="tab"][aria-selected="true"] {
  color: var(--text) !important;
  border-bottom-color: var(--fitch-red) !important;
}
[data-testid="stTabs"] [data-baseweb="tab-panel"] {
  background: transparent !important;
  padding-top: 16px !important;
}

/* ── Expanders ─────────────────────────────────────────────── */
[data-testid="stExpander"] {
  background: var(--surface) !important;
  border: 1px solid var(--border) !important;
  border-radius: 0 !important;
}
[data-testid="stExpander"] summary {
  font-size: 12px !important;
  color: var(--text-2) !important;
  font-family: var(--font-ui) !important;
}

/* ── Dataframe ─────────────────────────────────────────────── */
[data-testid="stDataFrame"] {
  border: 1px solid var(--border) !important;
  border-radius: 0 !important;
}
[data-testid="stDataFrame"] table { font-family: var(--font-mono) !important; font-size: 11px !important; }
[data-testid="stDataFrame"] th {
  background: var(--surface-2) !important;
  color: var(--text-3) !important;
  font-size: 9px !important;
  letter-spacing: 1.2px !important;
  text-transform: uppercase !important;
  font-weight: 600 !important;
  border-bottom: 1px solid var(--border) !important;
}
[data-testid="stDataFrame"] td {
  background: var(--surface) !important;
  color: var(--text) !important;
  border-bottom: 1px solid var(--border) !important;
}

/* ── Selectbox / multiselect ───────────────────────────────── */
[data-testid="stSelectbox"] > div > div,
[data-testid="stMultiSelect"] > div > div {
  background: var(--surface) !important;
  border: 1px solid var(--border) !important;
  border-radius: 0 !important;
  color: var(--text) !important;
}

/* ── Text inputs ───────────────────────────────────────────── */
[data-testid="stTextInput"] > div > div > input,
[data-testid="stTextArea"] textarea {
  background: var(--surface) !important;
  border: 1px solid var(--border) !important;
  border-radius: 0 !important;
  color: var(--text) !important;
  font-family: var(--font-ui) !important;
}

/* ── Dividers ──────────────────────────────────────────────── */
hr { border: none !important; border-top: 1px solid var(--border) !important; }
[data-testid="stDivider"] { border-top: 1px solid var(--border) !important; }

/* ── Captions / small text ─────────────────────────────────── */
.stCaption, [data-testid="stCaptionContainer"] {
  color: var(--text-2) !important;
  font-size: 10px !important;
  font-family: var(--font-ui) !important;
}

/* ── Page titles ───────────────────────────────────────────── */
h1 {
  font-family: var(--font-serif) !important;
  font-size: 22px !important;
  font-weight: 500 !important;
  letter-spacing: -0.3px !important;
  color: var(--text) !important;
}
h2 { font-family: var(--font-serif) !important; font-size: 18px !important; font-weight: 500 !important; color: var(--text) !important; }
h3 { font-family: var(--font-ui) !important; font-size: 13px !important; font-weight: 600 !important; color: var(--text) !important; }

/* ── Custom component classes ──────────────────────────────── */
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 0;
  padding: 18px 20px;
  margin-bottom: 14px;
  color: var(--text);
}
.card-2 { background: var(--surface-2); border: 1px solid var(--border); border-radius: 0; padding: 12px 14px; margin-bottom: 8px; }
.card-accent-green  { border-left: 2px solid var(--green) !important; }
.card-accent-blue   { border-left: 2px solid var(--blue) !important; }
.card-accent-yellow { border-left: 2px solid var(--yellow) !important; }
.card-accent-red    { border-left: 2px solid var(--fitch-red) !important; }
.card-accent-purple { border-left: 2px solid var(--purple) !important; }

/* Chips (square, no border-radius) */
.chip {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 2px 8px; font-size: 10px; font-family: var(--font-mono);
  font-weight: 500; border: 1px solid;
}
.chip-green { background: var(--green-dim); border-color: rgba(45,158,107,0.25); color: var(--green); }
.chip-red   { background: var(--fitch-red-dim); border-color: rgba(196,30,36,0.25); color: var(--fitch-red); }
.chip-gold  { background: var(--gold-dim); border-color: rgba(184,150,90,0.25); color: var(--gold); }
.chip-muted { background: var(--surface-3); border-color: var(--border); color: var(--text-2); }

/* Legacy badge aliases → chip */
.badge-high { display:inline-block; background:var(--green-dim);    color:var(--green);     padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(45,158,107,0.25); }
.badge-mid  { display:inline-block; background:var(--yellow-dim);   color:var(--yellow);    padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(196,154,48,0.25); }
.badge-low  { display:inline-block; background:var(--fitch-red-dim);color:var(--fitch-red); padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(196,30,36,0.25); }

/* ESG rating chips */
.esg-aaa,.esg-aa { background:var(--green-dim);     color:var(--green);     padding:3px 10px; font-family:var(--font-mono); font-weight:600; font-size:14px; border:1px solid rgba(45,158,107,0.3); }
.esg-a            { background:var(--bg-blue);       color:var(--blue);      padding:3px 10px; font-family:var(--font-mono); font-weight:600; font-size:14px; border:1px solid rgba(74,140,204,0.3); }
.esg-bbb          { background:var(--yellow-dim);    color:var(--yellow);    padding:3px 10px; font-family:var(--font-mono); font-weight:600; font-size:14px; border:1px solid rgba(196,154,48,0.3); }
.esg-bb           { background:var(--gold-dim);      color:var(--gold);      padding:3px 10px; font-family:var(--font-mono); font-weight:600; font-size:14px; border:1px solid rgba(184,150,90,0.3); }
.esg-b            { background:var(--fitch-red-dim); color:var(--fitch-red); padding:3px 10px; font-family:var(--font-mono); font-weight:600; font-size:14px; border:1px solid rgba(196,30,36,0.3); }

/* Fitch factor score cells */
.fitch-1 { background:var(--f1-bg); color:var(--f1-fg); }
.fitch-2 { background:var(--f2-bg); color:var(--f2-fg); }
.fitch-3 { background:var(--f3-bg); color:var(--f3-fg); }
.fitch-4 { background:var(--f4-bg); color:var(--f4-fg); }
.fitch-5 { background:var(--f5-bg); color:var(--f5-fg); }
.fitch-cell { display:inline-block; padding:2px 8px; font-weight:700; font-size:12px; font-family:var(--font-mono); border:1px solid currentColor; opacity:0.9; }

/* Regulatory gap badges */
.gap-disclosed { background:var(--green-dim);     color:var(--green);     padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(45,158,107,0.3); }
.gap-partial   { background:var(--yellow-dim);    color:var(--yellow);    padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(196,154,48,0.3); }
.gap-missing   { background:var(--fitch-red-dim); color:var(--fitch-red); padding:2px 8px; font-size:10px; font-weight:600; border:1px solid rgba(196,30,36,0.3); }

.framework-pill { display:inline-block; background:var(--bg-blue); color:var(--blue); border:1px solid var(--border-blue); padding:2px 10px; font-size:11px; margin:2px; }
.target-box { background:var(--green-dim); border:1px solid rgba(45,158,107,0.25); padding:12px 16px; margin:8px 0; }
.risk-item { border-left:2px solid var(--fitch-red); padding:4px 12px; margin:4px 0; background:var(--bg-risk); }

/* Sub-labels (uppercase section headers) */
.sub-label {
  font-size: 9px; font-weight: 600; letter-spacing: 1.3px;
  text-transform: uppercase; color: var(--text-3); margin-bottom: 10px;
}
.section-label { font-size:10px; color:var(--text-2); text-transform:uppercase; letter-spacing:1px; font-weight:600; margin-bottom:4px; }
.sidebar-header { font-family:var(--font-serif); font-size:18px; font-weight:500; color:var(--text); margin-bottom:2px; }
.sidebar-sub    { font-size:10px; color:var(--text-3); margin-bottom:12px; text-transform:uppercase; letter-spacing:1px; font-weight:500; }

/* Data table rows */
.seg-table { width:100%; border-collapse:collapse; }
.seg-table th { font-size:9px; font-weight:600; letter-spacing:1.2px; text-transform:uppercase; color:var(--text-3); padding:7px 10px; text-align:left; border-bottom:1px solid var(--border); }
.seg-table td { padding:8px 10px; font-size:12px; border-bottom:1px solid var(--border); color:var(--text); vertical-align:middle; font-family:var(--font-mono); }
.seg-table tr:last-child td { border-bottom:none; }
.seg-table tr:hover td { background:rgba(255,255,255,0.02); }

/* Reg progress bars */
.reg-track { height:3px; background:var(--surface-3); margin-top:4px; }
.reg-fill-green  { height:3px; background:var(--green); }
.reg-fill-yellow { height:3px; background:var(--yellow); }
.reg-fill-blue   { height:3px; background:var(--blue); }

/* KPI strip */
.kpi-strip { display:grid; gap:0; border:1px solid var(--border); margin-bottom:20px; }
.kpi-strip-4 { grid-template-columns:repeat(4,1fr); }
.kpi-strip-5 { grid-template-columns:repeat(5,1fr); }
.kpi-cell { padding:16px 20px; border-right:1px solid var(--border); position:relative; overflow:hidden; }
.kpi-cell:last-child { border-right:none; }
.kpi-label { font-size:9px; font-weight:600; letter-spacing:1.3px; text-transform:uppercase; color:var(--text-3); margin-bottom:8px; }
.kpi-value { font-size:24px; font-weight:500; font-family:var(--font-mono); color:var(--text); line-height:1; }
.kpi-delta { font-size:10px; color:var(--text-2); margin-top:5px; font-family:var(--font-mono); }
.kpi-value.red   { color:var(--fitch-red); }
.kpi-value.gold  { color:var(--gold); }
.kpi-value.green { color:var(--green); }

/* Ticker bar */
.ticker-bar {
  height:28px; background:var(--navy); border-bottom:1px solid var(--border);
  display:flex; align-items:stretch; gap:0; overflow:hidden;
  margin:0 -1rem 1.5rem -1rem; position:relative;
}
.ticker-label {
  font-size:9px; font-weight:800; letter-spacing:1.8px; text-transform:uppercase;
  color:#fff; background:#c41e24; padding:0 14px;
  white-space:nowrap; flex-shrink:0; align-self:stretch;
  display:flex; align-items:center;
  border-right:2px solid #a01018;
  position:relative; z-index:2;
}
.ticker-bar::after {
  content:''; position:absolute; right:0; top:0; bottom:0; width:40px;
  background:linear-gradient(to right, transparent, var(--navy));
  z-index:1; pointer-events:none;
}
.ticker-scroll-track {
  flex:1; overflow:hidden; position:relative; display:flex; align-items:center;
}
.ticker-items { display:flex; gap:24px; animation:tickerScroll 40s linear infinite; white-space:nowrap; padding-left:16px; }
@keyframes tickerScroll { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
.ticker-item { font-size:10px; font-family:var(--font-mono); color:var(--text-2); display:flex; align-items:center; gap:5px; flex-shrink:0; }
.ticker-item span { color:var(--text); }
.ticker-up  { color:var(--green)!important; }
.ticker-dn  { color:var(--fitch-red)!important; }

/* Fitch attribution chip */
.fitch-attr {
  display:inline-flex; align-items:center; gap:6px;
  padding:4px 10px; border:1px solid var(--border); background:var(--surface-2);
  font-size:9px; letter-spacing:1px; text-transform:uppercase; color:var(--text-3);
}
.fitch-attr-dot { width:5px; height:5px; background:var(--fitch-red); flex-shrink:0; display:inline-block; }

/* Context panel */
.ctx-live-dot {
  width:5px; height:5px; border-radius:50%; background:var(--green);
  display:inline-block; margin-right:6px;
  box-shadow:0 0 6px var(--green);
  animation:pulse-dot 2s ease-in-out infinite;
}
@keyframes pulse-dot { 0%,100%{opacity:1;box-shadow:0 0 6px var(--green)} 50%{opacity:0.5;box-shadow:0 0 2px var(--green)} }

/* Sidebar nav iframe — seamless, no border, navy bg */
[data-testid="stSidebar"] [data-testid="stCustomComponentV1"] {
  margin:0!important; padding:0!important; border:none!important;
  background:#060a16!important; display:block!important;
}
[data-testid="stSidebar"] [data-testid="stCustomComponentV1"] iframe {
  border:none!important; background:#060a16!important;
  display:block!important; width:100%!important;
}

/* ── Result card ───────────────────────────────────────────── */
.result-card{background:var(--surface);border:1px solid var(--border);margin-bottom:14px;animation:fadeSlideIn 0.4s ease forwards}
@keyframes fadeSlideIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.result-header{padding:13px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;background:linear-gradient(90deg,var(--surface-2) 0%,var(--surface) 60%);position:relative;overflow:hidden}
.result-header:after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,var(--fitch-red-dim),transparent 40%);pointer-events:none}
.result-check{color:var(--green);flex-shrink:0;position:relative;z-index:1}
.result-filename{font-size:13px;font-weight:500;color:var(--text);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;position:relative;z-index:1}

/* ── Data strip ────────────────────────────────────────────── */
.data-strip{display:grid;grid-template-columns:repeat(5,1fr);border-bottom:1px solid var(--border)}
.data-cell{padding:12px 18px;border-right:1px solid var(--border)}
.data-cell:last-child{border-right:none}
.data-cell-label{font-size:9px;letter-spacing:1.3px;text-transform:uppercase;color:var(--text-3);margin-bottom:5px;font-weight:600}
.data-cell-value{font-size:17px;font-weight:500;font-family:var(--font-mono);color:var(--text);line-height:1}
.data-cell-value.red{color:var(--fitch-red)}
.data-cell-value.sm{font-size:13px;padding-top:2px}

/* ── Result body 2-col ─────────────────────────────────────── */
.result-body{display:grid;grid-template-columns:1fr 1fr;gap:0}
.result-pane{padding:18px}
.result-pane:first-child{border-right:1px solid var(--border)}

/* ── Tab strip (custom) ────────────────────────────────────── */
.tab-strip{display:flex;border-bottom:1px solid var(--border);margin-bottom:14px}
.tab-btn{padding:8px 14px;border:none;background:none;font-size:11px;font-weight:500;font-family:var(--font-ui);color:var(--text-2);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;transition:color 0.15s,border-color 0.15s;letter-spacing:0.2px}
.tab-btn:hover{color:var(--text)}
.tab-btn.active{color:var(--text);border-bottom-color:var(--fitch-red)}
.tab-pane{display:none}
.tab-pane.active{display:block}

/* ── Chart placeholder ─────────────────────────────────────── */
.chart-ph{background:var(--surface-2);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--text-3);letter-spacing:0.5px;font-family:var(--font-mono);position:relative;overflow:hidden;margin-top:12px}
.chart-bars{position:absolute;bottom:0;left:0;right:0;height:55%;display:flex;align-items:flex-end;gap:4px;padding:0 12px}
.cbar{flex:1;opacity:0;border-radius:0;animation:barRise 0.8s ease forwards}
@keyframes barRise{to{opacity:1}}

/* ── Action row ────────────────────────────────────────────── */
.action-row{display:flex;gap:6px;margin-top:12px}
.action-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:6px 12px;border:1px solid var(--border-2);background:transparent;color:var(--text-2);font-size:11px;font-family:var(--font-ui);cursor:pointer;transition:all 0.15s}
.action-btn:hover{border-color:var(--fitch-red);color:var(--fitch-red)}

/* ── Fitch factor columns (new design) ─────────────────────── */
.fitch-cols{display:flex;gap:10px}
.fitch-col{flex:1}
.fitch-col-head{font-size:9px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-3);margin-bottom:7px}
.fitch-item{display:flex;justify-content:space-between;align-items:center;padding:5px 8px;margin-bottom:3px;background:var(--surface-2);border:1px solid var(--border)}
.fitch-item-name{font-size:10px;color:var(--text-2)}
.fitch-score{font-size:10px;font-weight:600;padding:1px 6px;font-family:var(--font-mono);border:1px solid}
.f1{background:var(--fitch-red-dim);border-color:rgba(196,30,36,0.3);color:var(--fitch-red)}
.f2{background:rgba(196,154,48,0.1);border-color:rgba(196,154,48,0.3);color:#b08a24}
.f3{background:var(--yellow-dim);border-color:rgba(196,154,48,0.3);color:var(--yellow)}
.f4{background:rgba(45,158,107,0.08);border-color:rgba(45,158,107,0.25);color:#259463}
.f5{background:var(--green-dim);border-color:rgba(45,158,107,0.3);color:var(--green)}

/* ── Score rows ────────────────────────────────────────────── */
.score-row{display:flex;align-items:center;gap:10px;margin-bottom:8px}
.score-row-label{font-size:11px;color:var(--text-2);width:110px;flex-shrink:0}
.score-track{flex:1;height:3px;background:var(--surface-3);overflow:hidden}
.score-fill{height:100%;transition:width 1.2s ease}
.fill-green{background:var(--green)}
.fill-blue{background:#4a8ccc}
.fill-purple{background:#8b7acc}
.score-val{font-size:10px;font-family:var(--font-mono);color:var(--text);width:24px;text-align:right}

/* ── Disclosure checklist ──────────────────────────────────── */
.disc-list{display:flex;flex-direction:column;gap:5px}
.disc-item{display:flex;align-items:center;gap:7px;font-size:11px;color:var(--text-2)}
.disc-ok{color:var(--green)}
.disc-warn{color:var(--yellow)}
.disc-no{color:var(--fitch-red)}

/* ── Greenwashing flag ─────────────────────────────────────── */
.gw-flag{padding:9px 12px;background:var(--fitch-red-dim);border:1px solid rgba(196,30,36,0.2);font-size:11px;color:var(--fitch-red);display:flex;align-items:flex-start;gap:7px;margin-top:12px}

/* ── Regulatory items ──────────────────────────────────────── */
.reg-item{margin-bottom:14px}
.reg-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:5px}
.reg-label{font-size:11px;font-weight:500;color:var(--text)}
.reg-pct{font-size:11px;font-family:var(--font-mono)}
.reg-track{height:3px;background:var(--surface-3)}
.reg-fill{height:3px;transition:width 1.4s ease}
.reg-sub{font-size:10px;color:var(--text-3);margin-top:3px}

/* ── Net-zero box ──────────────────────────────────────────── */
.nz-box{padding:9px 12px;background:var(--green-dim);border:1px solid rgba(45,158,107,0.2);margin-top:10px}
.nz-title{font-size:11px;font-weight:500;color:var(--green)}
.nz-sub{font-size:10px;color:var(--text-2);margin-top:2px}

/* ── NACE pills ────────────────────────────────────────────── */
.nace-wrap{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}
.nace-pill{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;background:var(--surface-3);border:1px solid var(--border);font-size:10px;font-family:var(--font-mono);color:var(--text-2)}
.nace-code{color:var(--gold)}

/* ── Topbar action buttons ─────────────────────────────────── */
.tbtn{display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border:1px solid var(--border-2);background:transparent;color:var(--text-2);font-size:11px;font-weight:500;font-family:var(--font-ui);cursor:pointer;letter-spacing:0.3px;transition:all 0.15s}
.tbtn:hover{border-color:var(--border-3);color:var(--text);background:rgba(255,255,255,0.03)}
.tbtn-primary{background:var(--fitch-red)!important;border-color:var(--fitch-red)!important;color:#fff!important}
.tbtn-primary:hover{background:#d42028!important;border-color:#d42028!important}

/* ── ESG header ────────────────────────────────────────────── */
.esg-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.esg-rating{font-family:var(--font-mono);font-size:20px;font-weight:600;padding:4px 12px;border:1px solid}
.esg-composite{font-size:11px;color:var(--text-2)}
.esg-composite strong{color:var(--text);font-family:var(--font-mono)}

/* ── Tweaks panel ──────────────────────────────────────────── */
.tweaks-panel{position:fixed;bottom:20px;right:20px;z-index:9999;width:260px;background:var(--surface);border:1px solid var(--border-2);display:none;flex-direction:column;box-shadow:0 12px 40px rgba(0,0,0,0.7)}
.tweaks-panel.visible{display:flex}
.tweaks-head{padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.tweaks-title{font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--text)}
.tweaks-close{background:none;border:none;color:var(--text-2);cursor:pointer;font-size:18px;line-height:1;padding:0}
.tweaks-body{padding:14px 16px;display:flex;flex-direction:column;gap:12px}
.tweak-label{font-size:9px;font-weight:600;letter-spacing:1.3px;text-transform:uppercase;color:var(--text-3);margin-bottom:6px}
.tweak-opts{display:flex;gap:4px;flex-wrap:wrap}
.tweak-opt{padding:4px 10px;border:1px solid var(--border-2);background:transparent;color:var(--text-2);font-size:11px;font-family:var(--font-ui);cursor:pointer;transition:all 0.12s}
.tweak-opt:hover{border-color:var(--fitch-red);color:var(--fitch-red)}
.tweak-opt.sel{background:var(--fitch-red-dim);border-color:rgba(196,30,36,0.4);color:var(--fitch-red)}

/* ── Ticker separator ──────────────────────────────────────── */
.ticker-sep{color:rgba(255,255,255,0.1);margin:0 4px}

/* ══════════════════════════════════════════════════════════
   STOCK PRICE TICKER (top row — Bloomberg / Yahoo Finance style)
══════════════════════════════════════════════════════════ */
.stock-bar {
  height:34px; background:#050c1a;
  border-bottom:1px solid rgba(255,255,255,0.06);
  display:flex; align-items:stretch; overflow:hidden;
  margin:0 -1rem 0 -1rem; flex-shrink:0; position:relative;
}
.stock-bar-label {
  font-size:9px; font-weight:800; letter-spacing:1.8px;
  color:#fff; background:#c41e24; padding:0 14px;
  white-space:nowrap; flex-shrink:0; align-self:stretch;
  display:flex; align-items:center; text-transform:uppercase;
  border-right:2px solid #a01018;
  position:relative; z-index:2;
}
/* Fade-mask on the right edge so items dissolve before looping */
.stock-bar::after {
  content:''; position:absolute; right:0; top:0; bottom:0; width:40px;
  background:linear-gradient(to right, transparent, #050c1a);
  z-index:1; pointer-events:none;
}
.stock-scroll-track {
  flex:1; overflow:hidden; position:relative; display:flex; align-items:center;
}
.stock-items {
  display:flex; gap:0;
  animation:stockScroll 50s linear infinite;
  white-space:nowrap; will-change:transform;
}
.stock-items:hover { animation-play-state:paused; }
@keyframes stockScroll { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
.stock-item {
  font-size:11px; font-family:var(--font-mono);
  color:var(--text-3); display:inline-flex; align-items:center;
  gap:5px; flex-shrink:0; padding:0 18px;
  border-right:1px solid rgba(255,255,255,0.05);
}
.stock-sym { color:#c8d4e8; font-weight:700; font-size:11px; letter-spacing:0.3px; }
.stock-label { color:#4a5a6b; font-size:9px; text-transform:uppercase; }
.stock-price { color:#dce6f5; font-weight:500; }
.stock-chg-up { color:#2dba5a; font-size:10px; }
.stock-chg-dn { color:#e05260; font-size:10px; }
.stock-chg-flat { color:#6b7a96; font-size:10px; }
.stock-divider { color:rgba(255,255,255,0.08); margin:0 2px; }
.stock-item-issuer {
  font-size:11px; font-family:var(--font-mono);
  display:inline-flex; align-items:center; gap:5px; flex-shrink:0;
  padding:0 18px; border-right:1px solid rgba(255,255,255,0.12);
  background:rgba(196,30,36,0.15);
  border-left:2px solid #c41e24 !important;
  position:relative; z-index:2; align-self:stretch;
}
.stock-item-issuer .stock-sym { color:#f0a0a4; font-weight:800; }
.stock-issuer-badge {
  font-size:8px; font-weight:700; letter-spacing:1px;
  color:#c41e24; text-transform:uppercase; background:rgba(196,30,36,0.2);
  padding:1px 5px; border-radius:2px; border:1px solid rgba(196,30,36,0.4);
}

/* ══════════════════════════════════════════════════════════
   NEWS HEADLINE TICKER (second row — CNN / CNBC style)
══════════════════════════════════════════════════════════ */
.news-bar {
  height:26px; background:#03060f;
  border-bottom:1px solid rgba(255,255,255,0.055);
  display:flex; align-items:stretch; overflow:hidden;
  margin:0 -1rem 1.5rem -1rem; position:relative;
}
.news-bar-label {
  font-size:8px; font-weight:800; letter-spacing:2px;
  color:#fff; background:#0057b8; padding:0 12px;
  white-space:nowrap; flex-shrink:0; align-self:stretch;
  display:flex; align-items:center; text-transform:uppercase;
  border-right:2px solid #0046a0;
  position:relative; z-index:2;
}
.news-bar::after {
  content:''; position:absolute; right:0; top:0; bottom:0; width:40px;
  background:linear-gradient(to right, transparent, #03060f);
  z-index:1; pointer-events:none;
}
.news-scroll-track {
  flex:1; overflow:hidden; position:relative; display:flex; align-items:center;
}
.news-items {
  display:flex; gap:0;
  animation:newsScroll 80s linear infinite;
  white-space:nowrap; will-change:transform;
}
.news-items:hover { animation-play-state:paused; }
@keyframes newsScroll { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
.news-item {
  font-size:10px; font-family:var(--font-mono);
  color:#8b97af; display:inline-flex; align-items:center;
  gap:8px; flex-shrink:0; padding:0 24px;
}
.news-bullet {
  color:#c41e24; font-size:12px; flex-shrink:0; line-height:1;
}
.news-headline { color:#bdc7da; }
.news-source { color:#4a5a6b; font-size:9px; }
</style></div>
""")

# ── Globe splash (first-visit cinematic intro) — OLD STUB REMOVED ─────────────
if False:  # placeholder so nothing breaks if referenced
  _OLD_GLOBE_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:100%;height:100%;background:#f4f2ec;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:Georgia,'Times New Roman',serif;overflow:hidden}
#inner{position:relative;width:200px;height:200px;will-change:transform}
#gc{display:block;border-radius:50%}
.ring{position:absolute;border-radius:50%;border:1px dashed rgba(0,0,0,0.12);animation:rr 6s linear infinite}
.ring:nth-child(2){inset:-34px;animation-duration:9s;animation-direction:reverse;border-color:rgba(0,0,0,0.07)}
.ring:nth-child(3){inset:-14px;animation-duration:4s;border-color:rgba(0,0,0,0.09)}
.ring{inset:-22px}
@keyframes rr{to{transform:rotate(360deg)}}
#brand{margin-top:32px;text-align:center;opacity:0;transition:opacity 0.9s ease}
#bf{font-weight:700;font-size:28px;color:#c41e24;letter-spacing:-0.4px}
#br{font-weight:400;font-size:28px;color:#4a5a6b;margin-left:3px;letter-spacing:-0.4px}
#bs{display:block;font-size:9px;letter-spacing:2.2px;text-transform:uppercase;color:#aaa;margin-top:9px;font-family:'Inter',system-ui,sans-serif}
#skip{position:fixed;bottom:32px;right:32px;padding:8px 20px;background:transparent;border:1px solid rgba(0,0,0,0.2);color:#4a5a6b;font-size:11px;letter-spacing:1px;text-transform:uppercase;cursor:pointer;font-family:'Inter',system-ui,sans-serif;transition:all 0.2s;opacity:0}
#skip:hover{background:rgba(0,0,0,0.06);border-color:rgba(0,0,0,0.35)}
</style>
</head>
<body>
<div id="inner">
  <div class="ring"></div><div class="ring"></div><div class="ring"></div>
  <canvas id="gc" width="200" height="200"></canvas>
</div>
<div id="brand"><span id="bf">Fitch</span><span id="br">Ratings</span><span id="bs">Global Credit Rating Analytics &nbsp;·&nbsp; 11 Offices Worldwide</span></div>
<button id="skip" onclick="advance()">Skip Intro</button>
<script>
const OFFICES=[
  {lon:-0.12,lat:51.51,name:'London'},{lon:2.35,lat:48.85,name:'Paris'},
  {lon:8.68,lat:50.11,name:'Frankfurt'},{lon:139.69,lat:35.69,name:'Tokyo'},
  {lon:114.17,lat:22.32,name:'Hong Kong'},{lon:103.82,lat:1.35,name:'Singapore'},
  {lon:72.88,lat:19.08,name:'Mumbai'},{lon:55.30,lat:25.20,name:'Dubai'},
  {lon:151.21,lat:-33.87,name:'Sydney'},{lon:-74.01,lat:40.71,name:'New York'},
  {lon:-87.63,lat:41.88,name:'Chicago',isTarget:true},
];
const POLYS=[
  [[-168,72],[-155,72],[-140,68],[-137,58],[-130,55],[-126,50],[-124,47],[-120,38],[-117,33],[-110,24],[-92,16],[-85,10],[-78,8],[-77,8],[-82,10],[-84,20],[-91,21],[-97,26],[-110,24],[-117,33],[-120,45],[-126,50],[-130,55],[-137,57],[-150,60],[-160,62],[-163,68],[-168,72]],
  [[-70,83],[-55,82],[-22,76],[-18,70],[-25,65],[-45,60],[-55,65],[-65,67],[-70,75],[-70,83]],
  [[-79,8],[-63,10],[-50,4],[-36,-6],[-35,-10],[-38,-15],[-40,-22],[-45,-24],[-48,-28],[-52,-34],[-58,-38],[-62,-45],[-65,-55],[-70,-55],[-75,-50],[-72,-42],[-72,-35],[-72,-28],[-70,-20],[-75,-14],[-80,-3],[-79,8]],
  [[-10,36],[0,37],[5,36],[14,37],[19,40],[23,38],[26,38],[28,42],[34,42],[36,46],[30,47],[26,47],[22,44],[16,45],[14,44],[12,44],[8,45],[3,45],[0,47],[-2,46],[-5,44],[-9,44],[-9,38],[-5,36],[-10,36]],
  [[-6,50],[-3,50],[0,52],[0,53],[-3,54],[-5,54],[-6,50]],
  [[5,58],[8,58],[10,57],[14,56],[18,57],[20,60],[28,71],[30,70],[28,65],[20,63],[14,58],[8,58],[5,58]],
  [[-18,15],[-15,12],[-14,10],[-8,5],[-4,4],[2,4],[8,4],[14,4],[16,1],[36,-1],[40,10],[44,12],[44,18],[36,22],[34,28],[32,32],[30,30],[26,24],[22,22],[16,20],[10,10],[8,4],[2,4],[-8,4],[-14,10],[-18,15]],
  [[16,-34],[20,-35],[26,-34],[32,-30],[34,-22],[35,-18],[34,-28],[26,-24],[20,-28],[16,-34]],
  [[44,-14],[50,-16],[50,-25],[44,-26],[44,-14]],
  [[36,36],[40,37],[42,36],[45,30],[50,25],[55,22],[58,20],[52,14],[44,12],[36,22],[36,36]],
  [[60,22],[70,22],[72,22],[80,24],[86,26],[92,26],[92,22],[88,20],[82,14],[80,10],[76,8],[72,8],[68,22],[60,22]],
  [[98,22],[105,22],[108,20],[110,10],[104,4],[100,4],[98,10],[98,22]],
  [[110,42],[115,40],[120,36],[120,30],[122,24],[118,20],[110,20],[105,22],[105,28],[110,32],[114,38],[110,42]],
  [[126,38],[130,36],[132,34],[128,34],[126,38]],
  [[130,32],[136,34],[140,38],[142,42],[140,44],[132,44],[130,38],[130,32]],
  [[114,-22],[120,-22],[126,-22],[130,-12],[136,-12],[136,-16],[130,-16],[136,-12],[142,-10],[148,-14],[154,-20],[156,-26],[150,-38],[144,-38],[140,-36],[134,-32],[130,-32],[116,-34],[114,-28],[114,-22]],
  [[172,-34],[174,-36],[176,-38],[174,-40],[170,-40],[172,-34]],
  [[172,-42],[174,-44],[172,-46],[170,-44],[172,-42]],
  [[26,70],[32,68],[40,68],[50,64],[60,64],[56,58],[50,52],[44,46],[38,44],[36,46],[30,47],[26,47],[22,54],[22,60],[26,65],[28,71],[26,70]],
  [[60,64],[80,68],[100,72],[120,72],[140,70],[160,62],[168,60],[160,54],[150,48],[140,44],[130,40],[126,50],[120,48],[110,44],[100,50],[90,56],[80,60],[70,62],[60,64]],
  [[-180,-70],[-90,-72],[0,-72],[90,-72],[180,-70],[180,-75],[-180,-75],[-180,-70]],
];
const canvas=document.getElementById('gc');
const gc=canvas.getContext('2d');
const CX=100,CY=100,R=88;
let rot=0,zoomFired=false,done=false;
const T0=performance.now();

function project(lon,lat,r){
  const λ=(lon+r)*Math.PI/180,φ=lat*Math.PI/180,tilt=-22*Math.PI/180;
  const x3=Math.cos(φ)*Math.sin(λ),y3=Math.sin(φ),z3=Math.cos(φ)*Math.cos(λ);
  const y3t=y3*Math.cos(tilt)-z3*Math.sin(tilt),z3t=y3*Math.sin(tilt)+z3*Math.cos(tilt);
  if(z3t<0)return null;
  return[CX+R*x3,CY-R*y3t,z3t];
}
function drawPoly(pts,r){
  let s=false;gc.beginPath();
  for(const[lo,la]of pts){const p=project(lo,la,r);if(!p){s=false;continue;}s?gc.lineTo(p[0],p[1]):gc.moveTo(p[0],p[1]);s=true;}
  gc.closePath();
}
function drawGrat(r){
  for(let lo=-180;lo<=180;lo+=30){gc.beginPath();let f=true;for(let la=-90;la<=90;la+=4){const p=project(lo,la,r);if(!p){f=true;continue;}f?gc.moveTo(p[0],p[1]):gc.lineTo(p[0],p[1]);f=false;}gc.stroke();}
  for(let la=-60;la<=60;la+=30){gc.beginPath();let f=true;for(let lo=-180;lo<=180;lo+=4){const p=project(lo,la,r);if(!p){f=true;continue;}f?gc.moveTo(p[0],p[1]):gc.lineTo(p[0],p[1]);f=false;}gc.stroke();}
}
function drawWhirl(t){
  [{rx:96,ry:20,sp:0.22},{rx:96,ry:36,sp:-0.16},{rx:96,ry:11,sp:0.38}].forEach((r,i)=>{
    gc.save();gc.translate(CX,CY);gc.rotate(t*r.sp+i*1.1);
    gc.beginPath();gc.ellipse(0,0,r.rx,r.ry,0,0,Math.PI*2);
    gc.strokeStyle=`rgba(10,10,10,${0.11+i*0.025})`;gc.lineWidth=0.65;gc.setLineDash([2,6]);gc.stroke();gc.setLineDash([]);gc.restore();
  });
  for(let i=0;i<36;i++){
    const a=(i/36)*Math.PI*2+t*0.48,px=CX+97*Math.cos(a),py=CY+97*Math.sin(a)*0.2,d=(Math.cos(a)+1)/2;
    gc.beginPath();gc.arc(px,py,0.7+d*1.2,0,Math.PI*2);gc.fillStyle=`rgba(10,10,10,${0.05+d*0.3})`;gc.fill();
  }
}
function drawOffices(el){
  if(el<1500)return;
  const gf=Math.min(1,(el-1500)/1200);
  OFFICES.forEach(city=>{
    const p=project(city.lon,city.lat,rot);if(!p||p[2]<0.08)return;
    const d=p[2],op=gf*(0.25+d*0.75),pulse=(Math.sin(el*0.005+city.lon*0.1)+1)/2;
    if(city.isTarget){
      gc.beginPath();gc.arc(p[0],p[1],9+pulse*5,0,Math.PI*2);gc.strokeStyle=`rgba(196,30,36,${op*0.2})`;gc.lineWidth=1;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],5+pulse*2.5,0,Math.PI*2);gc.strokeStyle=`rgba(196,30,36,${op*0.42})`;gc.lineWidth=0.9;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],3,0,Math.PI*2);gc.fillStyle=`rgba(196,30,36,${op})`;gc.fill();
    }else{
      gc.beginPath();gc.arc(p[0],p[1],4+pulse*3,0,Math.PI*2);gc.strokeStyle=`rgba(42,95,255,${op*0.25})`;gc.lineWidth=0.7;gc.stroke();
      gc.beginPath();gc.arc(p[0],p[1],1.8,0,Math.PI*2);gc.fillStyle=`rgba(42,95,255,${op})`;gc.fill();
    }
    if(d>0.32&&el>2500){
      const lf=Math.min(1,(el-2500)/800)*Math.min(1,(d-0.32)/0.28)*op;
      if(lf>0.04){
        gc.save();gc.font=`${city.isTarget?'bold ':''}7px Georgia,serif`;
        const w=gc.measureText(city.name).width,lx=p[0]+(p[0]<CX?5:-(w+4));
        gc.fillStyle=city.isTarget?`rgba(196,30,36,${lf})`:`rgba(22,32,70,${lf})`;
        gc.fillText(city.name,lx,p[1]+3);gc.restore();
      }
    }
  });
}
function frame(){
  if(done)return;
  const el=performance.now()-T0;
  if(el<12000){rot+=0.5;}else{const t=Math.min(1,(el-12000)/3000),e=1-Math.pow(1-t,3);rot=360+87.63*e;}
  gc.clearRect(0,0,200,200);
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle='#eeede6';gc.fill();
  const atm=gc.createRadialGradient(CX-20,CY-20,R*0.7,CX,CY,R);
  atm.addColorStop(0,'rgba(255,255,255,0.12)');atm.addColorStop(1,'rgba(160,160,140,0.1)');
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle=atm;gc.fill();
  gc.save();gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.clip();
  gc.strokeStyle='rgba(0,0,0,0.06)';gc.lineWidth=0.4;drawGrat(rot);
  gc.fillStyle='#1e1e1e';gc.strokeStyle='#eeede6';gc.lineWidth=0.6;
  for(const poly of POLYS){drawPoly(poly,rot);gc.fill();gc.stroke();}
  const vig=gc.createRadialGradient(CX+R*0.3,CY-R*0.3,0,CX,CY,R);
  vig.addColorStop(0,'rgba(238,237,230,0)');vig.addColorStop(0.75,'rgba(238,237,230,0)');vig.addColorStop(1,'rgba(180,175,160,0.28)');
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.fillStyle=vig;gc.fill();
  drawOffices(el);gc.restore();
  gc.beginPath();gc.arc(CX,CY,R,0,Math.PI*2);gc.strokeStyle='rgba(0,0,0,0.1)';gc.lineWidth=1;gc.stroke();
  drawWhirl(rot*Math.PI/180);
  if(el>15000&&!zoomFired){
    const cp=project(-87.63,41.88,rot);
    if(cp&&cp[2]>0.2){
      zoomFired=true;
      const li=document.getElementById('inner');
      li.style.transition='transform 1.4s cubic-bezier(0.16,1,0.3,1)';
      li.style.transformOrigin=cp[0]+'px '+cp[1]+'px';
      li.style.transform='scale(5.5)';
      document.getElementById('brand').style.opacity='0';
    }
  }
  if(el>16800){advance();return;}
  requestAnimationFrame(frame);
}
function advance(){
  if(done)return;
  done=true;
  window.parent.postMessage({type:'streamlit:setComponentValue',value:true},'*');
}
frame();
setTimeout(()=>{const b=document.getElementById('brand');if(b)b.style.opacity='1';},1000);
setTimeout(()=>{const s=document.getElementById('skip');if(s)s.style.opacity='1';},2000);
</script>
</body>
</html>"""

# ── Data loaders ───────────────────────────────────────────────────────────────

@st.cache_data
def load_extracted():
    return pd.read_csv(str(EXTRACTED_CSV)) if EXTRACTED_CSV.exists() else pd.DataFrame()

@st.cache_data
def load_esg():
    return pd.read_csv(str(ESG_CSV)) if ESG_CSV.exists() else pd.DataFrame()

@st.cache_data
def load_validation():
    return pd.read_csv(str(VALIDATION_CSV)) if VALIDATION_CSV.exists() else pd.DataFrame()

@st.cache_data
def load_fitch_factors():
    return pd.read_csv(str(FITCH_FACTORS_CSV)) if FITCH_FACTORS_CSV.exists() else pd.DataFrame()

@st.cache_data
def load_forward_looking():
    return pd.read_csv(str(FORWARD_LOOKING_CSV)) if FORWARD_LOOKING_CSV.exists() else pd.DataFrame()

@st.cache_data
def load_regulatory_gaps():
    if not REGULATORY_GAPS_CSV.exists():
        return pd.DataFrame()
    df = pd.read_csv(str(REGULATORY_GAPS_CSV))
    if "doc_name" in df.columns and "doc" not in df.columns:
        df = df.rename(columns={"doc_name": "doc"})
    return df


# ── Company label system ──────────────────────────────────────────────────────
# Stores {filename: "Company Name"} in outputs/doc_labels.json
# Displayed everywhere as "Company Name  (filename.pdf)"

_DOC_LABELS_PATH = OUTPUT_DIR / "doc_labels.json"

def _load_labels() -> dict:
    """Load the filename → company name mapping from disk."""
    if _DOC_LABELS_PATH.exists():
        try:
            return json.loads(_DOC_LABELS_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def _save_labels(labels: dict) -> None:
    _DOC_LABELS_PATH.write_text(json.dumps(labels, indent=2, ensure_ascii=False), encoding="utf-8")

_TICKER_TO_COMPANY: dict[str, str] = {
    # Common tickers that appear as filenames (e.g. "rivn-20241231.pdf")
    "rivn": "Rivian",    "tsla": "Tesla",      "aapl": "Apple",
    "msft": "Microsoft", "googl": "Alphabet",  "goog": "Alphabet",
    "amzn": "Amazon",    "meta": "Meta",        "nvda": "NVIDIA",
    "nflx": "Netflix",   "hood": "Robinhood",   "orcl": "Oracle",
    "gs": "Goldman Sachs","jpm": "JPMorgan",    "bac": "Bank of America",
    "c": "Citigroup",    "wfc": "Wells Fargo",  "ms": "Morgan Stanley",
    "xom": "ExxonMobil", "cvx": "Chevron",      "bp": "BP",
    "shel": "Shell",     "tot": "TotalEnergies","enph": "Enphase",
    "sedg": "SolarEdge", "rwe": "RWE",          "orsted": "Ørsted",
    "nee": "NextEra Energy", "duk": "Duke Energy", "so": "Southern Company",
    "pseg": "PSEG",      "eog": "EOG Resources","oxy": "Occidental",
    "lmt": "Lockheed Martin","ba": "Boeing",    "ge": "GE",
    "hon": "Honeywell",  "cat": "Caterpillar",  "de": "Deere",
    "f": "Ford",         "gm": "General Motors","lcid": "Lucid Motors",
    "wkhs": "Workhorse", "nkla": "Nikola",      "hyln": "Hyliion",
    "plug": "Plug Power","fcel": "FuelCell",    "be": "Bloom Energy",
    "spwr": "SunPower",  "run": "Sunrun",       "nova": "Sunnova",
    "psx": "Phillips 66","mpc": "Marathon",     "vlo": "Valero",
    "amc": "AMC",        "gme": "GameStop",     "ubs": "UBS",
    "cs": "Credit Suisse","db": "Deutsche Bank","bnp": "BNP Paribas",
    "ing": "ING",        "axa": "AXA",          "alv": "Allianz",
    "mcd": "McDonald's", "sbux": "Starbucks",   "ko": "Coca-Cola",
    "pep": "PepsiCo",    "pg": "Procter & Gamble","jnj": "Johnson & Johnson",
    "pfe": "Pfizer",     "mrk": "Merck",        "abbv": "AbbVie",
    "lly": "Eli Lilly",  "bmy": "Bristol-Myers","amgn": "Amgen",
    "gild": "Gilead",    "biib": "Biogen",      "regn": "Regeneron",
}

_DOMAIN_TO_COMPANY: dict[str, str] = {
    # Compound domain names that don't split cleanly
    "lucidmotors": "Lucid Motors",        "rivianautomotive": "Rivian",
    "nexteraenergy": "NextEra Energy",     "dominionenergy": "Dominion Energy",
    "sempraenergy": "Sempra Energy",       "firstsolar": "First Solar",
    "sunpower": "SunPower",                "sunnova": "Sunnova",
    "sunrun": "Sunrun",                    "plugpower": "Plug Power",
    "fuelcell": "FuelCell Energy",         "bloomenergyco": "Bloom Energy",
    "fiskerinc": "Fisker",                 "niousa": "NIO",
    "workhorse": "Workhorse Group",        "hyliion": "Hyliion",
    "canoo": "Canoo",                      "electrameccanica": "Electra Meccanica",
    "irontain": "Iron Mountain",           "americanexpress": "American Express",
    "goldmansachs": "Goldman Sachs",       "morganstanley": "Morgan Stanley",
    "bankofamerica": "Bank of America",    "wellsfargo": "Wells Fargo",
    "citigroup": "Citigroup",              "deutschebank": "Deutsche Bank",
    "creditsuisse": "Credit Suisse",       "bnpparibas": "BNP Paribas",
    "mcdonalds": "McDonald's",             "cocacola": "Coca-Cola",
    "pepsico": "PepsiCo",                  "johnsondandjohnson": "Johnson & Johnson",
    "bristolmyers": "Bristol-Myers Squibb","exxonmobil": "ExxonMobil",
    "chevron": "Chevron",                  "conocophillips": "ConocoPhillips",
    "totalenergies": "TotalEnergies",
}

_TLDS = {"com","net","org","io","co","uk","de","fr","nl","jp","cn","au",
         "gov","edu","info","biz","eu","int","mil","mobi","name","pro","tel","travel"}

def _extract_company_from_domain(host: str) -> str | None:
    """Pull a clean company name from a hostname like 'ir.lucidmotors.com'."""
    skip = {"ir", "www", "investor", "investors", "relations",
            "corporate", "media", "static", "files", "s3", "sec", "cdn"}
    parts = [p for p in host.lower().replace("www.", "").split(".")
             if p not in skip and p not in _TLDS and p]
    for part in reversed(parts):
        if part in _DOMAIN_TO_COMPANY:
            return _DOMAIN_TO_COMPANY[part]
        if part in _TICKER_TO_COMPANY:
            return _TICKER_TO_COMPANY[part]
        if len(part) >= 3 and not _re.fullmatch(r"[\da-f\-]+", part):
            return part.replace("-", " ").title()
    return None

def _auto_name(doc: str) -> str:
    """Best-effort company name extraction from a PDF filename or URL."""
    name = doc

    # ── Handle proper https:// URLs ──────────────────────────────────────────
    if _re.match(r"https?://", name, _re.IGNORECASE):
        try:
            from urllib.parse import urlparse
            host = urlparse(name).hostname or ""
            result = _extract_company_from_domain(host)
            if result:
                return result
        except Exception:
            pass

    # ── Handle colon-encoded URLs (filename stored as "https:domain:path") ──
    # When a URL is used as a filename, "/" is replaced with ":" on some systems.
    if _re.match(r"https?:[^/]", name, _re.IGNORECASE) and "://" not in name:
        try:
            parts = name.split(":")
            # parts[1] is usually the hostname, e.g. "ir.tesla.com"
            host = parts[1].strip().lower() if len(parts) >= 2 else ""
            result = _extract_company_from_domain(host)
            if result:
                return result
            # Fallback: look for a known ticker in the last colon-segment
            last = parts[-1].replace(".pdf", "").replace(".PDF", "")
            m = _re.match(r"([a-zA-Z]{2,6})", last)
            if m:
                t = m.group(1).lower()
                if t in _TICKER_TO_COMPANY:
                    return _TICKER_TO_COMPANY[t]
        except Exception:
            pass
    for ext in (".pdf", ".PDF", ".html", ".HTML"):
        name = name.replace(ext, "")
    # Strip leading numeric ID like "82_" or "3324_"
    name = _re.sub(r"^\d+_", "", name)
    # Remove exchange prefixes like "nasdaq-", "nyse-"
    name = _re.sub(r"^(nasdaq|nyse|lse|tsx|xetra|euronext)[-_]", "", name, flags=_re.IGNORECASE)
    # Remove common boilerplate words / filing types
    for phrase in [
        "Consolidated Financial Statements", "Financial Statements",
        "Annual Report", "Annual report", "annual report", "annual-report",
        "Sustainability Report", "sustainability-report",
        "Integrated Report", "integrated-report",
        "FinExtract Report", "FinExtract_Report",
        "Annual_Report", "annual_report",
        "Financial_Statements", "financial-statements",
        "10-K", "10K", "20-F", "20F", "6-K", "6K",
        "IFRS", "ifrs", "-en", "_en",
        "URD", "urd",          # French annual report
        "PDF", "Final", "Gen", "gen",
        "Consolidated", "consolidated",
        "Statements", "statements",
    ]:
        name = name.replace(phrase, "").replace(phrase.upper(), "").replace(phrase.lower(), "")
    # Remove year tokens and parenthetical date notes
    name = _re.sub(r"\s*\([^)]*\)", "", name)
    name = _re.sub(r"\b(19|20)\d{2}\b", "", name)
    # Remove long numeric / UUID-style sequences (7+ digits or hex UUIDs)
    name = _re.sub(r"[-_ ]?\b[\da-fA-F]{7,}\b", "", name)
    name = _re.sub(r"[-_]?\d{7,}", "", name)
    # Remove trailing version/edition markers like "BD_0", "VA", "Q1"
    name = _re.sub(r"[-_ ]+(?:BD|VA|Q[1-4]|v\d+|Vol\d*)[-_ ]*\d*\s*$", "", name, flags=_re.IGNORECASE)
    # Remove remaining isolated numbers (e.g. "9 26 25" from Oracle-PDF-Final-9-26-25)
    name = _re.sub(r"\b\d{1,4}\b", "", name)
    # Replace separators with spaces
    name = _re.sub(r"[-_]+", " ", name)
    name = " ".join(name.split()).strip(" '\".,")

    # Drop generic/connector words throughout (not just edges)
    generic = {"report", "annual", "financial", "statements", "consolidated",
               "sustainability", "integrated", "final", "pdf", "gen", "doc",
               "and", "or", "the", "of", "for", "en", "va", "bd"}
    words = [w for w in name.split() if w.lower() not in generic]
    name = " ".join(words).strip()

    # Check if what remains is a known ticker / compound domain name
    if name.lower() in _TICKER_TO_COMPANY:
        return _TICKER_TO_COMPANY[name.lower()]
    if name.lower() in _DOMAIN_TO_COMPANY:
        return _DOMAIN_TO_COMPANY[name.lower()]

    # If it looks like all lowercase or all uppercase, title-case it
    if name and (name == name.lower() or name == name.upper()):
        name = name.title()
    # Preserve known legal-entity suffixes uppercase (AG, PLC, SA, NV, BCR, etc.)
    name = _re.sub(r"\b(ag|plc|sa|nv|bv|llc|ltd|inc|corp|se|ab)\b",
                   lambda m: m.group(0).upper(), name, flags=_re.IGNORECASE)
    # If every word is a single letter or short uppercase acronym, keep as-is
    # Otherwise strip stray single letters (e.g. trailing "k" from "10-k")
    cleaned_words = [w for w in name.split() if len(w) > 1 or w.isupper()]
    name = " ".join(cleaned_words).strip()
    return name if len(name) >= 2 else doc[:30]

def _get_name(doc: str, labels: dict | None = None) -> str:
    """Return just the company name (for chart axis labels)."""
    if labels is None:
        labels = _load_labels()
    return labels.get(doc) or _auto_name(doc)

def _get_label(doc: str, labels: dict | None = None) -> str:
    """Return 'Company Name  (filename.pdf)' for dropdowns and tables."""
    name = _get_name(doc, labels)
    short_file = doc if len(doc) <= 30 else doc[:27] + "…"
    return f"{name}  ({short_file})"

def _apply_labels(df: pd.DataFrame, labels: dict | None = None, col: str = "doc") -> pd.DataFrame:
    """Add a doc_short column using the company label system."""
    if labels is None:
        labels = _load_labels()
    df = df.copy()
    df["doc_short"] = df[col].apply(lambda d: _get_name(d, labels))
    return df

def _ensure_labels(docs: list[str]) -> dict:
    """Auto-populate missing entries and return updated labels dict."""
    labels = _load_labels()
    changed = False
    for doc in docs:
        if doc not in labels:
            labels[doc] = _auto_name(doc)
            changed = True
    if changed:
        _save_labels(labels)
    return labels


def _fitch_score_badge(score: int) -> str:
    """Return HTML badge for a Fitch factor score 1-5."""
    labels = {1: "None", 2: "Minimal", 3: "Partial", 4: "Good", 5: "Best"}
    cls = f"fitch-{max(1, min(5, int(score)))}"
    return f'<span class="fitch-cell {cls}">{score} — {labels.get(score, "")}</span>'


def _mini_fitch_heatmap(factors: list[dict]) -> str:
    """Render a compact 3-column (E/S/G) factor heat map as HTML."""
    if not factors:
        return "<p style='color:var(--muted)'>No Fitch data yet</p>"
    by_dim: dict[str, list] = {"E": [], "S": [], "G": []}
    for f in factors:
        dim = f.get("dimension", "E")
        if dim in by_dim:
            by_dim[dim].append(f)
    cols_html = ""
    dim_labels = {"E": "🌱 Environmental", "S": "👥 Social", "G": "🏛 Governance"}
    for dim, label in dim_labels.items():
        rows = by_dim.get(dim, [])
        cells = ""
        for f in rows:
            sc = int(f.get("score", 1))
            cls = f"fitch-{sc}"
            cells += (
                f'<div style="display:flex;justify-content:space-between;align-items:center;'
                f'margin:3px 0;padding:4px 8px;border-radius:5px;background:var(--surface-alt)">'
                f'<span style="font-size:12px;color:var(--text)">{f.get("name","")}</span>'
                f'<span class="fitch-cell {cls}" style="font-size:11px;padding:2px 7px">{sc}/5</span>'
                f'</div>'
            )
        cols_html += (
            f'<div style="flex:1;min-width:160px;padding:0 6px">'
            f'<div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;'
            f'font-weight:600;margin-bottom:6px">{label}</div>{cells}</div>'
        )
    return f'<div style="display:flex;gap:8px;flex-wrap:wrap">{cols_html}</div>'

# ── Globe splash gate ─────────────────────────────────────────────────────────
if "globe_done" not in st.session_state:
    st.session_state.globe_done = True  # skip globe until nav is stable

if not st.session_state.globe_done:
    # Blast the globe into true full-viewport by making the component iframe position:fixed
    st.markdown("""<div style="display:none"><style>
    [data-testid="stSidebar"]{display:none!important}
    [data-testid="stToolbar"],[data-testid="stDecoration"],[data-testid="stHeader"]{display:none!important}
    footer{display:none!important}
    .main{padding:0!important}
    .main .block-container{padding:0!important;max-width:100vw!important;margin:0!important}
    /* Make the component iframe fill the entire browser window */
    [data-testid="stCustomComponentV1"]{
        position:fixed!important;top:0!important;left:0!important;
        width:100vw!important;height:100vh!important;
        z-index:999999!important;border:none!important;
    }
    [data-testid="stCustomComponentV1"] iframe{
        width:100%!important;height:100%!important;border:none!important;
    }
    </style></div>""", unsafe_allow_html=True)

    val = _stc.html(_GLOBE_HTML, height=800, scrolling=False)
    if val:
        st.session_state.globe_done = True
        st.rerun()
    st.stop()

# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    # Fitch Ratings logo
    # ── Brand header ─────────────────────────────────────────────
    st.markdown("""
    <div style="padding:20px 20px 16px;border-bottom:1px solid rgba(255,255,255,0.055)">
      <svg viewBox="0 0 248 38" xmlns="http://www.w3.org/2000/svg" style="display:block;width:100%;max-width:204px;height:auto;margin-bottom:8px">
        <text y="32" font-family="Georgia,'Times New Roman',serif" font-weight="700" font-size="36" fill="#c41e24" letter-spacing="-1">Fitch</text>
        <text x="100" y="32" font-family="Georgia,'Times New Roman',serif" font-weight="400" font-size="36" fill="#4a5a6b" letter-spacing="-0.5">Ratings</text>
      </svg>
      <div style="font-size:10px;font-weight:500;letter-spacing:1.4px;text-transform:uppercase;color:#6b7a96;margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.055)">
        FinExtract Analytics <span style="color:#8b97af">· Segment Extraction Engine</span>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Page state ────────────────────────────────────────────────
    if "page" not in st.session_state:
        st.session_state.page = "Document Intake"

    _ext_df = load_extracted()
    _doc_count = _ext_df["doc"].nunique() if not _ext_df.empty and "doc" in _ext_df.columns else 0

    # ── Nav buttons (native st.button — reliable, no component slots)
    _NAV = [
        ("Intake", [
            ("Document Intake",    "M7.25 10V2.75L4.75 5.25 3.5 4 8 0l4.5 4-1.25 1.25L8.75 2.75V10h-1.5zM2 10.5v4h12v-4H15.5V15A1.5 1.5 0 0114 16.5H2A1.5 1.5 0 01.5 15v-4.5H2z"),
            ("Company Search",     "M10.5 7A3.5 3.5 0 117 3.5 3.5 3.5 0 0110.5 7zm-1.09 2.909a5 5 0 111.5-1.5l3.34 3.34-1.5 1.5-3.34-3.34z"),
            ("Analyst Intelligence","M2 3a1 1 0 011-1h10a1 1 0 011 1v6a1 1 0 01-1 1H9l-3 3v-3H3a1 1 0 01-1-1V3z"),
        ]),
        ("Analysis", [
            ("Portfolio Overview",  "M1 1h6v6H1zm8 0h6v6H9zM1 9h6v6H1zm8 0h6v6H9z"),
            ("ESG & Fitch Factors", "M8 1a7 7 0 100 14A7 7 0 008 1zm.75 8.75H7.25V5h1.5v4.75zm0 2.25H7.25v-1.5h1.5V12z"),
            ("Regulatory Mapping",  "M8 0l6 4v2H2V4L8 0zM2 7h12v8H2V7zm3.5 2v4h5V9h-5z"),
            ("Portfolio Analytics", "M1 12L5.5 5 9 9l2.5-3.5L15 12H1z"),
        ]),
        ("Tools", [
            ("Document Key",        "M4.5 0A1.5 1.5 0 003 1.5v13A1.5 1.5 0 004.5 16h7a1.5 1.5 0 001.5-1.5V4.5L9.5 0H4.5zM5 5h6v1H5zm0 2h6v1H5zm0 2h6v1H5zm0 2h4v1H5z"),
            ("NACE Classification", "M8 5a3 3 0 100 6 3 3 0 000-6zm-7 3a7 7 0 1114 0A7 7 0 011 8z"),
            ("Generate Report",     "M4.5 0A1.5 1.5 0 003 1.5v13A1.5 1.5 0 004.5 16h7a1.5 1.5 0 001.5-1.5V4.5L9.5 0H4.5zM5 8h6v1H5zm0 2h6v1H5zm0 2h4v1H5z"),
            ("Accuracy Validation", "M14 2.5l-8 8-4-4L.5 8l5.5 5.5 9.5-9.5L14 2.5z"),
        ]),
    ]

    st.markdown("""<style>
/* Nav button reset */
[data-testid="stSidebar"] [data-testid="stBaseButton-secondary"]{
  display:flex!important;align-items:center!important;
  width:100%!important;padding:9px 20px!important;
  border:none!important;border-radius:0!important;
  background:transparent!important;
  font-size:13px!important;font-weight:400!important;
  color:#dde4f0!important;text-align:left!important;
  justify-content:flex-start!important;letter-spacing:0.2px!important;
  transition:color .15s,background .15s!important;
  cursor:pointer!important;box-shadow:none!important;
  font-family:'Inter',system-ui,sans-serif!important;
  line-height:1.4!important;
}
[data-testid="stSidebar"] [data-testid="stBaseButton-secondary"]:hover{
  color:#dde4f0!important;background:rgba(255,255,255,0.04)!important;
}
/* Active nav item */
[data-testid="stSidebar"] .nav-active [data-testid="stBaseButton-secondary"]{
  color:#ffffff!important;background:rgba(196,30,36,0.12)!important;
  border-left:2px solid #c41e24!important;padding-left:18px!important;
  font-weight:600!important;
}
/* Remove extra Streamlit button padding */
[data-testid="stSidebar"] .stButton{margin:0!important;padding:0!important}
</style>""", unsafe_allow_html=True)

    for group_label, items in _NAV:
        st.markdown(
            f'<div style="font-size:9px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;'
            f'color:#6b7a96;padding:14px 20px 5px;display:block">{group_label}</div>',
            unsafe_allow_html=True
        )
        for label, icon_path in items:
            is_active = st.session_state.page == label
            count_badge = f' <span style="margin-left:auto;font-size:10px;color:#6b7a96;font-family:monospace">{_doc_count}</span>' if label == "Portfolio Overview" and _doc_count else ""
            icon_svg = f'<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" style="flex-shrink:0;margin-right:10px;opacity:{"0.85" if is_active else "0.55"}"><path fill-rule="evenodd" d="{icon_path}"/></svg>'
            btn_html = f'<div class="{"nav-active" if is_active else ""}">'
            st.markdown(btn_html, unsafe_allow_html=True)
            if st.button(f"{label}", key=f"nav_{label}"):
                st.session_state.page = label
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)

    page = st.session_state.page

    st.html("""
<div style="padding:10px 20px 14px;border-top:1px solid rgba(255,255,255,0.055)">
  <div style="font-size:9px;font-weight:600;letter-spacing:1.3px;text-transform:uppercase;color:#6b7a96;margin-bottom:6px">Engine status</div>
  <div style="display:flex;align-items:center;gap:8px">
    <svg viewBox="0 0 100 14" xmlns="http://www.w3.org/2000/svg" style="flex:1;height:14px;overflow:visible">
      <polyline points="0,10 5,7 10,9 15,5 20,8 25,4 30,6 35,3 40,5 45,2 50,4 55,1 60,3 65,2 70,1 75,3 80,1 85,2 90,1 95,2 100,1"
        fill="none" stroke="rgba(196,30,36,0.55)" stroke-width="1.2" stroke-linejoin="round"/>
      <circle cx="100" cy="1" r="2.5" fill="#c41e24"/>
    </svg>
    <span style="font-size:9px;color:#2d9e6b;font-family:monospace;white-space:nowrap">Active</span>
  </div>
</div>""")

    # ── Persistent context indicator ──────────────────────────────────────────
    _ctx_company = st.session_state.get("current_company", "")
    _ctx_segs = st.session_state.get("last_segments", [])
    _ctx_esg = st.session_state.get("last_esg", {})
    _ctx_period = st.session_state.get("last_period", "")
    _ctx_currency = st.session_state.get("last_currency", "")
    _ctx_fitch = st.session_state.get("last_fitch", [])
    _ctx_fwd = st.session_state.get("last_fwd", {})
    _ctx_reg = st.session_state.get("last_reg", {})

    _esg_comp = _ctx_esg.get("composite", _ctx_esg.get("esg_composite", 0)) if _ctx_esg else 0
    _seg_count = len(_ctx_segs)
    _conf_val = _ctx_esg.get("confidence", 0) if _ctx_esg else 0

    if _ctx_company or _ctx_segs:
        _display_name = _get_name(_ctx_company) if _ctx_company else "Active document"
        st.html(f"""
<div style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.055);background:rgba(0,0,0,0.15)">
  <div style="font-size:9px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:#6b7a96;margin-bottom:10px">Active document</div>
  <div style="font-family:'Playfair Display',Georgia,serif;font-size:13px;font-weight:500;color:#bdc7da;margin-bottom:3px;display:flex;align-items:center;gap:7px">
    <span class="ctx-live-dot"></span>{_display_name[:28]}
  </div>
  <div style="font-size:11px;color:#6b7a96;margin-bottom:10px;font-family:'JetBrains Mono',monospace">
    {_ctx_period or '—'} &middot; {_ctx_currency or '—'}
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px">
    <div style="background:#0c1428;border:1px solid rgba(255,255,255,0.07);padding:8px 10px">
      <div style="font-size:18px;font-weight:600;font-family:'JetBrains Mono',monospace;color:#bdc7da;line-height:1">{_seg_count}</div>
      <div style="font-size:9px;letter-spacing:0.8px;text-transform:uppercase;color:#6b7a96;margin-top:3px">Segments</div>
    </div>
    <div style="background:#0c1428;border:1px solid rgba(255,255,255,0.07);padding:8px 10px">
      <div style="font-size:18px;font-weight:600;font-family:'Playfair Display',Georgia,serif;color:#c41e24;line-height:1">{f"{_esg_comp:.0f}" if _esg_comp else "—"}</div>
      <div style="font-size:9px;letter-spacing:0.8px;text-transform:uppercase;color:#6b7a96;margin-top:3px">ESG Score</div>
    </div>
    <div style="background:#0c1428;border:1px solid rgba(255,255,255,0.07);padding:8px 10px">
      <div style="font-size:14px;font-weight:600;font-family:'JetBrains Mono',monospace;color:#2d9e6b;line-height:1">{"&check;" if _ctx_fitch else "—"}</div>
      <div style="font-size:9px;letter-spacing:0.8px;text-transform:uppercase;color:#6b7a96;margin-top:3px">Fitch ({len(_ctx_fitch)}F)</div>
    </div>
    <div style="background:#0c1428;border:1px solid rgba(255,255,255,0.07);padding:8px 10px">
      <div style="font-size:14px;font-weight:600;font-family:'JetBrains Mono',monospace;color:{"#2d9e6b" if _ctx_reg else "#6b7a96"};line-height:1">{"&check;" if _ctx_reg else "—"}</div>
      <div style="font-size:9px;letter-spacing:0.8px;text-transform:uppercase;color:#6b7a96;margin-top:3px">Regulatory</div>
    </div>
  </div>
</div>""")
    else:
        st.html("""
<div style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.055);background:rgba(0,0,0,0.15)">
  <div style="font-size:9px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:#6b7a96;margin-bottom:8px">Active document</div>
  <div style="font-size:11px;color:#8b97af;font-style:italic">No document loaded</div>
  <div style="font-size:10px;color:#6b7a96;margin-top:4px">Upload a PDF to begin analysis</div>
</div>""")

    st.html("""
<div style="padding:12px 20px;border-top:1px solid rgba(255,255,255,0.055)">
  <div style="font-size:10px;color:#6b7a96;display:flex;align-items:center;gap:6px;margin-bottom:3px">
    <span style="width:4px;height:4px;border-radius:50%;background:#2d9e6b;flex-shrink:0;display:inline-block"></span>
    Claude Sonnet 4.6 &middot; Haiku 4.5
  </div>
  <div style="font-size:10px;color:#4a5a6b">NACE Rev 2.1 &middot; Fitch ESG &middot; CSRD &middot; TCFD</div>
</div>""")

# ─────────────────────────────────────────────────────────────────────────────
# PAGE 1 — Upload & Analyse
# ─────────────────────────────────────────────────────────────────────────────

def run_on_file(pdf_path: Path, force_page: int = None, on_step=None) -> dict:
    """Run the full pipeline on a single PDF and return the result dict."""
    from pipeline import process_one_pdf
    return process_one_pdf(pdf_path, verbose=False, force_page=force_page, on_step=on_step)


# ── Market data tickers ───────────────────────────────────────────────────────
# Curated list: ESG leaders, EV makers, major indices
_STOCK_TICKERS = [
    ("SPY",  "S&P 500"), ("QQQ",  "NASDAQ"),  ("TSLA", "Tesla"),
    ("RIVN", "Rivian"),  ("LCID", "Lucid"),   ("NIO",  "NIO"),
    ("NEE",  "NextEra"), ("ENPH", "Enphase"), ("XOM",  "Exxon"),
    ("MSFT", "Microsoft"), ("AAPL", "Apple"), ("GS",   "Goldman"),
]

@st.cache_data(ttl=3600, show_spinner=False)
def _lookup_ticker_symbol(company_name: str) -> str:
    """
    Use yfinance Search to resolve a company name → best stock ticker symbol.
    Returns the symbol string (e.g. 'LCID') or '' if not found.
    Cached for 1 hour since symbols don't change often.
    """
    if not company_name or len(company_name) < 2:
        return ""
    try:
        import yfinance as yf
        results = yf.Search(company_name, max_results=5).quotes
        for r in results:
            sym = r.get("symbol", "")
            q_type = r.get("quoteType", "")
            # Prefer equity, skip crypto/index/ETF
            if sym and q_type in ("EQUITY", ""):
                return sym
        return ""
    except Exception:
        return ""


@st.cache_data(ttl=60, show_spinner=False)
def _fetch_stock_prices() -> list[dict]:
    """Fetch live/last prices via yfinance. Cached 60 s."""
    try:
        import yfinance as yf
        symbols = " ".join(t[0] for t in _STOCK_TICKERS)
        data = yf.Tickers(symbols)
        results = []
        for sym, label in _STOCK_TICKERS:
            try:
                fi = data.tickers[sym].fast_info
                price = float(fi.last_price or 0)
                prev  = float(fi.previous_close or price)
                chg   = price - prev
                pct   = (chg / prev * 100) if prev else 0
                results.append({"sym": sym, "label": label,
                                 "price": price, "chg": chg, "pct": pct})
            except Exception:
                pass
        return results
    except Exception:
        return []


@st.cache_data(ttl=600, show_spinner=False)
def _fetch_market_news(issuer_name: str = "") -> list[dict]:
    """Fetch recent ESG/market headlines via DuckDuckGo. Cached 10 min."""
    try:
        from ddgs import DDGS
        headlines: list[dict] = []
        queries = ["ESG investing markets stocks 2025",
                   "clean energy electric vehicle earnings 2025"]
        # Prioritise news about the uploaded company if known
        if issuer_name:
            queries = [f"{issuer_name} stock earnings news 2025"] + queries
        for q in queries:
            with DDGS() as ddgs:
                for r in ddgs.news(q, max_results=6):
                    title  = (r.get("title")  or "").strip()
                    source = (r.get("source") or "").strip()
                    if title:
                        headlines.append({"title": title, "source": source})
        seen: set[str] = set()
        unique = []
        for h in headlines:
            if h["title"] not in seen:
                seen.add(h["title"])
                unique.append(h)
        return unique[:14]
    except Exception:
        return []


def _ticker():
    """Render the three-row live banner: stock prices · news headlines · ESG stats."""
    from datetime import datetime

    # ── Row 1: Stock prices ───────────────────────────────────────────────────
    stock_data = _fetch_stock_prices()

    # ── Issuer pin: fetch live price for the uploaded company ────────────────
    issuer_sym  = st.session_state.get("issuer_ticker", "")
    issuer_name = st.session_state.get("issuer_name", "")
    issuer_pin_html = ""

    if issuer_sym:
        try:
            import yfinance as yf
            fi = yf.Ticker(issuer_sym).fast_info
            i_price = float(fi.last_price or 0)
            i_prev  = float(fi.previous_close or i_price)
            i_chg   = i_price - i_prev
            i_pct   = (i_chg / i_prev * 100) if i_prev else 0
            i_arrow = "▲" if i_pct > 0 else ("▼" if i_pct < 0 else "■")
            i_cls   = "stock-chg-up" if i_pct > 0 else ("stock-chg-dn" if i_pct < 0 else "stock-chg-flat")
            i_price_fmt = f"{i_price:,.2f}" if i_price < 10_000 else f"{i_price:,.0f}"
            issuer_pin_html = (
                f'<span class="stock-item-issuer">'
                f'<span class="stock-issuer-badge">FILING</span>'
                f'<span class="stock-sym">{issuer_sym}</span>'
                f'<span class="stock-label">{issuer_name[:16]}</span>'
                f'<span class="stock-price">{i_price_fmt}</span>'
                f'<span class="{i_cls}">{i_arrow} {abs(i_pct):.2f}%</span>'
                f'</span>'
            )
        except Exception:
            issuer_pin_html = (
                f'<span class="stock-item-issuer">'
                f'<span class="stock-issuer-badge">FILING</span>'
                f'<span class="stock-sym">{issuer_sym}</span>'
                f'<span class="stock-label">{issuer_name[:16]}</span>'
                f'<span class="stock-price">—</span>'
                f'<span class="stock-chg-flat">— —%</span>'
                f'</span>'
            )

    if stock_data:
        def _stock_item(d: dict) -> str:
            price = d["price"]
            pct   = d["pct"]
            arrow = "▲" if pct > 0 else ("▼" if pct < 0 else "■")
            cls   = "stock-chg-up" if pct > 0 else ("stock-chg-dn" if pct < 0 else "stock-chg-flat")
            price_fmt = f"{price:,.2f}" if price < 10_000 else f"{price:,.0f}"
            return (
                f'<span class="stock-item">'
                f'<span class="stock-sym">{d["sym"]}</span>'
                f'<span class="stock-label">{d["label"]}</span>'
                f'<span class="stock-price">{price_fmt}</span>'
                f'<span class="{cls}">{arrow} {abs(pct):.2f}%</span>'
                f'</span>'
            )
        # Duplicate for seamless loop; issuer pin stays fixed at left
        stock_html = "".join(_stock_item(d) for d in stock_data) * 2
    else:
        # Graceful fallback if yfinance unavailable
        fallback = [
            ("SPY","S&P 500","—","stock-chg-flat"),("TSLA","Tesla","—","stock-chg-flat"),
            ("LCID","Lucid","—","stock-chg-flat"),("RIVN","Rivian","—","stock-chg-flat"),
            ("NEE","NextEra","—","stock-chg-flat"),("XOM","Exxon","—","stock-chg-flat"),
        ]
        def _fallback_item(sym, label, price, cls):
            return (f'<span class="stock-item">'
                    f'<span class="stock-sym">{sym}</span>'
                    f'<span class="stock-label">{label}</span>'
                    f'<span class="stock-price">{price}</span>'
                    f'<span class="{cls}">— —%</span></span>')
        stock_html = "".join(_fallback_item(*f) for f in fallback) * 2

    # ── Row 2: News headlines ─────────────────────────────────────────────────
    news_data = _fetch_market_news(issuer_name)

    if news_data:
        def _news_item(h: dict) -> str:
            src = f'<span class="news-source">  [{h["source"]}]</span>' if h.get("source") else ""
            title = h["title"].replace("<","&lt;").replace(">","&gt;")
            return (
                f'<span class="news-item">'
                f'<span class="news-bullet">◆</span>'
                f'<span class="news-headline">{title}</span>'
                f'{src}'
                f'</span>'
            )
        news_html = "".join(_news_item(h) for h in news_data) * 2
    else:
        placeholders = [
            "ESG disclosure requirements tighten under CSRD 2025 reporting cycle",
            "EV sector faces margin pressure amid battery cost volatility",
            "TCFD alignment becomes mandatory for FTSE 100 from fiscal 2026",
            "Fitch Ratings upgrades clean-energy issuer outlook to Positive",
            "Carbon credit markets see record volumes ahead of COP30",
        ]
        news_html = "".join(
            f'<span class="news-item"><span class="news-bullet">◆</span>'
            f'<span class="news-headline">{p}</span></span>'
            for p in placeholders
        ) * 2

    # ── Row 3: ESG / app stats (original ticker) ──────────────────────────────
    esg_df  = load_esg()
    ext_df  = load_extracted()
    doc_count   = ext_df["doc"].nunique() if not ext_df.empty and "doc" in ext_df.columns else 0
    avg_esg     = f"{esg_df['composite'].mean():.1f}" if not esg_df.empty and "composite" in esg_df.columns else "—"
    gw_count    = int((esg_df.get("greenwashing_penalty", esg_df.get("greenwashing_flag", pd.Series([0]))) != 0).sum()) if not esg_df.empty else 0
    avg_conf_raw = ext_df["extraction_confidence"].mean() if not ext_df.empty and "extraction_confidence" in ext_df.columns else None
    avg_conf    = f"{avg_conf_raw:.0%}" if avg_conf_raw is not None else "—"
    currency_count = ext_df["currency"].nunique() if not ext_df.empty and "currency" in ext_df.columns else "—"
    last_run    = datetime.now().strftime("%H:%M UTC")

    def _stat(label, val, cls=""):
        span = f'<span class="ticker-{cls}">{val}</span>' if cls else f'<span>{val}</span>'
        return f'<span class="ticker-item">{label} {span}</span><span class="ticker-sep">·</span>'

    stats = (
        _stat("ESG Global Avg", avg_esg)
        + _stat("Documents", doc_count)
        + _stat("Greenwashing Flags", gw_count, "dn")
        + _stat("Avg Confidence", avg_conf)
        + _stat("Currencies", currency_count)
        + '<span class="ticker-item">NACE Rev 2.1 · Fitch ESG Methodology · CSRD · TCFD</span>'
        + f'<span class="ticker-sep">·</span>'
        + _stat("Last Run", last_run)
    )
    stats_items = stats * 2   # duplicate for seamless loop

    st.markdown(f"""
<div class="stock-bar">
  <div class="stock-bar-label">MARKETS</div>
  {issuer_pin_html}
  <div class="stock-scroll-track">
    <div class="stock-items">{stock_html}</div>
  </div>
</div>
<div class="news-bar">
  <div class="news-bar-label">LIVE&nbsp;NEWS</div>
  <div class="news-scroll-track">
    <div class="news-items">{news_html}</div>
  </div>
</div>
<div class="ticker-bar" style="margin-bottom:1.5rem">
  <div class="ticker-label">Live</div>
  <div class="ticker-scroll-track">
    <div class="ticker-items">{stats_items}</div>
  </div>
</div>
""", unsafe_allow_html=True)


def _page_header(title: str, subtitle: str = "", chips: list[tuple[str,str]] | None = None):
    """Render topbar breadcrumb + page header + tweaks panel."""
    chips_html = ""
    if chips:
        for label, cls in chips:
            chips_html += f'<span class="chip chip-{cls}" style="margin-left:8px">{label}</span>'
    st.markdown(f"""
    <div style="height:48px;background:rgba(4,7,15,0.7);backdrop-filter:blur(16px);
      border-bottom:1px solid rgba(255,255,255,0.055);
      padding:0 28px;display:flex;align-items:center;gap:8px;
      margin:0 -1rem 0 -1rem;position:sticky;top:0;z-index:20;">
      <span style="font-size:12px;color:#6b7a96">FinExtract</span>
      <span style="color:#4a5a6b;font-size:10px">/</span>
      <span style="font-size:12px;color:#8b97af">{title}</span>
      <div style="margin-left:auto;display:flex;align-items:center;gap:6px">
        <span class="fitch-attr"><span class="fitch-attr-dot"></span>Fitch ESG Methodology</span>
      </div>
    </div>
    <div style="margin-bottom:24px;display:flex;align-items:flex-start;justify-content:space-between;padding-top:24px">
      <div>
        <h1 style="font-family:'Playfair Display',Georgia,serif;font-size:22px;font-weight:500;letter-spacing:-0.3px;color:#bdc7da;margin:0">{title}</h1>
        {"<p style='font-size:12px;color:#6b7a96;margin-top:4px;max-width:480px;line-height:1.6'>"+subtitle+"</p>" if subtitle else ""}
      </div>
      <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;padding-top:2px">
        {chips_html}
      </div>
    </div>
    """, unsafe_allow_html=True)


def _show_manage_documents() -> None:
    """Collapsible panel for removing previously processed documents."""
    extracted = load_extracted()
    if extracted.empty:
        return
    docs = sorted(extracted["doc"].unique())
    labels = _load_labels()
    with st.expander(f"Manage processed documents  ({len(docs)} on file)", expanded=False):
        st.caption("Remove a document to delete its extracted data from all outputs.")
        for doc in docs:
            label = _get_name(doc, labels)
            c1, c2 = st.columns([5, 1])
            c1.markdown(f"**{label}**  <span style='font-size:11px;color:#6b7a96'>{doc}</span>", unsafe_allow_html=True)
            if c2.button("Remove", key=f"rm_{abs(hash(doc))}", type="secondary"):
                _remove_document(doc)
                st.rerun()


def page_upload():
    _ticker()
    _page_header(
        "Document Intake",
        "Submit annual reports, integrated reports, or 10-K filings for Fitch-grade segment extraction and ESG assessment.",
        [("Engine Active", "green"), ("Claude Sonnet 4.6", "muted")],
    )
    # ── Upload grid (matches design two-column layout) ──
    col_upload, col_info = st.columns([62, 38])

    with col_upload:
        st.markdown("""
<div style="border:1px dashed rgba(255,255,255,0.10);background:var(--surface);
  padding:44px 32px;display:flex;flex-direction:column;align-items:center;
  justify-content:center;text-align:center;position:relative;overflow:hidden;min-height:220px">
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse 70% 60% at 50% 110%,var(--fitch-red-dim),transparent);pointer-events:none"></div>
  <div style="width:44px;height:44px;border:1px solid rgba(255,255,255,0.10);
    display:flex;align-items:center;justify-content:center;margin-bottom:14px;color:var(--fitch-red)">
    <svg viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
      <path d="M7.25 10V2.75L4.75 5.25 3.5 4 8 0l4.5 4-1.25 1.25L8.75 2.75V10h-1.5zM2 10.5v4h12v-4H15.5V15A1.5 1.5 0 0114 16.5H2A1.5 1.5 0 01.5 15v-4.5H2z"/>
    </svg>
  </div>
  <div style="font-family:var(--font-serif);font-size:15px;font-weight:500;color:var(--text);margin-bottom:6px">Drag &amp; drop PDF filings here</div>
  <div style="font-size:12px;color:var(--text-2);line-height:1.6;max-width:280px">Annual reports, integrated reports, 10-K filings and financial statements in any language</div>
  <div style="font-size:10px;color:var(--text-3);margin-top:12px;letter-spacing:0.3px">PDF · No size limit · All major languages supported</div>
</div>
""", unsafe_allow_html=True)
        uploaded_files = st.file_uploader(
            "Upload PDFs",
            type=["pdf"],
            accept_multiple_files=True,
            label_visibility="collapsed",
        )

    with col_info:
        st.markdown("""
<div style="background:var(--surface);border:1px solid var(--border);padding:20px;height:100%">
  <div style="font-size:9px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:var(--text-3);margin-bottom:14px">Extraction Coverage</div>
  <div style="border-bottom:1px solid var(--border);padding:10px 0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="width:6px;height:6px;background:var(--fitch-red);border-radius:50%;flex-shrink:0;margin-top:4px"></div>
      <div><div style="font-size:12px;font-weight:500;color:var(--text)">Segment revenues</div>
        <div style="font-size:10px;color:var(--text-2);margin-top:2px">Business unit breakdowns, value labels, eliminations</div></div>
    </div>
  </div>
  <div style="border-bottom:1px solid var(--border);padding:10px 0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="width:6px;height:6px;background:var(--gold);border-radius:50%;flex-shrink:0;margin-top:4px"></div>
      <div><div style="font-size:12px;font-weight:500;color:var(--text)">Currency normalisation</div>
        <div style="font-size:10px;color:var(--text-2);margin-top:2px">ISO codes, unit inference (mn / bn / k)</div></div>
    </div>
  </div>
  <div style="border-bottom:1px solid var(--border);padding:10px 0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="width:6px;height:6px;background:var(--blue);border-radius:50%;flex-shrink:0;margin-top:4px"></div>
      <div><div style="font-size:12px;font-weight:500;color:var(--text)">NACE Rev 2.1 classification</div>
        <div style="font-size:10px;color:var(--text-2);margin-top:2px">EU taxonomy industry tags per segment</div></div>
    </div>
  </div>
  <div style="border-bottom:1px solid var(--border);padding:10px 0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="width:6px;height:6px;background:var(--green);border-radius:50%;flex-shrink:0;margin-top:4px"></div>
      <div><div style="font-size:12px;font-weight:500;color:var(--text)">ESG + Fitch factor scoring</div>
        <div style="font-size:10px;color:var(--text-2);margin-top:2px">15-factor assessment with greenwashing detection</div></div>
    </div>
  </div>
  <div style="padding:10px 0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="width:6px;height:6px;background:var(--purple);border-radius:50%;flex-shrink:0;margin-top:4px"></div>
      <div><div style="font-size:12px;font-weight:500;color:var(--text)">Regulatory gap analysis</div>
        <div style="font-size:10px;color:var(--text-2);margin-top:2px">CSRD / ESRS, TCFD, EU Taxonomy alignment</div></div>
    </div>
  </div>
</div>
""", unsafe_allow_html=True)

    # ── Track which files are currently active in this upload session ────────
    # When files are uploaded, register them. When uploader is cleared (navigation
    # away), we still show the cached results until a NEW different file arrives.
    if uploaded_files:
        new_names = {f.name for f in uploaded_files}
        st.session_state["active_upload_names"] = list(new_names)

    active_names = st.session_state.get("active_upload_names", [])

    if not uploaded_files and not active_names:
        st.html('<div style="margin-top:20px;padding:14px 20px;background:var(--surface);border:1px solid var(--border);font-size:12px;color:var(--text-2)">No files uploaded yet — drag PDFs above or click Browse Files to begin.</div>')
        _show_manage_documents()
        return

    st.divider()

    # ── Save newly uploaded files to temp dir ─────────────────────────────────
    file_paths = {}
    if uploaded_files:
        tmp_dir = Path(tempfile.mkdtemp())
        for uploaded in uploaded_files:
            tmp_path = tmp_dir / uploaded.name
            tmp_path.write_bytes(uploaded.read())
            file_paths[uploaded.name] = tmp_path
            st.session_state[f"tmp_path_{uploaded.name}"] = str(tmp_path)
    else:
        # No live upload — reconstruct file_paths from cached tmp paths
        for fname in active_names:
            cached_path = st.session_state.get(f"tmp_path_{fname}", "")
            if cached_path and Path(cached_path).exists():
                file_paths[fname] = Path(cached_path)

    if not file_paths:
        st.info("Previous session files are no longer available. Please re-upload to continue.")
        _show_manage_documents()
        return

    # Per-file processing (with manual page override support)
    for name, tmp_path in file_paths.items():
        display_name = _get_name(name)
        st.markdown(f"### {display_name}")

        # Check if we already have a cached result in session state
        cache_key = f"result_{name}"
        force_key = f"force_page_{name}"

        if cache_key not in st.session_state:
            _STEP_ICONS = {
                "Scanning": "🔍",
                "Extracting segments": "📊",
                "NACE classification": "🏷️",
                "ESG scoring": "🌱",
                "Fitch factors": "📋",
                "Forward-looking intelligence": "🔭",
                "Regulatory alignment": "⚖️",
                "Complete": "✅",
            }
            with st.status(f"Analysing **{display_name}**…", expanded=True) as _status:
                _status_lines: list[str] = []

                def _on_step(label: str, detail: str = "") -> None:
                    icon = _STEP_ICONS.get(label, "⏳")
                    _status_lines.append(f"{icon} **{label}** — {detail}" if detail else f"{icon} **{label}**")
                    _status.update(label=f"{icon} {label}…", state="running")
                    # Show all completed steps so far
                    for ln in _status_lines[:-1]:
                        st.markdown(f"<span style='color:#3fb950;font-size:12px'>✔ {ln.replace('**','')}</span>", unsafe_allow_html=True)
                    st.markdown(f"<span style='color:#e3b341;font-size:12px'>⏳ {_status_lines[-1].replace('**','')}</span>", unsafe_allow_html=True)

                result = run_on_file(tmp_path, on_step=_on_step)
                n_segs = len(result.get("segments") or [])
                _status.update(
                    label=f"✅ {display_name} — {n_segs} segment{'s' if n_segs != 1 else ''} extracted",
                    state="complete",
                    expanded=False,
                )
            st.session_state[cache_key] = result

        result = st.session_state[cache_key]
        candidates = result.get("candidate_pages", [])

        # If extraction failed, show debug panel + manual override
        if result.get("error") and not result.get("segments"):
            st.error(f"Auto-extraction failed: {result['error']}")

            with st.expander("Debug: pages scanned", expanded=True):
                if candidates:
                    st.write(f"**Pages scanned:** {candidates}")
                    st.caption("The AI looked at these pages but didn't find a segment revenue table. "
                               "Check the PDF and enter the correct page number below.")
                else:
                    st.write("No pages scored high enough to scan. The document may use unusual terminology.")

                # Manual page override
                col_pg, col_btn = st.columns([2, 1])
                with col_pg:
                    page_num = st.number_input(
                        "Enter the exact page number containing segment revenue data",
                        min_value=1, max_value=2000, value=1, step=1,
                        key=f"pg_input_{name}"
                    )
                with col_btn:
                    st.write("")
                    st.write("")
                    if st.button(f"Extract from page {page_num}", key=f"force_btn_{name}"):
                        with st.spinner(f"Extracting from page {page_num}…"):
                            result = run_on_file(tmp_path, force_page=int(page_num))
                            st.session_state[cache_key] = result
                        st.rerun()

                # Show raw page text preview so analyst can find the right page
                st.divider()
                preview_page = st.number_input("Preview page text", min_value=1, max_value=2000,
                                               value=candidates[0] if candidates else 1,
                                               key=f"preview_{name}")
                if st.button("Show page text", key=f"preview_btn_{name}"):
                    txt = extract_text_from_page(tmp_path, int(preview_page))
                    st.text_area(f"Page {preview_page} text", txt[:3000], height=200)

            continue  # don't render result card for failed extraction

        # Persist successful result
        if result.get("segments"):
            _persist_result(result, name)
            st.cache_data.clear()
            # Cache for Chat + Company Search + Report pages
            st.session_state["last_segments"] = result["segments"]
            st.session_state["last_esg"] = result.get("esg") or {}
            st.session_state["last_fitch"] = result.get("fitch_factors") or []
            st.session_state["last_fwd"] = result.get("forward_looking") or {}
            st.session_state["last_reg"] = result.get("regulatory_gaps") or {}
            st.session_state["last_currency"] = result.get("currency", "")
            st.session_state["last_unit"] = result.get("unit", "")
            st.session_state["last_period"] = result.get("reporting_period", "")
            # Save the company name into doc_labels for cross-page use
            _existing_labels = _load_labels()
            auto = _auto_name(name)
            if name not in _existing_labels:
                _existing_labels[name] = auto
                _save_labels(_existing_labels)
            if not st.session_state.get("current_company"):
                st.session_state["current_company"] = _existing_labels.get(name, auto)
            # Look up the issuer's stock ticker symbol for the live price banner
            _company_for_lookup = _existing_labels.get(name, auto)
            if _company_for_lookup and not st.session_state.get("issuer_ticker"):
                _sym = _lookup_ticker_symbol(_company_for_lookup)
                if _sym:
                    st.session_state["issuer_ticker"] = _sym
                    st.session_state["issuer_name"] = _company_for_lookup
            # Cache source page text for View Source button
            src_pg = result.get("source_page", 1)
            src_key = f"src_text_{name}"
            if src_key not in st.session_state and str(src_pg).isdigit():
                try:
                    st.session_state[src_key] = extract_text_from_page(tmp_path, int(src_pg))
                except Exception:
                    pass

        _show_single_result(name, result)

        # Editable company name below result card
        labels_now = _load_labels()
        current_label = labels_now.get(name, _auto_name(name))
        new_label = st.text_input(
            "Company name for this filing",
            value=current_label,
            key=f"label_input_{abs(hash(name))}",
            help="This name is used across all pages instead of the PDF filename.",
        )
        st.caption(f"📎 File: {name}")
        if new_label and new_label != current_label:
            labels_now[name] = new_label
            _save_labels(labels_now)
            st.session_state["current_company"] = new_label


def _persist_result(result: dict, original_name: str):
    """Append new extraction to the main CSV files."""
    import pandas as pd

    company_name = _get_name(original_name)

    # Segments
    rows = []
    for seg in result.get("segments", []):
        rows.append({
            "company_name": company_name,
            "doc": original_name,
            "source_page": result.get("source_page", ""),
            "segment": seg.get("segment", ""),
            "value_label": seg.get("value_label", ""),
            "value": seg.get("value", ""),
            "is_total": seg.get("is_total", False),
            "currency": result.get("currency", ""),
            "unit": result.get("unit", ""),
            "reporting_period": result.get("reporting_period", ""),
            "extraction_confidence": result.get("extraction_confidence", ""),
            "extraction_notes": result.get("extraction_notes", ""),
            "nace_section": seg.get("nace_section", ""),
            "nace_division": seg.get("nace_division", ""),
            "nace_description": seg.get("nace_description", ""),
            "nace_confidence": seg.get("nace_confidence", ""),
        })
    if rows:
        new_df = pd.DataFrame(rows)
        if EXTRACTED_CSV.exists():
            existing = pd.read_csv(str(EXTRACTED_CSV))
            existing = existing[existing["doc"] != original_name]  # replace if already exists
            combined = pd.concat([existing, new_df], ignore_index=True)
        else:
            combined = new_df
        combined.to_csv(str(EXTRACTED_CSV), index=False)

    # ESG
    esg = result.get("esg")
    if esg:
        esg_row = dict(esg)
        esg_row.setdefault("doc", original_name)
        esg_row["company_name"] = company_name
        # Ensure company_name is the first column
        col_order = ["company_name", "doc"] + [k for k in esg_row if k not in ("company_name", "doc")]
        esg_df = pd.DataFrame([esg_row])[col_order]
        if ESG_CSV.exists():
            existing_esg = pd.read_csv(str(ESG_CSV))
            existing_esg = existing_esg[existing_esg["doc"] != original_name]
            # Add company_name column to old data if missing
            if "company_name" not in existing_esg.columns:
                existing_esg.insert(0, "company_name", existing_esg["doc"].apply(_get_name))
            esg_df = pd.concat([existing_esg, esg_df], ignore_index=True)
        esg_df.to_csv(str(ESG_CSV), index=False)


def _remove_document(doc_name: str) -> None:
    """Remove a document from all CSV outputs and the doc_labels store."""
    for csv_path in [EXTRACTED_CSV, ESG_CSV, FITCH_FACTORS_CSV, FORWARD_LOOKING_CSV, VALIDATION_CSV]:
        if csv_path.exists():
            try:
                df = pd.read_csv(str(csv_path))
                if "doc" in df.columns:
                    df = df[df["doc"] != doc_name]
                    df.to_csv(str(csv_path), index=False)
            except Exception:
                pass
    if REGULATORY_GAPS_CSV.exists():
        try:
            df = pd.read_csv(str(REGULATORY_GAPS_CSV))
            col = "doc_name" if "doc_name" in df.columns else "doc"
            if col in df.columns:
                df = df[df[col] != doc_name]
                df.to_csv(str(REGULATORY_GAPS_CSV), index=False)
        except Exception:
            pass
    labels = _load_labels()
    labels.pop(doc_name, None)
    _save_labels(labels)
    st.cache_data.clear()
    for key in list(st.session_state.keys()):
        if doc_name in str(key):
            del st.session_state[key]


def _show_single_result(name: str, result: dict):
    """Render result card using native Streamlit components (no unsafe markdown)."""
    segments = result.get("segments", [])
    esg = result.get("esg") or {}
    fitch = result.get("fitch_factors") or []
    reg = result.get("regulatory_gaps") or {}
    fwd = result.get("forward_looking") or {}
    conf = result.get("extraction_confidence", 0)
    error = result.get("error")
    currency = result.get("currency", "—")
    unit = result.get("unit", "—")
    period = str(result.get("reporting_period", "—"))[:10]
    src_page = result.get("source_page", "—")
    rating = esg.get("rating", "—") if esg else "—"

    if error and not segments:
        st.error(f"Could not extract segment data: {error}")
        return

    # ── Resolve company display name ─────────────────────────────────────────
    display_name = _get_name(name)
    conf_pct = int(conf * 100) if conf else 0
    non_totals = [s for s in segments if not s.get("is_total")]
    totals = [s for s in segments if s.get("is_total")]
    total_val = (
        totals[-1].get("value", 0) if totals
        else max((s.get("value", 0) or 0 for s in non_totals), default=1)
    ) or 1

    # ── Card header ──────────────────────────────────────────────────────────
    st.html(f"""
<div class="result-card">
  <div class="result-header">
    <svg class="result-check" width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
      <path fill-rule="evenodd" d="M14 2.5l-8 8-4-4L.5 8l5.5 5.5 9.5-9.5L14 2.5z"/>
    </svg>
    <div class="result-filename">{display_name}</div>
    <span class="chip chip-green">Extracted</span>
    <span class="chip chip-muted">{conf_pct}% confidence</span>
    <span class="chip chip-muted">p.&nbsp;{src_page}</span>
  </div>
  <div class="data-strip">
    <div class="data-cell"><div class="data-cell-label">Segments</div><div class="data-cell-value">{len(non_totals)}</div></div>
    <div class="data-cell"><div class="data-cell-label">Currency</div><div class="data-cell-value">{currency}</div></div>
    <div class="data-cell"><div class="data-cell-label">Unit</div><div class="data-cell-value">{unit}</div></div>
    <div class="data-cell"><div class="data-cell-label">Period</div><div class="data-cell-value sm">{period}</div></div>
    <div class="data-cell"><div class="data-cell-label">Fitch ESG Rating</div><div class="data-cell-value red" style="font-family:'Playfair Display',Georgia,serif;font-size:18px">{rating}</div></div>
  </div>
</div>""")

    # ── Body: left + right columns ────────────────────────────────────────────
    col_left, col_right = st.columns([48, 52])

    with col_left:
        # Segment table
        seg_rows = ""
        max_bar = max((s.get("value", 0) or 0 for s in non_totals), default=1) or 1
        bar_labels, bar_vals, bar_colors = [], [], []
        palette = ["#c41e24", "#a3191f", "#8a1519", "#701115", "#570d10"]
        for i, seg in enumerate(non_totals):
            val = seg.get("value", 0) or 0
            pct = min(100, int(val / total_val * 100)) if total_val else 0
            label = seg.get("value_label", "Revenue")
            seg_rows += f"""<tr>
  <td>{seg.get('segment','')[:28]}</td>
  <td><span class="chip chip-muted" style="font-size:9px">{label}</span></td>
  <td class="seg-value">{val:,.0f}</td>
  <td><div class="bar-wrap"><div class="bar-track"><div class="bar-fill" style="width:{pct}%"></div></div><span class="bar-pct">{pct}%</span></div></td>
</tr>"""
            bar_labels.append(seg.get("segment", "")[:14])
            bar_vals.append(val)
            bar_colors.append(palette[i % len(palette)])
        if totals:
            tv = totals[-1].get("value", 0) or 0
            seg_rows += f"""<tr class="total-row">
  <td style="color:var(--text-2)">{totals[-1].get('segment','Total')[:28]}</td>
  <td></td><td class="seg-value" style="color:var(--text-2)">{tv:,.0f}</td><td></td>
</tr>"""

        st.html(f"""
<div style="margin-top:4px">
  <div class="sub-label">Segment breakdown</div>
  <div class="card-2">
    <table class="seg-table">
      <thead><tr>
        <th>Segment</th><th>Metric</th>
        <th style="text-align:right">{currency}&nbsp;{unit}</th>
        <th style="min-width:100px">Weight</th>
      </tr></thead>
      <tbody>{seg_rows}</tbody>
    </table>
  </div>
</div>""")

        # Bar chart via Plotly (no JS needed)
        if bar_vals:
            fig_bar = go.Figure(go.Bar(
                x=bar_labels, y=bar_vals,
                marker_color=bar_colors,
                hovertemplate="%{x}<br>%{y:,.0f}<extra></extra>",
            ))
            fig_bar.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#6b7a96", size=9, family="Inter, sans-serif"),
                height=120, margin=dict(t=4, b=28, l=0, r=0),
                xaxis=dict(showgrid=False, tickfont=dict(size=8)),
                yaxis=dict(showgrid=False, showticklabels=False),
                showlegend=False,
            )
            st.plotly_chart(fig_bar, width="stretch", config={"displayModeBar": False})

        # Action buttons — real Streamlit widgets
        btn_c1, btn_c2 = st.columns(2)
        with btn_c1:
            dl_df = pd.DataFrame(segments)
            dl_df.insert(0, "company_name", display_name)
            dl_df.insert(1, "source_file", name)
            dl_df["currency"] = currency
            dl_df["unit"] = unit
            st.download_button(
                "Download CSV",
                data=dl_df.to_csv(index=False).encode(),
                file_name=f"{_re.sub(r'[^a-zA-Z0-9_-]', '_', display_name)}_segments.csv",
                mime="text/csv",
                key=f"dl_{abs(hash(name))}",
                use_container_width=True,
            )
        with btn_c2:
            if st.button(f"View Source  p.{src_page}", key=f"vs_{abs(hash(name))}", use_container_width=True):
                st.session_state[f"show_src_{name}"] = not st.session_state.get(f"show_src_{name}", False)

        # ── Full-screen PDF viewer injected into parent document ─────────────
        # st.html() uses shadow DOM so position:fixed and onclick can't escape
        # the container. We use st.components.v1.html() + window.parent injection
        # (same technique as the globe) and embed the PDF as a base64 data URL
        # so no static file serving URL is needed.
        if st.session_state.get(f"show_src_{name}"):
            tmp_path_str = st.session_state.get(f"tmp_path_{name}", "")
            if tmp_path_str and Path(tmp_path_str).exists():
                page_n = int(src_page) if str(src_page).isdigit() else 1

                # Base64-encode the PDF → data URL (browser opens it natively)
                pdf_b64 = base64.b64encode(Path(tmp_path_str).read_bytes()).decode("ascii")
                pdf_data_url = f"data:application/pdf;base64,{pdf_b64}#page={page_n}"

                modal_id = f"_pdf_modal_{abs(hash(name))}"

                import streamlit.components.v1 as _stc_pdf
                _stc_pdf.html(f"""<!DOCTYPE html>
<html><head><style>html,body{{margin:0;padding:0;height:0;overflow:hidden;background:transparent}}</style></head>
<body><script>
(function(){{
  try {{
    var pdoc = window.parent.document;
    // Remove any existing viewer first
    var old = pdoc.getElementById('{modal_id}');
    if(old) {{ old.remove(); return; }}  // second click = close

    var overlay = pdoc.createElement('div');
    overlay.id = '{modal_id}';
    overlay.style.cssText = [
      'position:fixed;inset:0;z-index:2147483646;',
      'background:rgba(5,10,22,0.94);',
      'display:flex;flex-direction:column;align-items:center;',
      'padding:20px 16px;',
      "font-family:'DM Sans',system-ui,sans-serif;",
      'transition:opacity .25s ease;'
    ].join('');

    // Top bar
    var topbar = pdoc.createElement('div');
    topbar.style.cssText = 'width:100%;max-width:1200px;display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-shrink:0;';

    var titleWrap = pdoc.createElement('div');
    titleWrap.style.cssText = 'display:flex;align-items:center;gap:10px;';

    var title = pdoc.createElement('span');
    title.textContent = '{display_name.replace("'", "\\'")}';
    title.style.cssText = 'font-size:13px;font-weight:600;color:#e0e8f5;letter-spacing:0.3px;';

    var badge = pdoc.createElement('span');
    badge.textContent = 'PAGE {page_n}';
    badge.style.cssText = 'font-size:9px;font-weight:800;letter-spacing:2px;text-transform:uppercase;color:#fff;background:#c41e24;padding:3px 11px;border-radius:2px;';

    titleWrap.appendChild(title);
    titleWrap.appendChild(badge);

    var closeBtn = pdoc.createElement('button');
    closeBtn.textContent = 'CLOSE  ✕';
    closeBtn.style.cssText = [
      'font-size:10px;letter-spacing:2px;text-transform:uppercase;',
      'color:rgba(255,255,255,0.4);border:1px solid rgba(255,255,255,0.15);',
      'background:transparent;padding:6px 16px;cursor:pointer;border-radius:2px;',
      'transition:color .2s,border-color .2s;font-family:inherit;'
    ].join('');
    closeBtn.onmouseover = function(){{ closeBtn.style.color='rgba(255,255,255,0.9)'; closeBtn.style.borderColor='rgba(255,255,255,0.4)'; }};
    closeBtn.onmouseout  = function(){{ closeBtn.style.color='rgba(255,255,255,0.4)'; closeBtn.style.borderColor='rgba(255,255,255,0.15)'; }};
    closeBtn.onclick = function(){{
      overlay.style.opacity='0';
      setTimeout(function(){{ overlay.remove(); }}, 260);
    }};

    topbar.appendChild(titleWrap);
    topbar.appendChild(closeBtn);
    overlay.appendChild(topbar);

    // PDF iframe
    var fr = pdoc.createElement('iframe');
    fr.src = '{pdf_data_url}';
    fr.style.cssText = [
      'width:100%;max-width:1200px;flex:1;border:none;',
      'border-radius:3px;box-shadow:0 8px 48px rgba(0,0,0,0.7);',
      'min-height:500px;background:#fff;'
    ].join('');

    overlay.appendChild(fr);
    pdoc.body.appendChild(overlay);

    // Also close on Escape key
    function onKey(e){{
      if(e.key==='Escape'){{ closeBtn.click(); pdoc.removeEventListener('keydown',onKey); }}
    }}
    pdoc.addEventListener('keydown', onKey);

  }} catch(err) {{ console.warn('PDF viewer error:', err); }}
}})();
</script></body></html>""", height=0)
            else:
                st.info("Source PDF unavailable — re-upload the file to enable the page viewer.")

    with col_right:
        # ESG tab content
        if esg:
            composite = esg.get("composite", 0)
            e_score = esg.get("e_score", 0)
            s_score = esg.get("s_score", 0)
            g_score = esg.get("g_score", 0)
            rating_cls = f"esg-{rating.lower().replace('+','').replace('-','')}" if rating not in ("—", "") else "esg-bbb"
            flags = esg.get("greenwashing_flags", "")
            penalty = esg.get("greenwashing_penalty", 0)

            disc_ok = '<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor" class="disc-ok"><path d="M14 2.5l-8 8-4-4L.5 8l5.5 5.5 9.5-9.5L14 2.5z"/></svg>'
            disc_warn = '<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor" class="disc-warn"><path d="M8 1a7 7 0 100 14A7 7 0 008 1zm.75 8.75H7.25V5h1.5v4.75zm0 2.25H7.25v-1.5h1.5V12z"/></svg>'
            disc_html = ""
            if e_score > 50:
                disc_html += f'<div class="disc-item">{disc_ok}Scope 1 &amp; 2 emissions disclosed</div>'
            disc_html += f'<div class="disc-item">{disc_ok if e_score > 70 else disc_warn}{"Scope 3 value chain emissions" if e_score > 70 else "Scope 3 data incomplete or missing"}</div>'
            disc_html += f'<div class="disc-item">{disc_ok if g_score > 65 else disc_warn}{"Third-party governance assurance" if g_score > 65 else "Third-party assurance not confirmed"}</div>'
            if fwd and fwd.get("net_zero_year"):
                disc_html += f'<div class="disc-item">{disc_ok}Net-zero target {fwd["net_zero_year"]} (SBTi)</div>'
            gw_html = ""
            if flags and penalty:
                gw_html = f'<div class="gw-flag"><svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 1a7 7 0 100 14A7 7 0 008 1zm.75 8.75H7.25V5h1.5v4.75zm0 2.25H7.25v-1.5h1.5V12z"/></svg>Greenwashing penalty: &minus;{penalty:.0f} pts &middot; {str(flags)[:100]}</div>'

            esg_html = f"""
<div class="esg-header"><span class="esg-rating {rating_cls}">{rating}</span>
  <div><div class="esg-composite">Composite <strong>{composite:.0f} / 100</strong></div>
  <div style="font-size:10px;color:var(--text-3);margin-top:2px">ESG assessment</div></div>
</div><hr>
<div class="sub-label">Pillar scores</div>
<div class="score-row"><div class="score-row-label">Environmental</div><div class="score-track"><div class="score-fill fill-green" style="width:{e_score}%"></div></div><div class="score-val">{e_score:.0f}</div></div>
<div class="score-row"><div class="score-row-label">Social</div><div class="score-track"><div class="score-fill fill-blue" style="width:{s_score}%"></div></div><div class="score-val">{s_score:.0f}</div></div>
<div class="score-row"><div class="score-row-label">Governance</div><div class="score-track"><div class="score-fill fill-purple" style="width:{g_score}%"></div></div><div class="score-val">{g_score:.0f}</div></div>
{"<hr><div class='sub-label'>Disclosure checklist</div><div class='disc-list'>" + disc_html + "</div>" if disc_html else ""}
{gw_html}"""
        else:
            esg_html = '<div style="font-size:12px;color:var(--text-3);padding:16px 0;text-align:center">No ESG data available.</div>'

        # Fitch tab content
        if fitch:
            by_dim: dict[str, list] = {"E": [], "S": [], "G": []}
            for f in fitch:
                d = f.get("dimension", "E")
                if d in by_dim:
                    by_dim[d].append(f)
            col1_h = '<div class="fitch-col"><div class="fitch-col-head">Environmental</div>'
            for f in by_dim["E"]:
                sc = max(1, min(5, int(f.get("score", 1))))
                fn = (f.get("name") or f.get("factor") or "")[:24]
                col1_h += f'<div class="fitch-item"><span class="fitch-item-name">{fn}</span><span class="fitch-score f{sc}">{sc}</span></div>'
            col1_h += '<div class="fitch-col-head" style="margin-top:10px">Social</div>'
            for f in by_dim["S"]:
                sc = max(1, min(5, int(f.get("score", 1))))
                fn = (f.get("name") or f.get("factor") or "")[:24]
                col1_h += f'<div class="fitch-item"><span class="fitch-item-name">{fn}</span><span class="fitch-score f{sc}">{sc}</span></div>'
            col1_h += '</div>'
            col2_h = '<div class="fitch-col"><div class="fitch-col-head">Governance</div>'
            for f in by_dim["G"]:
                sc = max(1, min(5, int(f.get("score", 1))))
                fn = (f.get("name") or f.get("factor") or "")[:24]
                col2_h += f'<div class="fitch-item"><span class="fitch-item-name">{fn}</span><span class="fitch-score f{sc}">{sc}</span></div>'
            col2_h += '</div>'
            fitch_html = f'<div class="sub-label">15-Factor assessment &mdash; 1 (not disclosed) to 5 (best practice)</div><div class="fitch-cols">{col1_h}{col2_h}</div>'
        else:
            fitch_html = '<div style="font-size:12px;color:var(--text-3);padding:16px 0;text-align:center">No Fitch factor data available.</div>'

        # Regulatory tab content
        if reg:
            reg_html = '<div class="sub-label">Framework alignment</div>'
            for fw_key, fw_label in [("csrd", "CSRD / ESRS"), ("tcfd", "TCFD"), ("eu_taxonomy", "EU Taxonomy")]:
                fw = reg.get(fw_key, {})
                if fw:
                    pct = fw.get("overall_pct", 0)
                    color = "#2d9e6b" if pct >= 70 else ("#c49a30" if pct >= 40 else "#c41e24")
                    reg_html += f'<div class="reg-item"><div class="reg-header"><span class="reg-label">{fw_label}</span><span class="reg-pct" style="color:{color}">{pct:.0f}%</span></div><div class="reg-track"><div class="reg-fill" style="width:{pct}%;background:{color}"></div></div></div>'
            if fwd and fwd.get("net_zero_year"):
                reg_html += f'<div class="nz-box"><div class="nz-title">Net-zero commitment: {fwd["net_zero_year"]}</div><div class="nz-sub">Science-Based Targets initiative · Scope 1+2+3</div></div>'
        else:
            reg_html = '<div style="font-size:12px;color:var(--text-3);padding:16px 0;text-align:center">No regulatory data available.</div>'

        # NACE tab content
        nace_items_html = ""
        seen_nace: set[str] = set()
        for seg in segments:
            sec = seg.get("nace_section", "")
            div_code = seg.get("nace_division", "")
            desc = seg.get("nace_description", "")
            nc_raw = seg.get("nace_confidence", "")
            if not sec or sec in seen_nace:
                continue
            seen_nace.add(sec)
            try:
                nc_f = float(nc_raw)
                nc_chip = "chip-green" if nc_f >= 0.85 else ("chip-gold" if nc_f >= 0.6 else "chip-muted")
                nc_label = f"{nc_f:.2f}"
            except (ValueError, TypeError):
                nc_chip, nc_label = "chip-muted", ""
            seg_name = seg.get("segment", "")[:30]
            nc_pill = f'<span class="chip {nc_chip}" style="font-size:9px">{nc_label}</span>' if nc_label else ""
            desc_short = (" " + desc[:16]) if desc else ""
            nace_items_html += (
                f'<div class="card-2" style="padding:10px 12px">'
                f'<div style="display:flex;align-items:center;justify-content:space-between">'
                f'<span style="font-size:12px;color:var(--text)">{seg_name}</span>'
                f'<div style="display:flex;gap:5px;align-items:center">'
                f'<span class="nace-pill"><span class="nace-code">{div_code or sec}</span>{desc_short}</span>'
                f'{nc_pill}</div></div></div>'
            )
        nace_html = f'<div class="sub-label">NACE Rev 2.1 industry classification</div><div style="display:flex;flex-direction:column;gap:7px;margin-top:6px">{nace_items_html}</div>' if nace_items_html else '<div style="font-size:12px;color:var(--text-3);padding:16px 0;text-align:center">No NACE classification data available.</div>'

        # Native Streamlit tabs (no JavaScript needed)
        tab_esg, tab_fitch, tab_reg, tab_nace = st.tabs(["ESG Score", "Fitch Factors", "Regulatory", "NACE"])
        with tab_esg:
            st.html(esg_html)
        with tab_fitch:
            st.html(fitch_html)
        with tab_reg:
            st.html(reg_html)
        with tab_nace:
            st.html(nace_html)

# ─────────────────────────────────────────────────────────────────────────────
# PAGE 2 — Results Dashboard
# ─────────────────────────────────────────────────────────────────────────────

def page_dashboard():
    _ticker()
    _page_header("Portfolio Overview", "Aggregate view across all processed documents in your library.")

    extracted = load_extracted()
    esg = load_esg()

    if extracted.empty:
        st.info("No data yet. Go to **Upload & Analyse** to process your first PDF.")
        return

    # ── Summary metrics ──
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Documents", extracted["doc"].nunique())
    m2.metric("Segments", len(extracted))
    m3.metric("Currencies", extracted["currency"].nunique() if "currency" in extracted.columns else "—")
    avg_conf = extracted["extraction_confidence"].mean() if "extraction_confidence" in extracted.columns else 0
    m4.metric("Avg Confidence", f"{avg_conf:.0%}")
    if not esg.empty and "composite" in esg.columns:
        m5.metric("Avg ESG Score", f"{esg['composite'].mean():.1f}/100")

    st.divider()

    col_left, col_right = st.columns(2)

    with col_left:
        # Currency breakdown
        if "currency" in extracted.columns:
            counts = extracted["currency"].value_counts().reset_index()
            counts.columns = ["currency", "count"]
            fig_c = px.pie(counts, names="currency", values="count",
                           title="Global Coverage — Currencies",
                           color_discrete_sequence=px.colors.qualitative.G10)
            fig_c.update_layout(paper_bgcolor="#161b22", font_color="#c9d1d9",
                                plot_bgcolor="#161b22", height=320,
                                margin=dict(t=40, b=20, l=0, r=0))
            st.plotly_chart(fig_c, width="stretch")

    with col_right:
        # NACE distribution
        if "nace_section" in extracted.columns:
            nc = extracted["nace_section"].value_counts().reset_index()
            nc.columns = ["section", "count"]
            nc["label"] = nc["section"].map(NACE_SECTIONS).fillna("Other")
            fig_n = px.bar(nc.head(10), x="count", y="section", orientation="h",
                           hover_data=["label"], title="NACE Sections",
                           color="count", color_continuous_scale="Blues")
            fig_n.update_layout(paper_bgcolor="#161b22", font_color="#c9d1d9",
                                plot_bgcolor="#161b22", height=320,
                                margin=dict(t=40, b=20, l=0, r=10),
                                coloraxis_showscale=False, yaxis_title="", xaxis_title="# Segments")
            st.plotly_chart(fig_n, width="stretch")

    st.divider()

    # ── Per-document segment table ──
    st.subheader("Browse All Extracted Data")
    docs = sorted(extracted["doc"].unique())
    selected = st.selectbox("Select document", ["All documents"] + docs)
    view = extracted if selected == "All documents" else extracted[extracted["doc"] == selected]

    show_cols = [c for c in ["doc", "segment", "value", "value_label", "currency", "unit",
                              "reporting_period", "nace_section", "nace_description", "extraction_confidence"]
                 if c in view.columns]
    st.dataframe(view[show_cols].reset_index(drop=True), use_container_width=True, hide_index=True)

    # Download all
    st.download_button("Download all extracted data (CSV)",
                       data=extracted.to_csv(index=False).encode(),
                       file_name="all_segments.csv", mime="text/csv")

    # ── Segment value breakdown for selected doc ──
    if selected != "All documents" and len(view) > 0:
        st.divider()
        st.subheader(f"Segment breakdown — {selected[:60]}")
        currency = view["currency"].iloc[0] if "currency" in view.columns else ""
        unit = view["unit"].iloc[0] if "unit" in view.columns else ""
        non_totals = view[view["is_total"] == False] if "is_total" in view.columns else view

        if len(non_totals) >= 2:
            fig_seg = px.bar(
                non_totals, x="segment", y="value",
                color="value", color_continuous_scale=["#da3633", "#30363d", "#238636"],
                text="value", title=f"Revenue by segment ({currency} {unit})"
            )
            fig_seg.update_traces(texttemplate="%{text:,.0f}", textposition="outside")
            fig_seg.update_layout(paper_bgcolor="#161b22", font_color="#c9d1d9",
                                   plot_bgcolor="#161b22", height=380,
                                   coloraxis_showscale=False,
                                   margin=dict(t=40, b=60, l=10, r=10),
                                   xaxis=dict(showgrid=False, tickangle=20),
                                   yaxis=dict(showgrid=True, gridcolor="#30363d"))
            st.plotly_chart(fig_seg, width="stretch")

# ─────────────────────────────────────────────────────────────────────────────
# PAGE 3 — ESG & Greenwashing
# ─────────────────────────────────────────────────────────────────────────────

def page_esg():
    _ticker()
    _page_header("ESG Scores & Greenwashing Detection", "Portfolio ESG distribution and greenwashing risk assessment.")

    esg = load_esg()
    if esg.empty:
        st.info("No ESG data yet. Upload PDFs first.")
        return

    # ── Top metrics ──
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Documents scored", len(esg))
    m2.metric("Avg ESG composite", f"{esg['composite'].mean():.1f}" if "composite" in esg.columns else "—")
    flagged = (esg["greenwashing_penalty"] > 5).sum() if "greenwashing_penalty" in esg.columns else 0
    m3.metric("Greenwashing flags", int(flagged), delta=f"{flagged} docs at risk", delta_color="inverse" if flagged > 0 else "normal")
    scope3_missing = (~esg["has_scope3"].astype(bool)).sum() if "has_scope3" in esg.columns else 0
    m4.metric("Missing Scope 3", int(scope3_missing), delta_color="inverse")

    st.divider()

    col_l, col_r = st.columns(2)

    with col_l:
        # Score distribution
        fig_hist = px.histogram(esg, x="composite", nbins=15,
                                title="ESG Score Distribution",
                                labels={"composite": "ESG Composite (0-100)"},
                                color_discrete_sequence=["#238636"])
        fig_hist.add_vline(x=50, line_dash="dash", line_color="#8b949e", annotation_text="50 baseline")
        fig_hist.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                               font_color="#c9d1d9", height=300,
                               margin=dict(t=40, b=20))
        st.plotly_chart(fig_hist, width="stretch")

    with col_r:
        # E vs G scatter coloured by greenwashing
        if all(c in esg.columns for c in ["e_score", "g_score", "greenwashing_penalty"]):
            fig_sc = px.scatter(esg, x="g_score", y="e_score",
                                size="greenwashing_penalty",
                                color="greenwashing_penalty",
                                hover_data=["doc", "composite", "rating"],
                                color_continuous_scale="RdYlGn_r",
                                title="E-score vs G-score (bubble = greenwashing penalty)",
                                labels={"g_score": "Governance", "e_score": "Environmental"})
            fig_sc.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                                  font_color="#c9d1d9", height=300,
                                  margin=dict(t=40, b=20))
            st.plotly_chart(fig_sc, width="stretch")

    # ── Greenwashing table ──
    st.subheader("Greenwashing Risk Table")
    flag_cols = [c for c in ["doc", "rating", "composite", "greenwashing_penalty", "greenwashing_flags",
                               "has_scope1", "has_scope2", "has_scope3", "has_third_party_assurance"] if c in esg.columns]
    styled = esg.sort_values("greenwashing_penalty", ascending=False)[flag_cols]
    st.dataframe(styled, use_container_width=True, hide_index=True)

    # ── Individual doc deep-dive ──
    st.divider()
    st.subheader("Deep-dive: individual document")
    selected = st.selectbox("Select document", sorted(esg["doc"].unique()))
    row = esg[esg["doc"] == selected].iloc[0]

    d1, d2, d3, d4 = st.columns(4)
    rating = row.get("rating", "—")
    d1.metric("Rating", rating)
    d2.metric("Environmental", f"{row.get('e_score', 0):.0f}/100")
    d3.metric("Social", f"{row.get('s_score', 0):.0f}/100")
    d4.metric("Governance", f"{row.get('g_score', 0):.0f}/100")

    col_radar, col_flags = st.columns([1, 1])
    with col_radar:
        e, s, g = row.get("e_score", 0), row.get("s_score", 0), row.get("g_score", 0)
        radar = go.Figure(go.Scatterpolar(
            r=[e, s, g, e], theta=["Environmental", "Social", "Governance", "Environmental"],
            fill="toself", fillcolor="rgba(88,166,255,0.15)", line_color="#58a6ff"
        ))
        radar.update_layout(
            polar=dict(bgcolor="#161b22",
                       radialaxis=dict(visible=True, range=[0, 100], gridcolor="#30363d"),
                       angularaxis=dict(gridcolor="#30363d", tickfont_color="#c9d1d9")),
            paper_bgcolor="#161b22", font_color="#c9d1d9", height=320,
            margin=dict(t=20, b=20, l=30, r=30)
        )
        st.plotly_chart(radar, width="stretch")

    with col_flags:
        st.markdown("**Disclosure checklist**")
        checks = [
            ("Scope 1 emissions", row.get("has_scope1", False)),
            ("Scope 2 emissions", row.get("has_scope2", False)),
            ("Scope 3 emissions", row.get("has_scope3", False)),
            ("Third-party assurance", row.get("has_third_party_assurance", False)),
            ("Net-zero target", row.get("has_net_zero_target", False)),
        ]
        for label, ok in checks:
            icon = "✅" if ok else "❌"
            st.markdown(f"{icon} &nbsp; {label}", unsafe_allow_html=True)
        penalty = row.get("greenwashing_penalty", 0)
        vague = row.get("vague_phrase_count", 0)
        st.divider()
        st.metric("Greenwashing penalty", f"−{penalty:.0f} pts")
        st.metric("Vague language phrases", int(vague))
        flags = str(row.get("greenwashing_flags", ""))
        if flags and penalty > 0:
            st.warning(flags)

# ─────────────────────────────────────────────────────────────────────────────
# PAGE — Document Key
# ─────────────────────────────────────────────────────────────────────────────

def page_document_key():
    _ticker()
    _page_header("Document Key", "Company names used throughout this platform and their source files.")

    # Gather all known docs from every CSV
    all_known: set[str] = set()
    for csv_path in [EXTRACTED_CSV, ESG_CSV, FITCH_FACTORS_CSV, FORWARD_LOOKING_CSV, REGULATORY_GAPS_CSV]:
        if csv_path.exists():
            try:
                df = pd.read_csv(str(csv_path))
                if "doc" in df.columns:
                    all_known.update(df["doc"].dropna().unique().tolist())
            except Exception:
                pass

    labels = _ensure_labels(list(all_known))

    if not all_known:
        st.info("No documents processed yet. Upload PDFs on the Document Intake page to get started.")
        return

    # ── Summary cards ──────────────────────────────────────────────────────────
    c1, c2, c3 = st.columns([2, 2, 3])
    c1.metric("Documents in Library", len(all_known))
    custom = sum(1 for d in all_known if labels.get(d) and labels[d] != _auto_name(d))
    c2.metric("Names Customised", custom)
    with c3:
        st.write("")
        if st.button("↺  Re-detect all names from filenames", use_container_width=True,
                     help="Clears all cached names and re-runs the auto-detector on every filename. Use this after uploading new files or if names look wrong."):
            fresh = {d: _auto_name(d) for d in all_known}
            _save_labels(fresh)
            st.success("All names reset to auto-detected values.")
            st.rerun()

    st.divider()

    # ── Master key table ───────────────────────────────────────────────────────
    st.subheader("Company → File Mapping")
    st.caption("This is the single source of truth for all names used in charts, reports, and exports.")

    key_rows = []
    for doc in sorted(all_known, key=lambda d: labels.get(d, _auto_name(d)).lower()):
        key_rows.append({
            "Company Name": labels.get(doc, _auto_name(doc)),
            "Original Filename / URL": doc,
        })
    key_df = pd.DataFrame(key_rows)
    st.dataframe(
        key_df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Company Name":          st.column_config.TextColumn("Company Name",            width="medium"),
            "Original Filename / URL": st.column_config.TextColumn("Original Filename / URL", width="large"),
        },
    )

    # Download the key as CSV
    st.download_button(
        "Download Key as CSV",
        data=key_df.to_csv(index=False).encode(),
        file_name="document_key.csv",
        mime="text/csv",
        use_container_width=False,
    )

    st.divider()

    # ── Inline name editor ─────────────────────────────────────────────────────
    st.subheader("Edit Company Names")
    st.caption("Changes save instantly and update every chart, heatmap, and report on this platform.")

    edited: dict[str, str] = {}
    cols_e = st.columns(2)
    for i, doc in enumerate(sorted(all_known, key=lambda d: labels.get(d, _auto_name(d)).lower())):
        with cols_e[i % 2]:
            val = st.text_input(
                "Company name",
                value=labels.get(doc, _auto_name(doc)),
                key=f"dk_label_{abs(hash(doc))}",
                label_visibility="collapsed",
            )
            st.caption(f"📎 {doc[:80]}")
            edited[doc] = val

    if st.button("Save All Names", type="primary", use_container_width=False):
        _save_labels(edited)
        st.success("Names saved. All pages will now use the updated names.")
        st.rerun()


# PAGE 4 — NACE Classification
# ─────────────────────────────────────────────────────────────────────────────

def page_nace():
    _ticker()
    _page_header("NACE Classification", "European standard industry taxonomy — used for CSRD, ESRS, and global ESG reporting.")

    extracted = load_extracted()
    if extracted.empty or "nace_section" not in extracted.columns:
        st.info("No NACE data yet. Upload PDFs first.")
        return

    # Summary
    m1, m2 = st.columns(2)
    m1.metric("Unique NACE sections", extracted["nace_section"].nunique())
    m2.metric("Total tagged segments", len(extracted))

    st.divider()
    col_l, col_r = st.columns(2)

    with col_l:
        counts = extracted["nace_section"].value_counts().reset_index()
        counts.columns = ["section", "count"]
        counts["description"] = counts["section"].map(NACE_SECTIONS).fillna("Other")
        fig = px.treemap(counts, path=["section"], values="count",
                         hover_data=["description"],
                         title="NACE Sections — treemap",
                         color="count", color_continuous_scale="Blues")
        fig.update_layout(paper_bgcolor="#161b22", font_color="#c9d1d9",
                           margin=dict(t=40, b=10, l=10, r=10), height=380)
        st.plotly_chart(fig, width="stretch")

    with col_r:
        if "nace_confidence" in extracted.columns:
            fig2 = px.histogram(extracted, x="nace_confidence", nbins=10,
                                title="Classification Confidence Distribution",
                                labels={"nace_confidence": "Confidence (0-1)"},
                                color_discrete_sequence=["#58a6ff"])
            fig2.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                                font_color="#c9d1d9", height=380,
                                margin=dict(t=40, b=20))
            st.plotly_chart(fig2, width="stretch")

    st.divider()
    st.subheader("All Tagged Segments")
    show_cols = [c for c in ["doc", "segment", "value", "currency", "unit",
                              "nace_section", "nace_division", "nace_description", "nace_confidence"]
                 if c in extracted.columns]
    st.dataframe(extracted[show_cols].sort_values("nace_section"), use_container_width=True, hide_index=True)

# ─────────────────────────────────────────────────────────────────────────────
# PAGE 5 — Accuracy Validation
# ─────────────────────────────────────────────────────────────────────────────

def page_validation():
    _ticker()
    _page_header("Accuracy Validation", "Compare AI extractions against the ground truth spreadsheet. Target: ≥90% recall.")

    val = load_validation()
    extracted = load_extracted()

    if val.empty:
        st.info("No validation data yet. Run the pipeline on the ground truth PDFs first.")
        with st.expander("Run validation now"):
            if st.button("Run on ground truth PDFs", type="primary"):
                from pipeline import run_pipeline
                gt_docs = [
                    "82_Orsted Annual Report 2025.pdf",
                    "726_Alliander_Annual_Report_2024 (4).pdf",
                    "728_2025 Annual report.pdf",
                    "766_2024 annual report.pdf",
                    "11140_2025 Consolidated Financial Statements (Dec 2025).pdf",
                ]
                paths = [PDF_DIR / d for d in gt_docs if (PDF_DIR / d).exists()]
                with st.spinner("Running…"):
                    run_pipeline(pdf_paths=paths, validate=True, verbose=False)
                st.cache_data.clear()
                st.rerun()
        return

    # ── Overall metrics ──
    if "matched" in val.columns:
        matched = int(val["matched"].sum())
        total = len(val)
        acc = matched / total if total else 0

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Overall Accuracy", f"{acc:.1%}", delta="Target met" if acc >= 0.9 else "Below 90%",
                  delta_color="normal" if acc >= 0.9 else "inverse")
        m2.metric("Rows matched", f"{matched}/{total}")
        m3.metric("Ground truth rows", total)
        m4.metric("Status", "PASS" if acc >= 0.9 else "FAIL",
                  delta_color="normal" if acc >= 0.9 else "inverse")

        st.divider()

        # Per-doc bar
        summary = (val.groupby("doc")
                   .agg(gt_rows=("gt_segment", lambda x: x.notna().sum()),
                        matched=("matched", "sum"))
                   .reset_index())
        summary["recall"] = summary["matched"] / summary["gt_rows"]
        summary["doc_short"] = summary["doc"].str[:40]

        fig = px.bar(summary, x="recall", y="doc_short", orientation="h",
                     color="recall", range_color=[0, 1],
                     color_continuous_scale="RdYlGn",
                     text=summary["recall"].apply(lambda x: f"{x:.0%}"),
                     title="Recall per document (matched GT rows / total GT rows)",
                     labels={"recall": "Recall", "doc_short": ""})
        fig.add_vline(x=0.9, line_dash="dash", line_color="#58a6ff", annotation_text="90% target")
        fig.update_traces(textposition="outside")
        fig.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                           font_color="#c9d1d9", height=320, coloraxis_showscale=False,
                           margin=dict(t=40, b=20, l=10, r=60),
                           xaxis=dict(range=[0, 1.15], tickformat=".0%", gridcolor="#30363d"),
                           yaxis=dict(showgrid=False))
        st.plotly_chart(fig, width="stretch")

        # Detailed match table
        st.subheader("Row-level match detail")
        show = [c for c in ["doc", "extracted_segment", "gt_segment", "extracted_value",
                             "gt_value", "extracted_currency", "gt_currency", "matched"]
                if c in val.columns]
        st.dataframe(val[show].sort_values("matched", ascending=True),
                     use_container_width=True, hide_index=True)

        st.download_button("Download validation results (CSV)",
                           data=val.to_csv(index=False).encode(),
                           file_name="validation_results.csv", mime="text/csv")

# ─────────────────────────────────────────────────────────────────────────────
# PAGE 6 — Company Search
# ─────────────────────────────────────────────────────────────────────────────

def page_company_search():
    from company_search import (
        search_annual_report, suggest_peer_companies,
        fetch_company_news, summarize_company_context, try_download_pdf,
    )

    _ticker()
    _page_header("Company Search", "Locate the latest annual report filing for any global issuer and pull live ESG context.")
    st.caption(
        "Type a company name — AI finds their latest annual report, suggests peer companies, "
        "and pulls live news with ESG context."
    )

    # ── Search box — pre-filled with the last searched company ──
    last_query = st.session_state.get("cs_last_query", "")
    col_in, col_btn = st.columns([5, 1])
    with col_in:
        company_input = st.text_input(
            "Company name",
            value=last_query,
            placeholder="e.g.  Orsted,  Vestas,  National Grid,  Enel,  NextEra Energy…",
            label_visibility="collapsed",
        )
    with col_btn:
        search_clicked = st.button("Search", use_container_width=True)

    if not company_input:
        st.info("Enter a company name above to search for their latest filing and peer context.")
        return

    # Run on button click OR when session already has results for this company
    cache_key = f"search_{company_input.strip().lower()}"

    if search_clicked or cache_key not in st.session_state:
        with st.spinner(f"Searching for **{company_input}** annual report and news…"):
            filing = search_annual_report(company_input)
            news = fetch_company_news(company_input, num_results=10)
            peers = suggest_peer_companies(
                company_input,
                industry_hint=filing.get("filing_type", ""),
            )
            # Build context summary (uses ESG + segments if loaded from a previous upload)
            loaded_segments = st.session_state.get("last_segments", [])
            loaded_esg = st.session_state.get("last_esg", {})
            context_brief = summarize_company_context(
                company_input, news, loaded_segments, loaded_esg
            )
        st.session_state[cache_key] = {
            "filing": filing,
            "news": news,
            "peers": peers,
            "context_brief": context_brief,
        }
        # Store for chatbot + persist query so the page restores on navigation
        st.session_state["current_company"] = company_input
        st.session_state["company_news"] = news
        st.session_state["context_brief"] = context_brief
        st.session_state["cs_last_query"] = company_input

    data = st.session_state[cache_key]
    filing = data["filing"]
    news = data["news"]
    peers = data["peers"]
    context_brief = data["context_brief"]

    st.divider()

    # ── Filing result ──
    col_filing, col_peers = st.columns([3, 2])

    with col_filing:
        st.subheader("📄 Latest Filing Found")

        if filing.get("error") and not filing.get("url"):
            st.error(filing["error"])
        else:
            conf = filing.get("confidence", 0)
            conf_color = "#3fb950" if conf >= 0.7 else ("#e3b341" if conf >= 0.4 else "#f85149")
            st.markdown(
                f"**{filing.get('company_name', company_input)}** — "
                f"{filing.get('filing_type', 'Annual Report')} {filing.get('year', '')}",
            )
            st.markdown(
                f'<span style="background:var(--surface);border:1px solid {conf_color};color:{conf_color};'
                f'padding:2px 10px;border-radius:20px;font-size:12px">'
                f'Match confidence: {conf:.0%}</span>',
                unsafe_allow_html=True,
            )
            st.write("")

            url = filing.get("url", "")
            if url:
                st.markdown(f"🔗 **[Open filing]({url})**")
                st.caption(filing.get("notes", ""))

                # Auto-download if it's a direct PDF link
                if filing.get("is_direct_pdf") and url:
                    col_dl1, col_dl2 = st.columns(2)
                    with col_dl1:
                        if st.button("⬇️ Download & analyse PDF", use_container_width=True):
                            with st.spinner("Downloading PDF…"):
                                saved = try_download_pdf(url, PDF_DIR)
                            if saved:
                                st.success(f"Saved to project folder: `{saved.name}`")
                                st.info(
                                    "Go to **Upload & Analyse**, click Browse files, "
                                    f"and select `{saved.name}` to extract segments."
                                )
                            else:
                                st.warning(
                                    "Could not auto-download (the site may require login). "
                                    "Use the link above to download manually, then upload it."
                                )
            else:
                st.warning("No direct URL found. Try searching manually on the company's investor relations page.")

            # Show top search results as fallback links
            raw_results = filing.get("search_results", [])
            if raw_results:
                with st.expander("All search results"):
                    for r in raw_results[:5]:
                        st.markdown(f"- [{r.get('title','link')}]({r.get('href','')})")

    with col_peers:
        st.subheader("🏢 Peer Companies")
        st.caption("Comparable companies a Fitch analyst would benchmark against")
        if peers:
            for p in peers:
                ticker = f" `{p.get('ticker')}`" if p.get("ticker") else ""
                region_badge = (
                    f'<span style="background:var(--surface-alt);color:var(--muted);padding:1px 7px;'
                    f'border-radius:10px;font-size:11px">{p.get("region","")}</span>'
                )
                st.markdown(
                    f"**{p.get('name','')}{ticker}** {region_badge}  \n"
                    f"<span style='color:var(--muted);font-size:12px'>{p.get('reason','')}</span>",
                    unsafe_allow_html=True,
                )
                st.write("")
        else:
            st.info("Peer suggestions require an API key.")

    st.divider()

    # ── Analyst brief ──
    st.subheader("📋 AI Analyst Brief")
    if context_brief:
        st.markdown(context_brief)
    else:
        st.info("Could not generate brief — check API key or try again.")

    # ── Live news ──
    st.divider()
    st.subheader("📰 Live News")
    if news:
        cols = st.columns(2)
        for i, item in enumerate(news[:8]):
            with cols[i % 2]:
                date_str = str(item.get("date", ""))[:10]
                source = item.get("source", "")
                url_n = item.get("url", "") or item.get("href", "")
                title = item.get("title", "No title")
                body = item.get("body", "")[:200]

                st.markdown(
                    f"""<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:14px;margin-bottom:12px">
<div style="font-size:11px;color:var(--muted)">{date_str} · {source}</div>
<div style="font-weight:600;margin:6px 0"><a href="{url_n}" target="_blank" style="color:var(--blue);text-decoration:none">{title}</a></div>
<div style="font-size:13px;color:var(--muted)">{body}…</div>
</div>""",
                    unsafe_allow_html=True,
                )
    else:
        st.info("No news found. This may be a rate-limit issue — try again in a moment.")

    # Prompt user to go to chat
    st.divider()
    st.markdown(
        "💬 **Want to ask questions about this company?** Go to **AI Chat** in the sidebar — "
        "context from this search will be loaded automatically."
    )


# ─────────────────────────────────────────────────────────────────────────────
# PAGE 7 — AI Chat
# ─────────────────────────────────────────────────────────────────────────────

def page_chat():
    from chatbot import build_system_prompt, stream_chat_response, get_suggested_questions

    _ticker()
    _page_header("Analyst Intelligence", "Context-aware research assistant. Loaded with your document extractions, ESG data, and live market intelligence.")

    # ── Gather available context ──
    company_name = st.session_state.get("current_company", "")
    context_brief = st.session_state.get("context_brief", "")
    news_items = st.session_state.get("company_news", [])
    last_segments = st.session_state.get("last_segments", [])
    last_esg = st.session_state.get("last_esg", {})
    last_currency = st.session_state.get("last_currency", "")
    last_unit = st.session_state.get("last_unit", "")
    last_period = st.session_state.get("last_period", "")
    last_pdf_text = st.session_state.get("last_pdf_text", "")

    # ── Sidebar context panel ──
    with st.sidebar:
        st.divider()
        st.markdown("**Research context**")
        st.markdown(f"Issuer: **{company_name or '—'}**")
        st.markdown(f"Segments loaded: **{len(last_segments)}**")
        st.markdown(f"ESG data: **{'Available' if last_esg else 'None'}**")
        st.markdown(f"News items: **{len(news_items)}**")
        st.divider()

        # Company override
        override = st.text_input("Override issuer name:", value=company_name, key="chat_company_override")
        if override != company_name:
            st.session_state["current_company"] = override
            company_name = override

        if st.button("Clear session", key="clear_chat"):
            st.session_state["chat_history"] = []
            st.rerun()

    # ── Build / cache system prompt — include Fitch + forward-looking ──
    last_fitch = st.session_state.get("last_fitch", [])
    last_fwd = st.session_state.get("last_fwd", {})
    last_reg = st.session_state.get("last_reg", {})
    sp_key = f"sys_prompt_{company_name}_{len(last_segments)}_{len(news_items)}_{len(last_fitch)}"
    if sp_key not in st.session_state:
        # Build Fitch context string
        fitch_ctx = ""
        if last_fitch:
            fitch_ctx = "\n## Fitch ESG Factor Scores (1=not disclosed, 5=best practice)\n"
            for f in last_fitch:
                fitch_ctx += f"- {f['name']} ({f['factor_id']}): {f['score']}/5"
                ev = f.get("evidence", "")
                if ev and ev != "Not found":
                    fitch_ctx += f" — \"{ev[:80]}\""
                fitch_ctx += "\n"

        # Build forward-looking context string
        fwd_ctx = ""
        if last_fwd:
            from forward_looking import format_targets_markdown
            fwd_ctx = "\n## Forward-looking Commitments\n" + format_targets_markdown(last_fwd)

        # Regulatory context
        reg_ctx = ""
        if last_reg:
            csrd_pct = last_reg.get("csrd", {}).get("overall_pct", 0)
            tcfd_pct = last_reg.get("tcfd", {}).get("overall_pct", 0)
            eu_pct = last_reg.get("eu_taxonomy", {}).get("overall_pct", 0)
            reg_ctx = (
                f"\n## Regulatory Alignment\n"
                f"- CSRD/ESRS: {csrd_pct:.0f}% aligned\n"
                f"- TCFD: {tcfd_pct:.0f}% aligned\n"
                f"- EU Taxonomy: {eu_pct:.0f}% aligned\n"
            )

        combined_news = context_brief + fitch_ctx + fwd_ctx + reg_ctx

        st.session_state[sp_key] = build_system_prompt(
            company_name=company_name,
            segments=last_segments or None,
            esg=last_esg or None,
            news_summary=combined_news,
            pdf_text_snippets=last_pdf_text,
            currency=last_currency,
            unit=last_unit,
            reporting_period=last_period,
        )
    system_prompt = st.session_state[sp_key]

    # ── Initialise chat history ──
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    chat_history = st.session_state["chat_history"]

    # ── Suggested questions (shown when chat is empty) ──
    if not chat_history:
        st.html('<div style="font-size:11px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-3);margin-bottom:10px">Suggested questions</div>')
        suggested = get_suggested_questions(
            company_name,
            has_segments=bool(last_segments),
            has_esg=bool(last_esg),
            has_news=bool(news_items),
            segments=last_segments or None,
            esg=last_esg or None,
            fitch_factors=last_fitch or None,
            reg=last_reg or None,
        )
        btn_cols = st.columns(2)
        for i, q in enumerate(suggested):
            if btn_cols[i % 2].button(q, key=f"sq_{i}", use_container_width=True):
                st.session_state["pending_message"] = q
                st.rerun()
        st.divider()

    # ── Render existing messages ──
    for msg in chat_history:
        role = msg["role"]
        with st.chat_message(role, avatar=None):
            st.markdown(msg["content"])

    # ── Context status ──
    if not company_name and not last_segments:
        st.html('<div style="padding:12px 16px;background:var(--surface);border:1px solid var(--border);border-left:3px solid var(--gold);font-size:12px;color:var(--text-2);margin:8px 0">No issuer context loaded. Use <strong>Company Search</strong> or <strong>Document Intake</strong> first, or ask a general question.</div>')

    # ── Chat input ──
    pending = st.session_state.pop("pending_message", None)
    user_input = st.chat_input("Ask about segments, ESG scores, regulatory gaps, or credit risks…") or pending

    if user_input:
        with st.chat_message("user", avatar=None):
            st.markdown(user_input)

        with st.chat_message("assistant", avatar=None):
            response_placeholder = st.empty()
            full_response = ""

            for chunk in stream_chat_response(user_input, chat_history, system_prompt):
                full_response += chunk
                response_placeholder.markdown(full_response + "▌")

            response_placeholder.markdown(full_response)

        chat_history.append({"role": "user", "content": user_input})
        chat_history.append({"role": "assistant", "content": full_response})
        st.session_state["chat_history"] = chat_history


# ─────────────────────────────────────────────────────────────────────────────
# PAGE — ESG & Fitch Factors  (replaces old "ESG & Greenwashing")
# ─────────────────────────────────────────────────────────────────────────────

def page_esg_factors():
    _ticker()
    _page_header("ESG & Fitch Factor Analysis", "Full 15-factor Fitch ESG scoring · Greenwashing detection · Disclosure quality heat map.")

    esg_df = load_esg()
    fitch_df = load_fitch_factors()

    if esg_df.empty:
        st.info("No ESG data yet. Upload and analyse PDFs first.")
        return

    # ── Top metrics ──
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Docs scored", len(esg_df))
    m2.metric("Avg ESG", f"{esg_df['composite'].mean():.1f}/100" if "composite" in esg_df.columns else "—")
    flagged = int((esg_df["greenwashing_penalty"] > 5).sum()) if "greenwashing_penalty" in esg_df.columns else 0
    m3.metric("Greenwashing risk", flagged, delta=f"{flagged} docs" if flagged else "None", delta_color="inverse" if flagged else "normal")
    no_scope3 = int((~esg_df["has_scope3"].astype(bool)).sum()) if "has_scope3" in esg_df.columns else 0
    m4.metric("Missing Scope 3", no_scope3, delta_color="inverse" if no_scope3 else "normal")
    no_assured = int((~esg_df.get("has_third_party_assurance", pd.Series([True]*len(esg_df))).astype(bool)).sum())
    m5.metric("No 3rd-party assurance", no_assured, delta_color="inverse" if no_assured else "normal")

    st.divider()

    # ── Fitch factor heat map across all docs ──
    if not fitch_df.empty:
        st.subheader("Fitch ESG Factor Heat Map — All Documents")
        st.caption("Score 1 (red) = not disclosed → 5 (green) = best practice disclosure")

        _labels_heat = _load_labels()
        pivot = fitch_df.pivot_table(index="doc", columns="name", values="score", aggfunc="first")
        pivot.index = pivot.index.map(lambda d: _get_name(d, _labels_heat))

        score_colors = {1: "#4d1919", 2: "#3d2200", 3: "#2d2a00", 4: "#1a3a1a", 5: "#0d2d1e"}
        text_colors  = {1: "#f85149", 2: "#f0883e", 3: "#e3b341", 4: "#7ee787", 5: "#3fb950"}

        fig_heat = go.Figure(data=go.Heatmap(
            z=pivot.values,
            x=list(pivot.columns),
            y=list(pivot.index),
            colorscale=[[0, "#4d1919"], [0.25, "#3d2200"], [0.5, "#2d2a00"], [0.75, "#1a3a1a"], [1, "#0d2d1e"]],
            zmin=1, zmax=5,
            text=pivot.values,
            texttemplate="%{text:.0f}",
            textfont={"size": 12, "color": "white"},
            showscale=True,
            colorbar=dict(
                title=dict(text="Score", font=dict(color="#c9d1d9")),
                tickvals=[1, 2, 3, 4, 5],
                ticktext=["1 None", "2 Minimal", "3 Partial", "4 Good", "5 Best"],
                tickfont=dict(color="#c9d1d9"),
            ),
        ))
        fig_heat.update_layout(
            paper_bgcolor="#161b22", plot_bgcolor="#161b22", font_color="#c9d1d9",
            height=max(300, 60 * len(pivot)),
            margin=dict(t=20, b=60, l=10, r=10),
            xaxis=dict(tickangle=-35, tickfont=dict(size=10)),
            yaxis=dict(tickfont=dict(size=10)),
        )
        st.plotly_chart(fig_heat, width="stretch")

        # Per-factor average bar
        avg_scores = fitch_df.groupby(["factor_id", "name", "dimension"])["score"].mean().reset_index()
        avg_scores = avg_scores.sort_values("factor_id")
        dim_colors = {"E": "#3fb950", "S": "#58a6ff", "G": "#bc8cff"}
        avg_scores["color"] = avg_scores["dimension"].map(dim_colors)

        fig_bar = go.Figure(go.Bar(
            x=avg_scores["name"],
            y=avg_scores["score"],
            marker_color=avg_scores["color"],
            text=avg_scores["score"].apply(lambda x: f"{x:.1f}"),
            textposition="outside",
        ))
        fig_bar.update_layout(
            title="Average factor disclosure score across all documents",
            paper_bgcolor="#161b22", plot_bgcolor="#161b22", font_color="#c9d1d9",
            height=340, yaxis=dict(range=[0, 5.5], gridcolor="#30363d"), xaxis=dict(tickangle=-30),
            margin=dict(t=40, b=80, l=10, r=10),
        )
        st.plotly_chart(fig_bar, width="stretch")

        # Document deep-dive
        st.divider()
        st.subheader("Factor Deep-dive — Single Document")
        docs = sorted(fitch_df["doc"].unique())
        _labels_dd = _load_labels()
        sel_doc = st.selectbox("Select company", docs, format_func=lambda d: _get_name(d, _labels_dd))
        doc_factors = fitch_df[fitch_df["doc"] == sel_doc].sort_values("factor_id")

        cols_e, cols_s, cols_g = st.columns(3)
        for dim, col, label in [("E", cols_e, "🌱 Environmental"), ("S", cols_s, "👥 Social"), ("G", cols_g, "🏛 Governance")]:
            with col:
                st.markdown(f"**{label}**")
                subset = doc_factors[doc_factors["dimension"] == dim]
                for _, row in subset.iterrows():
                    sc = int(row["score"])
                    cls = f"fitch-{sc}"
                    st.markdown(
                        f'<div style="margin:4px 0;padding:6px 10px;border-radius:6px;background:var(--surface-alt)">'
                        f'<div style="display:flex;justify-content:space-between">'
                        f'<span style="font-size:12px;color:var(--text);font-weight:600">{row["name"]}</span>'
                        f'<span class="fitch-cell {cls}">{sc}/5</span></div>'
                        + (f'<div style="font-size:11px;color:var(--muted);margin-top:3px">{str(row.get("evidence",""))[:100]}</div>' if row.get("evidence") and row.get("evidence") != "Not found" else "")
                        + "</div>",
                        unsafe_allow_html=True,
                    )
    else:
        st.info("No Fitch factor data yet — upload PDFs to generate factor scores.")

    st.divider()

    # ── Greenwashing table ──
    st.subheader("Greenwashing Risk Table")
    flag_cols = [c for c in ["doc", "rating", "composite", "greenwashing_penalty", "greenwashing_flags",
                               "has_scope1", "has_scope2", "has_scope3", "has_third_party_assurance"] if c in esg_df.columns]
    styled = esg_df.sort_values("greenwashing_penalty", ascending=False)[flag_cols]
    st.dataframe(styled, use_container_width=True, hide_index=True)

    # ── Score distribution ──
    st.divider()
    col_l, col_r = st.columns(2)
    with col_l:
        fig_hist = px.histogram(esg_df, x="composite", nbins=15, title="ESG Composite Distribution",
                                color_discrete_sequence=["#238636"])
        fig_hist.add_vline(x=50, line_dash="dash", line_color="#8b949e", annotation_text="50 baseline")
        fig_hist.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                               font_color="#c9d1d9", height=300, margin=dict(t=40, b=20))
        st.plotly_chart(fig_hist, width="stretch")
    with col_r:
        if all(c in esg_df.columns for c in ["e_score", "g_score", "greenwashing_penalty"]):
            fig_sc = px.scatter(esg_df, x="g_score", y="e_score", size_max=30,
                                size=esg_df["greenwashing_penalty"].clip(lower=1),
                                color="greenwashing_penalty", hover_data=["doc", "composite", "rating"],
                                color_continuous_scale="RdYlGn_r",
                                title="Environmental vs Governance (bubble = greenwashing)",
                                labels={"g_score": "Governance", "e_score": "Environmental"})
            fig_sc.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                                  font_color="#c9d1d9", height=300, margin=dict(t=40, b=20))
            st.plotly_chart(fig_sc, width="stretch")


# ─────────────────────────────────────────────────────────────────────────────
# PAGE — Regulatory Mapping
# ─────────────────────────────────────────────────────────────────────────────

def page_regulatory():
    _ticker()
    _page_header("Regulatory Mapping", "CSRD / ESRS · TCFD · EU Taxonomy — disclosure gap analysis against each framework.")

    reg_session = st.session_state.get("last_reg", {})
    reg_df = load_regulatory_gaps()
    company = st.session_state.get("current_company", "")

    has_session = bool(reg_session)
    has_csv = not reg_df.empty and "doc" in reg_df.columns

    if not has_session and not has_csv:
        st.info("No regulatory data yet — upload a PDF and run the full analysis to see CSRD / TCFD / EU Taxonomy gap checks here.")
        return

    # ── Source selector: session state (current PDF) vs CSV (all processed) ──
    view_mode = st.radio(
        "Data source",
        ["Current document (session)", "All processed documents (CSV)"],
        horizontal=True,
        label_visibility="collapsed",
    ) if has_session and has_csv else (
        "Current document (session)" if has_session else "All processed documents (CSV)"
    )

    # ── SESSION STATE view — rich requirement-level detail ──
    if view_mode == "Current document (session)" and has_session:
        if company:
            st.caption(f"Showing regulatory analysis for: **{company}**")

        # Overall compliance KPIs across all frameworks
        fw_configs = [
            ("csrd", "CSRD / ESRS", "📑", "#0969da"),
            ("tcfd", "TCFD", "🌡", "#1a7f37"),
            ("eu_taxonomy", "EU Taxonomy", "🌿", "#9a6700"),
        ]

        # Top-level compliance overview row
        kpi_cols = st.columns(3)
        for col_i, (fw_key, fw_label, fw_icon, fw_color) in enumerate(fw_configs):
            fw_data = reg_session.get(fw_key, {})
            pct = fw_data.get("overall_pct", 0) if fw_data else 0
            d = fw_data.get("disclosed_count", 0) if fw_data else 0
            total = (fw_data.get("disclosed_count", 0) +
                     fw_data.get("partial_count", 0) +
                     fw_data.get("not_disclosed_count", 0)) if fw_data else 0
            pct_color = "#1a7f37" if pct >= 70 else "#9a6700" if pct >= 40 else "#cf222e"
            kpi_cols[col_i].markdown(
                f'<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;'
                f'padding:16px;text-align:center;">'
                f'<div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;'
                f'letter-spacing:0.8px;margin-bottom:6px;">{fw_icon} {fw_label}</div>'
                f'<div style="font-size:36px;font-weight:800;color:{pct_color};">{pct:.0f}%</div>'
                f'<div style="font-size:11px;color:var(--muted);margin-top:2px;">{d} / {total} disclosed</div>'
                f'<div style="background:var(--border);border-radius:3px;height:5px;margin-top:8px;">'
                f'<div style="background:{pct_color};height:5px;border-radius:3px;width:{pct:.1f}%;"></div></div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        st.write("")

        # Per-framework detailed breakdown
        for fw_key, fw_label, fw_icon, fw_color in fw_configs:
            fw_data = reg_session.get(fw_key, {})
            if not fw_data:
                continue
            reqs = fw_data.get("requirements", [])
            d = fw_data.get("disclosed_count", 0)
            p = fw_data.get("partial_count", 0)
            n = fw_data.get("not_disclosed_count", 0)
            total = d + p + n
            pct = fw_data.get("overall_pct", 0)

            with st.expander(f"{fw_icon} {fw_label} — {pct:.0f}% disclosed ({d}/{total} requirements)", expanded=False):
                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Overall alignment", f"{pct:.0f}%")
                m2.metric("✅ Disclosed", d)
                m3.metric("🟡 Partial", p)
                m4.metric("❌ Missing", n)

                if total > 0:
                    st.markdown(
                        f'<div style="background:var(--border);border-radius:4px;height:8px;margin:4px 0 16px">'
                        f'<div style="background:{fw_color};height:8px;border-radius:4px;width:{d/total*100:.1f}%"></div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

                if reqs:
                    # Status filter
                    status_filter = st.radio(
                        "Show", ["All", "✅ Disclosed", "🟡 Partial", "❌ Not Found"],
                        horizontal=True, key=f"filter_{fw_key}"
                    )
                    filter_map = {
                        "All": None,
                        "✅ Disclosed": "disclosed",
                        "🟡 Partial": "partial",
                        "❌ Not Found": "not_disclosed",
                    }
                    filtered = reqs if not filter_map[status_filter] else [
                        r for r in reqs if r.get("status", "not_disclosed") == filter_map[status_filter]
                    ]

                    for req in filtered:
                        status = req.get("status", "not_disclosed")
                        badge_cls = "gap-disclosed" if status == "disclosed" else ("gap-partial" if status == "partial" else "gap-missing")
                        badge_label = "✅ Disclosed" if status == "disclosed" else ("🟡 Partial" if status == "partial" else "❌ Not Found")
                        evidence = str(req.get("evidence", "")).strip()
                        ev_snippet = evidence[:200] + "…" if len(evidence) > 200 else evidence
                        req_text = str(req.get("requirement", req.get("requirement_id", "")))
                        req_id = str(req.get("id", req.get("requirement_id", "")))
                        st.markdown(
                            f'<div style="display:flex;gap:10px;align-items:flex-start;margin:5px 0;'
                            f'padding:9px 12px;background:var(--surface-alt);border-radius:7px;">'
                            f'<span class="{badge_cls}" style="white-space:nowrap;margin-top:1px;">{badge_label}</span>'
                            f'<div style="flex:1;">'
                            f'<div style="font-size:12px;font-weight:600;color:var(--text);">'
                            f'<code style="font-size:10px;color:var(--muted);">{req_id}</code> {req_text[:120]}</div>'
                            + (f'<div style="font-size:11px;color:var(--muted);margin-top:3px;line-height:1.4;">{ev_snippet}</div>'
                               if ev_snippet and ev_snippet.lower() not in ("not found", "not_found", "") else "")
                            + '</div></div>',
                            unsafe_allow_html=True,
                        )
                else:
                    st.info(f"No detailed requirements available for {fw_label}.")

    # ── Online enrichment for gaps ──────────────────────────────────────────
    if view_mode == "Current document (session)" and has_session and company:
        st.write("")
        st.markdown(
            '<div style="margin:20px 0 10px;padding-bottom:8px;border-bottom:1px solid var(--border);">'
            '<span style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);">'
            'Online Gap Enrichment</span></div>',
            unsafe_allow_html=True,
        )
        col_enrich_a, col_enrich_b = st.columns([3, 9])
        with col_enrich_a:
            enrich_gaps = st.button("Search online for missing disclosures", key="reg_enrich_btn", type="primary")
        with col_enrich_b:
            st.caption("Searches public sources (sustainability reports, press releases, company website) for evidence "
                       "of regulatory disclosures not found in the uploaded PDF. A disclaimer is added to any data sourced externally.")

        if enrich_gaps or st.session_state.get("reg_online_data"):
            if enrich_gaps:
                from company_search import search_regulatory_context, summarize_regulatory_gaps_online
                fw_findings: dict = {}
                for fw_key, fw_label, _, _ in fw_configs:
                    fw_data = reg_session.get(fw_key, {})
                    if not fw_data:
                        continue
                    missing = [r for r in fw_data.get("requirements", []) if r.get("status") == "not_disclosed"]
                    if not missing:
                        continue
                    missing_topics = [r.get("topic", r.get("id", "")) for r in missing[:6]]
                    with st.spinner(f"Searching online for {company} {fw_label} disclosures…"):
                        hits = search_regulatory_context(company, fw_label, missing_topics)
                        summary = summarize_regulatory_gaps_online(company, fw_label, missing, hits)
                    fw_findings[fw_label] = {"summary": summary, "hits": hits, "missing_count": len(missing)}
                st.session_state["reg_online_data"] = fw_findings
                st.session_state["reg_online_company"] = company

            online_findings = st.session_state.get("reg_online_data", {})
            online_company = st.session_state.get("reg_online_company", company)

            if online_findings:
                st.info(
                    f"**Data source note:** The following information was retrieved from publicly available online "
                    f"sources for **{online_company}** and was NOT extracted from the uploaded PDF filing. "
                    "It is provided for context only and should be independently verified before use in investment decisions.",
                    icon="ℹ️",
                )
                for fw_label, finding in online_findings.items():
                    summary = finding.get("summary", "")
                    missing_count = finding.get("missing_count", 0)
                    with st.expander(f"{fw_label} — {missing_count} gaps searched online", expanded=True):
                        if summary:
                            st.markdown(summary)
                        else:
                            st.caption("No relevant online evidence found for missing requirements.")
                        hits = finding.get("hits", [])
                        if hits:
                            st.caption("Sources consulted:")
                            for h in hits[:4]:
                                url = h.get("url", "")
                                title = h.get("title", url[:60])
                                if url:
                                    st.markdown(f"- [{title}]({url})", unsafe_allow_html=False)
            else:
                st.info("No gap data found — ensure a PDF has been processed with regulatory analysis enabled.")

    # ── CSV VIEW — cross-document comparison ──
    if view_mode == "All processed documents (CSV)" and has_csv:
        docs = sorted(reg_df["doc"].unique())
        sel_doc = st.selectbox("Select document to inspect", docs)
        doc_reg = reg_df[reg_df["doc"] == sel_doc]

        if "status" in doc_reg.columns:
            m1, m2, m3, m4 = st.columns(4)
            d = int((doc_reg["status"] == "disclosed").sum())
            p = int((doc_reg["status"] == "partial").sum())
            n = int((doc_reg["status"] == "not_disclosed").sum())
            total = d + p + n
            pct = (d * 1.0 + p * 0.5) / total * 100 if total else 0
            m1.metric("Weighted alignment", f"{pct:.0f}%", help="Full disclosure=100%, Partial=50%, Not disclosed=0%")
            m2.metric("✅ Disclosed", d)
            m3.metric("🟡 Partial", p)
            m4.metric("❌ Gap", n)

        st.dataframe(doc_reg, use_container_width=True)

        if len(docs) > 1:
            st.subheader("Cross-document Compliance Comparison")
            st.caption("Scores: Fully disclosed = 100%, Partial = 50%, Not disclosed = 0%. Weighted average per document.")

            def _compliance_score(x):
                total = max(len(x), 1)
                full  = (x == "disclosed").sum()
                part  = (x == "partial").sum()
                return round((full * 1.0 + part * 0.5) / total * 100, 1)

            compliance = reg_df.groupby("doc")["status"].apply(_compliance_score).reset_index()
            compliance.columns = ["doc", "compliance_pct"]
            compliance = _apply_labels(compliance, _load_labels())
            compliance = compliance.sort_values("compliance_pct", ascending=True)

            # Color each bar: red < 25, amber 25-50, green > 50
            compliance["bar_color"] = compliance["compliance_pct"].apply(
                lambda v: "#c41e24" if v < 25 else ("#e3b341" if v < 50 else "#3fb950")
            )

            fig = go.Figure(go.Bar(
                y=compliance["doc_short"],
                x=compliance["compliance_pct"],
                orientation="h",
                marker_color=compliance["bar_color"].tolist(),
                text=compliance["compliance_pct"].apply(lambda v: f"{v:.0f}%"),
                textposition="outside",
                hovertemplate="%{y}<br>Disclosure score: %{x:.1f}%<extra></extra>",
            ))
            fig.add_vline(x=75, line_dash="dash", line_color="#58a6ff",
                          annotation_text="75% target", annotation_font_color="#58a6ff",
                          annotation_position="top right")
            fig.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                font_color="#c9d1d9",
                height=max(280, 45 * len(docs) + 80),
                margin=dict(t=20, b=20, l=10, r=80),
                xaxis=dict(range=[0, 115], showgrid=True, gridcolor="rgba(48,54,61,0.4)",
                           ticksuffix="%", showticklabels=True),
                yaxis=dict(showgrid=False),
            )
            st.plotly_chart(fig, width="stretch")

    # ── Live Regulatory Intelligence ──────────────────────────────────────────
    st.markdown(
        '<div style="margin:32px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--border);">'
        '<span style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);">'
        'Live Regulatory Intelligence</span></div>',
        unsafe_allow_html=True,
    )

    col_btn, col_status = st.columns([3, 9])
    with col_btn:
        fetch_clicked = st.button("Fetch Live Updates", key="reg_fetch_btn", type="primary")
    with col_status:
        if "reg_live_ts" in st.session_state:
            st.markdown(
                f'<div style="padding:8px 0;font-size:11px;color:var(--muted);">'
                f'Last fetched: <strong style="color:var(--text);">{st.session_state.reg_live_ts}</strong>'
                f'</div>',
                unsafe_allow_html=True,
            )

    if fetch_clicked:
        with st.spinner("Fetching live regulatory updates from EUR-Lex, TCFD & EU Taxonomy…"):
            results = _fetch_regulatory_live()
        st.session_state.reg_live_data = results
        from datetime import datetime
        st.session_state.reg_live_ts = datetime.now().strftime("%d %b %Y, %H:%M UTC")
        st.rerun()

    if "reg_live_data" in st.session_state:
        live = st.session_state.reg_live_data
        tabs = st.tabs(["CSRD / ESRS (EUR-Lex)", "TCFD", "EU Taxonomy"])

        source_meta = [
            ("eurlex", "https://eur-lex.europa.eu"),
            ("tcfd",   "https://www.fsb-tcfd.org"),
            ("taxonomy", "https://ec.europa.eu/sustainable-finance-taxonomy"),
        ]
        for tab_ui, (src_key, src_url) in zip(tabs, source_meta):
            with tab_ui:
                items = live.get(src_key, [])
                if not items:
                    st.info("No updates retrieved — the source may be temporarily unavailable.")
                else:
                    for item in items:
                        title = item.get("title", "").strip()
                        snippet = item.get("snippet", "").strip()
                        link = item.get("link", "").strip()
                        date_str = item.get("date", "").strip()

                        date_badge = (
                            f'<span style="font-size:10px;color:var(--muted);margin-left:8px;">{date_str}</span>'
                            if date_str else ""
                        )
                        link_badge = (
                            f'<a href="{link}" target="_blank" style="font-size:10px;color:#c41e24;'
                            f'text-decoration:none;margin-left:8px;">↗ Source</a>'
                            if link else ""
                        )
                        st.markdown(
                            f'<div style="padding:10px 14px;margin:4px 0;background:var(--surface-alt);'
                            f'border-left:2px solid #c41e24;border-radius:0 6px 6px 0;">'
                            f'<div style="font-size:12px;font-weight:600;color:var(--text);">'
                            f'{title}{date_badge}{link_badge}</div>'
                            + (f'<div style="font-size:11px;color:var(--muted);margin-top:4px;line-height:1.5;">'
                               f'{snippet}</div>' if snippet else "")
                            + '</div>',
                            unsafe_allow_html=True,
                        )
                st.markdown(
                    f'<div style="margin-top:8px;font-size:10px;color:var(--muted);">'
                    f'Source: <a href="{src_url}" target="_blank" style="color:var(--muted);">{src_url}</a></div>',
                    unsafe_allow_html=True,
                )


@st.cache_data(ttl=3600, show_spinner=False)
def _fetch_regulatory_live() -> dict:
    """Scrape live regulatory updates from EUR-Lex, TCFD, and EU Taxonomy Compass."""
    import re as _re
    try:
        import requests as _req
        from bs4 import BeautifulSoup as _BS
    except ImportError:
        return {"eurlex": [], "tcfd": [], "taxonomy": []}

    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/123.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
    }
    TIMEOUT = 12

    def _safe_get(url):
        try:
            r = _req.get(url, headers=HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            return _BS(r.text, "html.parser")
        except Exception:
            return None

    results: dict = {"eurlex": [], "tcfd": [], "taxonomy": []}

    # ── EUR-Lex: search for CSRD / ESRS documents ────────────────────────────
    eurlex_url = (
        "https://eur-lex.europa.eu/search.html"
        "?scope=EURLEX&text=CSRD+ESRS+sustainability+reporting"
        "&lang=en&type=quick&qid=1&DTS_DOM=ALL"
        "&typeOfActStatus=REG_impl%2CREG%2CDIR&sortOne=DD&sortOneOrder=desc"
    )
    soup = _safe_get(eurlex_url)
    if soup:
        for item in soup.select(".SearchResult")[:8]:
            title_el = item.select_one("h2 a, .title a")
            date_el  = item.select_one(".date, .documentDate, time")
            desc_el  = item.select_one(".excerpt, .description, p")
            if title_el:
                href = title_el.get("href", "")
                if href and not href.startswith("http"):
                    href = "https://eur-lex.europa.eu" + href
                results["eurlex"].append({
                    "title":   title_el.get_text(strip=True)[:160],
                    "snippet": desc_el.get_text(strip=True)[:240] if desc_el else "",
                    "link":    href,
                    "date":    date_el.get_text(strip=True)[:30] if date_el else "",
                })

    # Fallback: EUR-Lex OJ RSS for CSRD keyword
    if not results["eurlex"]:
        rss_soup = _safe_get(
            "https://eur-lex.europa.eu/oj/direct-access.html?ojShortId=OJ.L"
        )
        if rss_soup:
            for a in rss_soup.select("table a[href*='uri-serv']")[:6]:
                text = a.get_text(strip=True)
                href = a.get("href", "")
                if not href.startswith("http"):
                    href = "https://eur-lex.europa.eu" + href
                if any(k in text.lower() for k in ("csrd", "esrs", "sustainab", "disclosure")):
                    results["eurlex"].append({"title": text[:160], "snippet": "", "link": href, "date": ""})

    # ── TCFD: FSB TCFD status page ────────────────────────────────────────────
    tcfd_url = "https://www.fsb-tcfd.org/tcfd-supporters-and-implementers/"
    soup = _safe_get(tcfd_url)
    if soup:
        for item in (soup.select(".post, article, .news-item, .update-item") or soup.select("section p"))[:6]:
            title_el = item.find(["h2", "h3", "h4", "strong"])
            date_el  = item.find("time") or item.select_one(".date")
            desc_el  = item.find("p")
            title = (title_el.get_text(strip=True) if title_el else item.get_text(strip=True)[:120])
            if len(title) < 10:
                continue
            link_el = item.find("a", href=True)
            href = link_el["href"] if link_el else tcfd_url
            if href and not href.startswith("http"):
                href = "https://www.fsb-tcfd.org" + href
            results["tcfd"].append({
                "title":   title[:160],
                "snippet": desc_el.get_text(strip=True)[:240] if desc_el else "",
                "link":    href,
                "date":    date_el.get_text(strip=True)[:30] if date_el else "",
            })

    # Fallback TCFD: main news page
    if not results["tcfd"]:
        soup2 = _safe_get("https://www.fsb-tcfd.org/news/")
        if soup2:
            for a in soup2.select("article h2 a, .entry-title a")[:6]:
                href = a.get("href", "")
                results["tcfd"].append({
                    "title": a.get_text(strip=True)[:160],
                    "snippet": "",
                    "link": href,
                    "date": "",
                })

    # ── EU Taxonomy Compass ────────────────────────────────────────────────────
    taxonomy_urls = [
        "https://ec.europa.eu/sustainable-finance-taxonomy/home",
        "https://finance.ec.europa.eu/sustainable-finance/tools-and-standards/eu-taxonomy-sustainable-activities_en",
    ]
    for t_url in taxonomy_urls:
        soup = _safe_get(t_url)
        if soup:
            for item in (soup.select(".news-item, article, .update, li.ecl-content-item") or
                         soup.select("main section")[:1])[:6]:
                title_el = item.find(["h2", "h3", "h4", "strong", "a"])
                desc_el  = item.find("p")
                link_el  = item.find("a", href=True)
                title = title_el.get_text(strip=True) if title_el else ""
                if len(title) < 8:
                    continue
                href = link_el["href"] if link_el else t_url
                if href and not href.startswith("http"):
                    href = "https://ec.europa.eu" + href
                results["taxonomy"].append({
                    "title":   title[:160],
                    "snippet": desc_el.get_text(strip=True)[:240] if desc_el else "",
                    "link":    href,
                    "date":    "",
                })
            if results["taxonomy"]:
                break

    # ── Static fallbacks if all scraping fails ────────────────────────────────
    if not results["eurlex"]:
        results["eurlex"] = [
            {"title": "CSRD — Corporate Sustainability Reporting Directive (Directive 2022/2464/EU)",
             "snippet": "Requires large companies and listed SMEs to report on sustainability matters. Applies from FY 2024 for companies already subject to NFRD.",
             "link": "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32022L2464", "date": "16 Dec 2022"},
            {"title": "ESRS Set 1 — European Sustainability Reporting Standards (Delegated Regulation 2023/2772)",
             "snippet": "Twelve cross-cutting and topical standards covering environment, social, and governance. Mandatory for CSRD-in-scope entities.",
             "link": "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=OJ:L_202302772", "date": "22 Dec 2023"},
        ]
    if not results["tcfd"]:
        results["tcfd"] = [
            {"title": "TCFD Final Status Report 2023",
             "snippet": "Over 4,000 organisations have expressed support for TCFD. The framework is now incorporated into IFRS S2 Climate-related Disclosures.",
             "link": "https://www.fsb-tcfd.org/publications/final-2023-tcfd-status-report/", "date": "Oct 2023"},
            {"title": "IFRS S2 Climate-related Disclosures — supersedes standalone TCFD recommendations",
             "snippet": "ISSB's IFRS S2 is built on TCFD and is now the global baseline for climate disclosure.",
             "link": "https://www.ifrs.org/issued-standards/ifrs-sustainability-standards-navigator/ifrs-s2-climate-related-disclosures/", "date": "Jun 2023"},
        ]
    if not results["taxonomy"]:
        results["taxonomy"] = [
            {"title": "EU Taxonomy Regulation (2020/852) — Climate & Environmental objectives",
             "snippet": "Classifies economic activities as environmentally sustainable. Six environmental objectives; technical screening criteria published via Delegated Acts.",
             "link": "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32020R0852", "date": "18 Jun 2020"},
            {"title": "Taxonomy Compass — interactive tool for screening criteria",
             "snippet": "The EU Taxonomy Compass lets users browse all technical screening criteria, DNSH conditions, and minimum social safeguards.",
             "link": "https://ec.europa.eu/sustainable-finance-taxonomy/", "date": ""},
        ]

    return results


# ─────────────────────────────────────────────────────────────────────────────
# PAGE — Portfolio Analytics
# ─────────────────────────────────────────────────────────────────────────────

def page_portfolio():
    _ticker()
    _page_header("Portfolio Analytics", "Cross-portfolio segment trends, currency exposure, NACE distribution, and ESG benchmarking across all processed documents.")

    extracted = load_extracted()
    esg_df = load_esg()
    fitch_df = load_fitch_factors()
    fwd_df = load_forward_looking()

    if extracted.empty and esg_df.empty:
        st.info("Upload and analyse multiple PDFs to enable portfolio benchmarking.")
        return

    def _chart_layout(fig, height=380, legend=True):
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font_color="#c9d1d9", height=height,
            margin=dict(t=40, b=30, l=10, r=10),
            legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="#30363d") if legend else dict(visible=False),
        )
        fig.update_xaxes(gridcolor="rgba(48,54,61,0.3)", showgrid=True)
        fig.update_yaxes(gridcolor="rgba(48,54,61,0.3)", showgrid=True)
        return fig

    COLORS = ["#58a6ff", "#3fb950", "#f0883e", "#bc8cff", "#e3b341", "#ff7b72", "#79c0ff"]

    def hex_to_rgba(hex_color, alpha=0.18):
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return f"rgba({r},{g},{b},{alpha})"

    n_docs = esg_df["doc"].nunique() if not esg_df.empty and "doc" in esg_df.columns else 0
    n_segs = len(extracted) if not extracted.empty else 0

    # ── Top KPI strip ──────────────────────────────────────────────────────────
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("Companies", n_docs or extracted["doc"].nunique() if not extracted.empty else 0)
    if not esg_df.empty and "composite" in esg_df.columns:
        k2.metric("Avg ESG Score", f"{esg_df['composite'].mean():.1f}/100")
        best_idx = esg_df["composite"].idxmax()
        k3.metric("Top ESG Company", _get_name(esg_df.loc[best_idx, "doc"]))
        worst_idx = esg_df["composite"].idxmin()
        k4.metric("Lowest ESG", _get_name(esg_df.loc[worst_idx, "doc"]))
    k5.metric("Total Segments", n_segs)

    # ── Auto-populate + allow editing company names ──
    all_known_docs = []
    for df in [extracted, esg_df, fitch_df, fwd_df]:
        if not df.empty and "doc" in df.columns:
            all_known_docs.extend(df["doc"].unique().tolist())
    labels = _ensure_labels(list(set(all_known_docs)))

    with st.expander("✏️ Edit Company Names", expanded=False):
        st.caption("Names are auto-detected from filenames. Edit any name below — saved names update everywhere instantly.")
        edited = {}
        cols_e = st.columns(2)
        for i, doc in enumerate(sorted(set(all_known_docs))):
            with cols_e[i % 2]:
                val = st.text_input(
                    "Company name",
                    value=labels.get(doc, _auto_name(doc)),
                    key=f"label_{doc}",
                    label_visibility="collapsed",
                )
                st.caption(f"📎 {doc[:60]}")
                edited[doc] = val
        if st.button("💾 Save company names", use_container_width=True):
            _save_labels(edited)
            labels = edited
            st.success("Saved! Charts will update with new names.")
            st.rerun()

    # ── Document Key ─────────────────────────────────────────────────────────
    # Shows the canonical company name → original filename mapping.
    with st.expander("📋 Document Key  —  Company Name → File", expanded=False):
        st.caption("Every document in this session listed by the company name used throughout the platform.")
        key_rows = []
        for doc in sorted(set(all_known_docs)):
            key_rows.append({
                "Company Name": labels.get(doc, _auto_name(doc)),
                "Original File": doc,
            })
        if key_rows:
            key_df = pd.DataFrame(key_rows).sort_values("Company Name").reset_index(drop=True)
            st.dataframe(
                key_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Company Name": st.column_config.TextColumn("Company Name", width="medium"),
                    "Original File": st.column_config.TextColumn("Original Filename / URL", width="large"),
                },
            )

    st.divider()

    # ─────────────────────────────────────────────────────────────────────────
    # TAB LAYOUT
    # ─────────────────────────────────────────────────────────────────────────
    tab_fin, tab_esg, tab_credit, tab_fitch, tab_nz = st.tabs([
        "💰 Financial", "🌱 ESG Comparison", "🏆 Credit Ratings", "📊 Fitch Factors", "🎯 Net-Zero & Climate"
    ])

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 1 — FINANCIAL
    # ═══════════════════════════════════════════════════════════════════════
    with tab_fin:
        if extracted.empty:
            st.info("No segment data yet — upload PDFs to see financial comparisons.")
        else:
            all_docs_fin = sorted(extracted["doc"].unique())
            sel_fin = st.multiselect(
                "Select companies to compare (leave blank = all)",
                all_docs_fin,
                default=all_docs_fin[:min(8, len(all_docs_fin))],
                format_func=lambda d: _get_name(d, labels),
                key="sel_fin",
            )
            sub_ext = extracted[extracted["doc"].isin(sel_fin)] if sel_fin else extracted
            sub_ext = _apply_labels(sub_ext, labels)

            non_total = sub_ext[sub_ext["is_total"] != True].copy() if "is_total" in sub_ext.columns else sub_ext.copy()
            non_total["value"] = pd.to_numeric(non_total["value"], errors="coerce").fillna(0)
            non_total_pos = non_total[non_total["value"] > 0]

            # ── Chart 1: Revenue per company (per-currency, horizontal bars) ──
            st.subheader("Total Reported Revenue by Company")
            st.caption("Each bar shows the sum of all non-elimination segments. Companies reporting in different currencies cannot be directly compared — values are shown in their native currency with the unit noted.")

            rev_summary = (
                non_total_pos.groupby(["doc_short", "currency", "unit"])
                .agg(total_rev=("value", "sum"))
                .reset_index()
            )
            if not rev_summary.empty:
                # One row per company — pick the dominant currency if multiple
                rev_by_company = (
                    rev_summary.sort_values("total_rev", ascending=False)
                    .drop_duplicates(subset="doc_short")
                    .sort_values("total_rev", ascending=True)
                    .reset_index(drop=True)
                )
                rev_by_company["bar_label"] = rev_by_company.apply(
                    lambda r: f"{r['total_rev']:,.0f} {r['currency']} {r['unit']}", axis=1
                )

                fig_rev = px.bar(
                    rev_by_company,
                    y="doc_short", x="total_rev",
                    color="currency",
                    orientation="h",
                    text="bar_label",
                    color_discrete_sequence=COLORS,
                    labels={"total_rev": "Revenue", "doc_short": "", "currency": "Currency"},
                )
                fig_rev.update_traces(textposition="outside", textfont_size=10)
                fig_rev = _chart_layout(fig_rev, height=max(320, len(rev_by_company) * 40 + 80))
                fig_rev.update_xaxes(
                    showgrid=True, showticklabels=False, title="",
                    exponentformat="none",
                )
                fig_rev.update_yaxes(showgrid=False, title="")
                st.plotly_chart(fig_rev, width="stretch")
            else:
                st.info("No positive segment values found in the selected documents.")

            st.divider()

            # ── Chart 2: Segment revenue MIX (% of total) ──────────────────
            st.subheader("Revenue Composition by Segment (%)")
            st.caption("Normalised to 100 % per company — shows how each company's revenue is split across business units, regardless of currency or scale. Useful for comparing business models.")

            seg_mix = non_total_pos[["doc_short", "segment", "value"]].copy()
            if not seg_mix.empty:
                company_totals = seg_mix.groupby("doc_short")["value"].sum().rename("co_total")
                seg_mix = seg_mix.join(company_totals, on="doc_short")
                seg_mix["pct"] = (seg_mix["value"] / seg_mix["co_total"] * 100).round(1)
                seg_mix["pct_label"] = seg_mix["pct"].apply(lambda x: f"{x:.0f}%")

                # Keep top 12 segments by total across all companies for legend clarity
                top_segs = (
                    seg_mix.groupby("segment")["value"].sum()
                    .nlargest(12).index.tolist()
                )
                seg_mix_plot = seg_mix[seg_mix["segment"].isin(top_segs)]

                # Sort companies by total revenue descending
                company_order = (
                    seg_mix.groupby("doc_short")["value"].sum()
                    .sort_values(ascending=False).index.tolist()
                )

                fig_mix = px.bar(
                    seg_mix_plot,
                    x="doc_short",
                    y="pct",
                    color="segment",
                    barmode="stack",
                    text="pct_label",
                    color_discrete_sequence=COLORS + ["#d2a679", "#7fbbff", "#b5ead7", "#ffd6a5"],
                    labels={"pct": "% of Revenue", "doc_short": "", "segment": "Segment"},
                    category_orders={"doc_short": company_order},
                )
                fig_mix.update_traces(textposition="inside", textfont_size=9, insidetextanchor="middle")
                fig_mix = _chart_layout(fig_mix, height=420)
                fig_mix.update_xaxes(tickangle=15, showgrid=False)
                fig_mix.update_yaxes(
                    range=[0, 105],
                    ticksuffix="%",
                    tickformat=".0f",
                    exponentformat="none",
                )
                st.plotly_chart(fig_mix, width="stretch")

            st.divider()

            # ── Chart 3: Segment diversification — count + confidence ───────
            col_a, col_b = st.columns(2)
            with col_a:
                st.subheader("Segment Count")
                st.caption("Number of distinct reportable segments per company. More segments = more diversified revenue.")
                seg_count = non_total_pos.groupby("doc_short")["segment"].nunique().reset_index()
                seg_count.columns = ["Company", "Segments"]
                seg_count["Segments"] = seg_count["Segments"].astype(int)
                seg_count = seg_count.sort_values("Segments", ascending=True)
                max_segs = int(seg_count["Segments"].max()) if not seg_count.empty else 10
                fig_sc = px.bar(
                    seg_count, y="Company", x="Segments",
                    orientation="h",
                    text="Segments",
                    color="Segments",
                    color_continuous_scale=["#1f3a5f", "#58a6ff", "#3fb950"],
                    labels={"Company": "", "Segments": "# Segments"},
                )
                fig_sc.update_traces(textposition="outside")
                fig_sc = _chart_layout(fig_sc, height=max(280, len(seg_count) * 32 + 60), legend=False)
                fig_sc.update_xaxes(
                    showgrid=False,
                    range=[0, max_segs + 3],
                    tickformat="d",
                    exponentformat="none",
                    dtick=max(1, max_segs // 5),
                )
                fig_sc.update_yaxes(showgrid=False)
                fig_sc.update_coloraxes(showscale=False)
                st.plotly_chart(fig_sc, width="stretch")

            with col_b:
                st.subheader("Currency Reporting Mix")
                st.caption("How many companies report in each currency — reflects geographic footprint of the portfolio.")
                curr_count = non_total_pos.groupby("currency")["doc_short"].nunique().reset_index()
                curr_count.columns = ["Currency", "Companies"]
                curr_count = curr_count.sort_values("Companies", ascending=False)
                fig_curr = px.pie(
                    curr_count, names="Currency", values="Companies",
                    color_discrete_sequence=COLORS, hole=0.45,
                )
                fig_curr.update_traces(
                    texttemplate="%{label}<br>%{value} co.",
                    textposition="outside",
                )
                fig_curr = _chart_layout(fig_curr, height=max(280, len(seg_count) * 32 + 60))
                st.plotly_chart(fig_curr, width="stretch")

            st.divider()

            # ── Chart 4: Extraction confidence per company ──────────────────
            if "extraction_confidence" in sub_ext.columns:
                st.subheader("Extraction Confidence")
                st.caption("AI confidence score for each segment extraction. Green ≥ 85%, amber ≥ 65%, red < 65% — values below 65% may warrant manual page override.")
                conf_df = (
                    sub_ext.groupby("doc_short")["extraction_confidence"]
                    .mean().reset_index()
                    .sort_values("extraction_confidence", ascending=True)
                )
                conf_df["pct"] = (conf_df["extraction_confidence"] * 100).round(1)
                conf_df["Status"] = conf_df["pct"].apply(
                    lambda v: "High (≥85%)" if v >= 85 else ("Medium (≥65%)" if v >= 65 else "Low (<65%)")
                )
                status_colors = {"High (≥85%)": "#3fb950", "Medium (≥65%)": "#e3b341", "Low (<65%)": "#ff7b72"}
                fig_conf = px.bar(
                    conf_df, y="doc_short", x="pct",
                    orientation="h",
                    color="Status",
                    color_discrete_map=status_colors,
                    text=conf_df["pct"].apply(lambda v: f"{v:.0f}%"),
                    labels={"pct": "Confidence %", "doc_short": "", "Status": "Band"},
                    range_x=[0, 115],
                )
                fig_conf.update_traces(textposition="outside")
                fig_conf.add_vline(x=85, line_dash="dot", line_color="#3fb950",
                                   annotation_text="85%", annotation_font_color="#3fb950",
                                   annotation_position="top right")
                fig_conf.add_vline(x=65, line_dash="dot", line_color="#e3b341",
                                   annotation_text="65%", annotation_font_color="#e3b341",
                                   annotation_position="top right")
                fig_conf = _chart_layout(fig_conf, height=max(260, len(conf_df) * 32 + 80))
                fig_conf.update_xaxes(
                    range=[0, 115],
                    tickformat=".0f",
                    ticksuffix="%",
                    exponentformat="none",
                    showgrid=True,
                )
                fig_conf.update_yaxes(showgrid=False)
                st.plotly_chart(fig_conf, width="stretch")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 2 — ESG COMPARISON
    # ═══════════════════════════════════════════════════════════════════════
    with tab_esg:
        if esg_df.empty:
            st.info("No ESG data yet.")
        else:
            all_docs_esg = sorted(esg_df["doc"].unique())
            sel_esg = st.multiselect(
                "Select companies",
                all_docs_esg,
                default=all_docs_esg[:min(6, len(all_docs_esg))],
                format_func=lambda d: _get_name(d, labels),
                key="sel_esg",
            )
            sub_esg = esg_df[esg_df["doc"].isin(sel_esg)].copy() if sel_esg else esg_df.copy()
            sub_esg = _apply_labels(sub_esg, labels)

            # ── ESG Ranking Table ──────────────────────────────────────────
            st.subheader("ESG Ranking")
            rank_cols = [c for c in ["doc_short", "doc", "rating", "composite", "e_score", "s_score", "g_score", "greenwashing_penalty"] if c in sub_esg.columns]
            rank_df = sub_esg[rank_cols].sort_values("composite", ascending=False).reset_index(drop=True)
            rank_df.index += 1
            rank_df = rank_df.rename(columns={"doc_short": "Company", "doc": "Source File"})
            rank_df.columns = [c if c in ("Company", "Source File") else c.replace("_", " ").title() for c in rank_df.columns]
            st.dataframe(rank_df, use_container_width=True)

            st.divider()

            col_r, col_b2 = st.columns(2)

            with col_r:
                # ── ESG Radar ──────────────────────────────────────────────
                st.subheader("ESG Radar — E / S / G")
                fig_radar = go.Figure()
                for i, (_, row) in enumerate(sub_esg.iterrows()):
                    e = float(row.get("e_score", 0) or 0)
                    s = float(row.get("s_score", 0) or 0)
                    g = float(row.get("g_score", 0) or 0)
                    c = COLORS[i % len(COLORS)]
                    fig_radar.add_trace(go.Scatterpolar(
                        r=[e, s, g, e],
                        theta=["Environmental", "Social", "Governance", "Environmental"],
                        fill="toself",
                        fillcolor=hex_to_rgba(c),
                        line_color=c,
                        name=row["doc_short"],
                    ))
                fig_radar.update_layout(
                    polar=dict(
                        bgcolor="rgba(0,0,0,0)",
                        radialaxis=dict(visible=True, range=[0, 100], gridcolor="rgba(48,54,61,0.4)", tickfont_color="#8b949e"),
                        angularaxis=dict(gridcolor="rgba(48,54,61,0.4)", tickfont_color="#c9d1d9"),
                    ),
                    paper_bgcolor="rgba(0,0,0,0)", font_color="#c9d1d9", height=380,
                    margin=dict(t=40, b=20, l=20, r=20),
                    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="#30363d"),
                )
                st.plotly_chart(fig_radar, width="stretch")

            with col_b2:
                # ── Composite ESG bar ──────────────────────────────────────
                st.subheader("Composite ESG Score")
                sorted_esg = sub_esg.sort_values("composite", ascending=True)
                fig_comp = go.Figure(go.Bar(
                    x=sorted_esg["composite"].tolist(),
                    y=sorted_esg["doc_short"].tolist(),
                    orientation="h",
                    marker=dict(
                        color=sorted_esg["composite"].tolist(),
                        colorscale="RdYlGn",
                        cmin=0, cmax=100,
                        showscale=False,
                    ),
                    text=[f"{v:.0f}" for v in sorted_esg["composite"]],
                    textposition="outside",
                ))
                fig_comp.add_vline(x=65, line_dash="dash", line_color="#58a6ff",
                                   annotation_text="AA threshold (65)")
                fig_comp = _chart_layout(fig_comp, height=380, legend=False)
                fig_comp.update_xaxes(range=[0, 115], showgrid=False)
                fig_comp.update_yaxes(showgrid=False)
                st.plotly_chart(fig_comp, width="stretch")

            # ── E / S / G grouped bar ──────────────────────────────────────
            st.subheader("E / S / G Dimension Breakdown")
            esg_melt = []
            for _, row in sub_esg.iterrows():
                for dim, col in [("Environmental", "e_score"), ("Social", "s_score"), ("Governance", "g_score")]:
                    esg_melt.append({"Company": row["doc_short"], "Dimension": dim, "Score": float(row.get(col, 0) or 0)})
            if esg_melt:
                esg_melt_df = pd.DataFrame(esg_melt)
                fig_esg_bar = px.bar(esg_melt_df, x="Dimension", y="Score", color="Company",
                                     barmode="group", color_discrete_sequence=COLORS,
                                     labels={"Score": "Score (0–100)"})
                fig_esg_bar = _chart_layout(fig_esg_bar, height=340)
                fig_esg_bar.update_xaxes(showgrid=False)
                fig_esg_bar.update_yaxes(range=[0, 115])
                st.plotly_chart(fig_esg_bar, width="stretch")

            # ── Greenwashing risk ──────────────────────────────────────────
            if "greenwashing_penalty" in sub_esg.columns:
                st.subheader("Greenwashing Risk Comparison")
                gw = sub_esg[["doc_short", "greenwashing_penalty"]].sort_values("greenwashing_penalty", ascending=False)
                fig_gw = px.bar(gw, x="doc_short", y="greenwashing_penalty",
                                color="greenwashing_penalty",
                                color_continuous_scale=[[0, "#3fb950"], [0.4, "#e3b341"], [1.0, "#f85149"]],
                                text="greenwashing_penalty",
                                labels={"greenwashing_penalty": "Penalty (pts)", "doc_short": ""})
                fig_gw.update_traces(texttemplate="−%{text:.0f}pts", textposition="outside")
                fig_gw = _chart_layout(fig_gw, height=320, legend=False)
                fig_gw.update_xaxes(showgrid=False, tickangle=20)
                st.plotly_chart(fig_gw, width="stretch")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 3 — CREDIT RATINGS
    # ═══════════════════════════════════════════════════════════════════════
    with tab_credit:
        if esg_df.empty or "rating" not in esg_df.columns:
            st.info("No rating data yet — process PDFs to generate ESG ratings.")
        else:
            st.subheader("ESG Credit Rating Distribution")

            rating_order = ["AAA", "AA", "A", "BBB", "BB", "B", "CCC", "—"]
            rating_colors_map = {
                "AAA": "#116329", "AA": "#1a7f37", "A": "#0969da",
                "BBB": "#9a6700", "BB": "#bc4c00", "B": "#cf222e", "CCC": "#a40000", "—": "#57606a",
            }

            esg_rated = esg_df.copy()
            esg_rated["rating_clean"] = esg_rated["rating"].fillna("—").replace("", "—")
            esg_rated = _apply_labels(esg_rated, labels)

            # Rating badge grid
            st.markdown("**Rating Summary**")
            cols_per_row = 4
            rows = [list(esg_rated.iterrows())[i:i+cols_per_row]
                    for i in range(0, len(esg_rated), cols_per_row)]
            for row_items in rows:
                cols = st.columns(cols_per_row)
                for col_i, (_, r) in enumerate(row_items):
                    rating = str(r.get("rating_clean", "—"))
                    composite = float(r.get("composite", 0) or 0)
                    r_color = rating_colors_map.get(rating, "#57606a")
                    r_bg = r_color + "18"
                    cols[col_i].markdown(
                        f'<div style="background:var(--surface);border:1px solid var(--border);'
                        f'border-radius:10px;padding:14px;text-align:center;border-top:3px solid {r_color};">'
                        f'<div style="font-size:10px;color:var(--muted);margin-bottom:6px;'
                        f'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{r["doc_short"]}</div>'
                        f'<div style="font-size:28px;font-weight:800;color:{r_color};">{rating}</div>'
                        f'<div style="font-size:12px;color:var(--muted);margin-top:4px;">{composite:.0f}/100</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

            st.divider()

            # ── Rating distribution donut ──────────────────────────────────
            col_d, col_t = st.columns(2)
            with col_d:
                st.subheader("Rating Distribution")
                rating_dist = esg_rated["rating_clean"].value_counts().reset_index()
                rating_dist.columns = ["Rating", "Count"]
                color_seq = [rating_colors_map.get(r, "#57606a") for r in rating_dist["Rating"]]
                fig_donut = px.pie(rating_dist, names="Rating", values="Count",
                                   color_discrete_sequence=color_seq, hole=0.5)
                fig_donut.update_traces(textinfo="label+value")
                fig_donut = _chart_layout(fig_donut, height=300)
                st.plotly_chart(fig_donut, width="stretch")

            with col_t:
                # ── Rating vs Composite scatter ────────────────────────────
                st.subheader("ESG Score Distribution")
                fig_hist = px.histogram(esg_rated, x="composite", nbins=10,
                                        color_discrete_sequence=["#58a6ff"],
                                        labels={"composite": "Composite ESG Score"})
                fig_hist.add_vline(x=65, line_dash="dash", line_color="#3fb950",
                                   annotation_text="AA (65)")
                fig_hist.add_vline(x=35, line_dash="dash", line_color="#e3b341",
                                   annotation_text="BBB (35)")
                fig_hist = _chart_layout(fig_hist, height=300, legend=False)
                st.plotly_chart(fig_hist, width="stretch")

            # ── Composite vs E/S/G scatter with rating color ───────────────
            st.subheader("Composite Score vs E/S/G Pillars")
            if all(c in esg_rated.columns for c in ["e_score", "s_score", "g_score"]):
                scatter_tab1, scatter_tab2, scatter_tab3 = st.tabs(["vs Environmental", "vs Social", "vs Governance"])
                for tab_s, dim, col_name in [
                    (scatter_tab1, "Environmental", "e_score"),
                    (scatter_tab2, "Social", "s_score"),
                    (scatter_tab3, "Governance", "g_score"),
                ]:
                    with tab_s:
                        fig_sc2 = px.scatter(
                            esg_rated, x=col_name, y="composite",
                            color="rating_clean",
                            color_discrete_map=rating_colors_map,
                            text="doc_short", size_max=18,
                            labels={col_name: f"{dim} Score", "composite": "Composite ESG"},
                            hover_data=["doc_short", "rating_clean"],
                        )
                        fig_sc2.update_traces(textposition="top center", textfont_size=9)
                        fig_sc2 = _chart_layout(fig_sc2, height=380)
                        st.plotly_chart(fig_sc2, width="stretch")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 4 — FITCH FACTORS
    # ═══════════════════════════════════════════════════════════════════════
    with tab_fitch:
        if fitch_df.empty:
            st.info("No Fitch factor data yet — upload PDFs to generate factor scores.")
        else:
            all_docs_fitch = sorted(fitch_df["doc"].unique())
            sel_fitch = st.multiselect(
                "Select companies",
                all_docs_fitch,
                default=all_docs_fitch[:min(5, len(all_docs_fitch))],
                format_func=lambda d: _get_name(d, labels),
                key="sel_fitch",
            )
            sub_fitch = fitch_df[fitch_df["doc"].isin(sel_fitch)].copy() if sel_fitch else fitch_df.copy()
            sub_fitch = _apply_labels(sub_fitch, labels)

            factor_col = "name" if "name" in sub_fitch.columns else "factor_id"
            score_col = "score"

            # ── Cross-company heatmap ──────────────────────────────────────
            st.subheader("Fitch Factor Cross-Company Heatmap")
            if factor_col in sub_fitch.columns and score_col in sub_fitch.columns:
                pivot = sub_fitch.pivot_table(
                    index=factor_col, columns="doc_short", values=score_col, aggfunc="first"
                ).fillna(0)

                z_vals = pivot.values.tolist()
                x_labels = list(pivot.columns)
                y_labels = list(pivot.index)

                # Build colorscale: 1=red → 3=yellow → 5=green
                colorscale = [
                    [0.0, "#cf222e"], [0.25, "#bc4c00"], [0.5, "#9a6700"],
                    [0.75, "#1a7f37"], [1.0, "#116329"]
                ]
                fig_heat = go.Figure(go.Heatmap(
                    z=z_vals, x=x_labels, y=y_labels,
                    colorscale=colorscale, zmin=1, zmax=5,
                    text=[[f"{v:.0f}" for v in row] for row in z_vals],
                    texttemplate="%{text}",
                    hovertemplate="%{y}<br>%{x}<br>Score: %{z:.0f}<extra></extra>",
                    colorbar=dict(title="Score", tickvals=[1,2,3,4,5],
                                  ticktext=["1-Weak","2","3-Avg","4","5-Strong"]),
                ))
                fig_heat.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)", font_color="#c9d1d9",
                    height=max(350, 30 * len(y_labels) + 120),
                    margin=dict(t=20, b=20, l=10, r=20),
                    xaxis=dict(tickangle=25, side="bottom"),
                )
                st.plotly_chart(fig_heat, width="stretch")

            # ── Average factor score by dimension ─────────────────────────
            st.subheader("Average Score by Dimension per Company")
            if "dimension" in sub_fitch.columns:
                dim_avg = (
                    sub_fitch.groupby(["doc_short", "dimension"])[score_col]
                    .mean().reset_index()
                )
                dim_avg.columns = ["Company", "Dimension", "Avg Score"]
                fig_dim = px.bar(dim_avg, x="Dimension", y="Avg Score",
                                 color="Company", barmode="group",
                                 color_discrete_sequence=COLORS,
                                 labels={"Avg Score": "Avg Score (1–5)"})
                fig_dim = _chart_layout(fig_dim, height=340)
                fig_dim.update_xaxes(showgrid=False)
                fig_dim.update_yaxes(range=[0, 5.8])
                st.plotly_chart(fig_dim, width="stretch")

            # ── Weakest factors across portfolio ──────────────────────────
            st.subheader("Weakest Factors Across Portfolio (avg score < 3)")
            if factor_col in sub_fitch.columns:
                weak = (
                    sub_fitch.groupby(factor_col)[score_col].mean()
                    .reset_index()
                    .sort_values(score_col)
                )
                weak.columns = ["Factor", "Avg Score"]
                weak_filtered = weak[weak["Avg Score"] < 3.5]
                if not weak_filtered.empty:
                    fig_weak = px.bar(weak_filtered, x="Avg Score", y="Factor",
                                      orientation="h",
                                      color="Avg Score",
                                      color_continuous_scale=[[0,"#cf222e"],[0.5,"#9a6700"],[1,"#1a7f37"]],
                                      range_color=[1, 5],
                                      text="Avg Score",
                                      labels={"Avg Score": "Average Score (1–5)", "Factor": ""})
                    fig_weak.update_traces(texttemplate="%{text:.1f}", textposition="outside")
                    fig_weak = _chart_layout(fig_weak, height=max(250, 35*len(weak_filtered)+80), legend=False)
                    fig_weak.update_xaxes(range=[0, 5.8], showgrid=False)
                    fig_weak.update_yaxes(showgrid=False)
                    st.plotly_chart(fig_weak, width="stretch")
                else:
                    st.success("All factors average ≥ 3.5 — solid across the board.")

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 5 — NET-ZERO & CLIMATE
    # ═══════════════════════════════════════════════════════════════════════
    with tab_nz:
        if fwd_df.empty:
            st.info("No forward-looking data yet.")
        else:
            col_nz, col_fw = st.columns(2)

            with col_nz:
                st.subheader("Net-Zero Target Year")
                if "net_zero_year" in fwd_df.columns:
                    nz = fwd_df[fwd_df["net_zero_year"].notna()][["doc", "net_zero_year"]].copy()
                    nz["net_zero_year"] = pd.to_numeric(nz["net_zero_year"], errors="coerce")
                    nz = nz.dropna().sort_values("net_zero_year")
                    nz = _apply_labels(nz, labels)
                    if not nz.empty:
                        fig_nz = px.bar(
                            nz, x="net_zero_year", y="doc_short", orientation="h",
                            color="net_zero_year",
                            color_continuous_scale=[[0,"#3fb950"],[0.5,"#e3b341"],[1,"#f85149"]],
                            range_color=[2030, 2060],
                            text="net_zero_year",
                            labels={"net_zero_year": "Target Year", "doc_short": ""},
                        )
                        fig_nz.update_traces(texttemplate="%{text:.0f}", textposition="outside")
                        fig_nz.add_vline(x=2050, line_dash="dash", line_color="#8b949e",
                                         annotation_text="2050")
                        fig_nz = _chart_layout(fig_nz, height=max(300, 45*len(nz)+80), legend=False)
                        fig_nz.update_xaxes(range=[2025, 2065], showgrid=False)
                        fig_nz.update_yaxes(showgrid=False)
                        st.plotly_chart(fig_nz, width="stretch")
                    else:
                        st.info("No net-zero year commitments found.")
                else:
                    st.info("Net-zero year data not available.")

            with col_fw:
                st.subheader("Frameworks Referenced")
                if "mentioned_frameworks" in fwd_df.columns or "frameworks" in fwd_df.columns:
                    fw_col = "mentioned_frameworks" if "mentioned_frameworks" in fwd_df.columns else "frameworks"
                    fw_list = []
                    for _, row in fwd_df.iterrows():
                        val = row.get(fw_col, "")
                        if isinstance(val, str) and val:
                            import ast
                            try:
                                items = ast.literal_eval(val)
                                if isinstance(items, list):
                                    fw_list.extend(items)
                            except Exception:
                                fw_list.extend([v.strip() for v in val.replace("[","").replace("]","").replace("'","").split(",")])
                        elif isinstance(val, list):
                            fw_list.extend(val)
                    if fw_list:
                        import collections
                        fw_counts = pd.DataFrame(
                            collections.Counter(fw_list).most_common(12),
                            columns=["Framework", "Count"]
                        )
                        fig_fw = px.bar(fw_counts, x="Count", y="Framework",
                                        orientation="h", color="Count",
                                        color_continuous_scale="Blues",
                                        text="Count",
                                        labels={"Count": "Documents referencing", "Framework": ""})
                        fig_fw.update_traces(textposition="outside")
                        fig_fw = _chart_layout(fig_fw, height=300, legend=False)
                        fig_fw.update_xaxes(showgrid=False)
                        fig_fw.update_yaxes(showgrid=False)
                        st.plotly_chart(fig_fw, width="stretch")
                    else:
                        st.info("No framework references parsed.")
                else:
                    st.info("No framework data in CSV.")

            # ── ESG vs Greenwashing scatter ────────────────────────────────
            if not esg_df.empty and "composite" in esg_df.columns and "greenwashing_penalty" in esg_df.columns:
                st.subheader("ESG Score vs Greenwashing Risk")
                fig_gw2 = px.scatter(
                    esg_df, x="composite", y="greenwashing_penalty",
                    color="rating" if "rating" in esg_df.columns else None,
                    text=esg_df["doc"].apply(lambda d: _get_name(d, labels)),
                    size="greenwashing_penalty",
                    size_max=25,
                    labels={"composite": "ESG Composite Score", "greenwashing_penalty": "Greenwashing Penalty (pts)"},
                    color_discrete_sequence=COLORS,
                )
                fig_gw2.update_traces(textposition="top center", textfont_size=9)
                fig_gw2 = _chart_layout(fig_gw2, height=380)
                st.plotly_chart(fig_gw2, width="stretch")


# ─────────────────────────────────────────────────────────────────────────────
# PAGE — Generate Report
# ─────────────────────────────────────────────────────────────────────────────

def page_report():
    from report_generator import generate_html_report

    _ticker()
    _page_header("Generate Report", "One-click professional Fitch-style research note — download as HTML, open in browser, print to PDF.")

    # ── Gather context — prefer session_state, fall back to CSV files ─────────
    company_name = st.session_state.get("current_company", "")
    segments     = st.session_state.get("last_segments", [])
    esg          = st.session_state.get("last_esg", {})
    fitch_factors= st.session_state.get("last_fitch", [])
    fwd          = st.session_state.get("last_fwd", {})
    reg          = st.session_state.get("last_reg", {})
    currency     = st.session_state.get("last_currency", "")
    unit         = st.session_state.get("last_unit", "")
    period       = st.session_state.get("last_period", "")
    news_items   = st.session_state.get("company_news", [])
    context_brief= st.session_state.get("context_brief", "")
    peers        = []

    # ── CSV fallback: rebuild context from persisted outputs if session expired ─
    if not segments and EXTRACTED_CSV.exists():
        try:
            ext_df = pd.read_csv(str(EXTRACTED_CSV))
            if not ext_df.empty and "doc" in ext_df.columns:
                # Use the most recently processed document
                last_doc = ext_df["doc"].iloc[-1]
                doc_rows = ext_df[ext_df["doc"] == last_doc]
                if not company_name:
                    company_name = _get_name(last_doc)
                    st.session_state["current_company"] = company_name
                seg_cols = ["segment", "value", "value_label", "is_total"]
                segs = doc_rows[[c for c in seg_cols if c in doc_rows.columns]].to_dict("records")
                if segs:
                    segments = segs
                    currency = str(doc_rows["currency"].iloc[0]) if "currency" in doc_rows.columns else ""
                    unit     = str(doc_rows["unit"].iloc[0])     if "unit"     in doc_rows.columns else ""
                    period   = str(doc_rows["reporting_period"].iloc[0]) if "reporting_period" in doc_rows.columns else ""
                    st.session_state["last_segments"] = segments
                    st.session_state["last_currency"] = currency
                    st.session_state["last_unit"]     = unit
                    st.session_state["last_period"]   = period
        except Exception:
            pass

    if not esg and ESG_CSV.exists():
        try:
            esg_df_r = pd.read_csv(str(ESG_CSV))
            if not esg_df_r.empty:
                if company_name:
                    match = esg_df_r[esg_df_r["doc"].apply(_get_name) == company_name]
                    row = match.iloc[-1] if not match.empty else esg_df_r.iloc[-1]
                else:
                    row = esg_df_r.iloc[-1]
                esg = row.dropna().to_dict()
                st.session_state["last_esg"] = esg
        except Exception:
            pass

    if not fitch_factors and FITCH_FACTORS_CSV.exists():
        try:
            ff_df = pd.read_csv(str(FITCH_FACTORS_CSV))
            if not ff_df.empty:
                doc_filter = ff_df["doc"].apply(_get_name) == company_name if company_name else pd.Series([True] * len(ff_df))
                subset = ff_df[doc_filter] if doc_filter.any() else ff_df
                # Get latest doc's factors
                latest_doc = subset["doc"].iloc[-1] if not subset.empty else None
                if latest_doc:
                    fitch_factors = ff_df[ff_df["doc"] == latest_doc].to_dict("records")
                    st.session_state["last_fitch"] = fitch_factors
        except Exception:
            pass

    search_key = f"search_{company_name.strip().lower()}"
    if search_key in st.session_state:
        peers = st.session_state[search_key].get("peers", [])

    # ── Preview / config ──
    col_cfg, col_prev = st.columns([1, 2])
    with col_cfg:
        st.subheader("Report settings")
        report_company = st.text_input("Company name on report", value=company_name or "Unknown Company")
        include_news = st.checkbox("Include news section", value=True)
        include_peers = st.checkbox("Include peer companies", value=bool(peers))
        include_reg = st.checkbox("Include regulatory gap analysis", value=bool(reg))
        enrich_online = st.checkbox(
            "Supplement with online sources",
            value=True,
            help="Fetch missing sections (executive summary, peers, news, sustainability commitments) from publicly available online sources. A disclaimer will be added to any data not found in the PDF.",
        )
        st.divider()
        st.markdown("**Context loaded:**")
        st.markdown(f"- Segments: **{len(segments)}**")
        st.markdown(f"- Fitch factors: **{len(fitch_factors)}/15**")
        st.markdown(f"- ESG score: **{esg.get('composite', '—')}/100**" if esg else "- ESG: **not loaded**")
        nz = fwd.get("net_zero_year") if fwd else None
        st.markdown(f"- Net-zero target: **{nz or 'not found'}**")
        st.markdown(f"- News items: **{len(news_items)}**")
        st.markdown(f"- CSRD alignment: **{reg.get('csrd', {}).get('overall_pct', 0):.0f}%**" if reg else "- Regulatory: **not run**")

    with col_prev:
        st.subheader("Generate & download")
        st.html("""
<div class="card card-accent-blue" style="font-size:12px;line-height:1.7">
  The report includes:<br>
  <b>Executive summary</b> &mdash; analyst bullets from PDF + online context<br>
  <b>Revenue segment breakdown</b> &mdash; table + SVG chart<br>
  <b>Fitch ESG factor heat map</b> &mdash; all 15 factors, colour-coded<br>
  <b>Regulatory gap analysis</b> &mdash; CSRD, TCFD, EU Taxonomy<br>
  <b>Forward-looking intelligence</b> &mdash; net-zero, targets, risks<br>
  <b>Recent news</b> &mdash; live market intelligence<br>
  <b>Peer companies</b> &mdash; Fitch peer group
</div>""")
        st.write("")

        if not segments and not esg:
            st.warning("Upload and analyse a PDF first, then come back to generate a report.")
        else:
            if st.button("Generate Research Note", use_container_width=True):
                online_disclaimer_sections: list[str] = []

                with st.spinner("Building report…"):
                    # ── Online enrichment ───────────────────────────────────────
                    enriched_news = list(news_items)
                    enriched_peers = list(peers)
                    enriched_brief = context_brief

                    if enrich_online and report_company:
                        from company_search import fetch_company_news, suggest_peer_companies, summarize_company_context

                        if len(enriched_news) < 3:
                            try:
                                with st.spinner("Fetching recent news…"):
                                    fetched = fetch_company_news(report_company, num_results=8)
                                if fetched:
                                    enriched_news = fetched
                                    online_disclaimer_sections.append("recent news")
                            except Exception:
                                pass
                        if not enriched_peers:
                            try:
                                with st.spinner("Identifying peer companies…"):
                                    enriched_peers = suggest_peer_companies(report_company)
                                if enriched_peers:
                                    online_disclaimer_sections.append("peer company suggestions")
                            except Exception:
                                pass

                        if not enriched_brief:
                            try:
                                with st.spinner("Generating analyst brief from online sources…"):
                                    enriched_brief = summarize_company_context(
                                        report_company,
                                        enriched_news,
                                        segments if segments else None,
                                        esg if esg else None,
                                    )
                                if enriched_brief:
                                    online_disclaimer_sections.append("analyst brief / executive summary")
                            except Exception:
                                pass

                    # Build disclaimer string
                    online_note = ""
                    if online_disclaimer_sections:
                        sections_str = ", ".join(online_disclaimer_sections)
                        online_note = (
                            f"**Data source note:** The following sections were supplemented with "
                            f"aggregate information from publicly available online sources because "
                            f"the relevant data was not found directly in the uploaded PDF filing: "
                            f"*{sections_str}*. This information is provided for context only and "
                            f"should be independently verified before use in investment decisions."
                        )

                    html_report = generate_html_report(
                        doc_name=report_company,
                        segments=segments,
                        esg=esg if esg else {},
                        fitch_factors=fitch_factors,
                        forward_looking=fwd if fwd else {},
                        regulatory_data=reg if include_reg else {},
                        peers=enriched_peers if include_peers else [],
                        news_items=enriched_news if include_news else [],
                        currency=currency,
                        unit=unit,
                        reporting_period=period,
                        context_brief=enriched_brief,
                        online_disclaimer=online_note,
                    )

                st.success("Report ready!")
                fname = f"{report_company.replace(' ','_')}_FinExtract_Report.html"
                st.download_button(
                    "Download HTML Report",
                    data=html_report.encode("utf-8"),
                    file_name=fname,
                    mime="text/html",
                    use_container_width=True,
                )
                if online_disclaimer_sections:
                    st.info(f"Online sources used for: {', '.join(online_disclaimer_sections)}. Disclaimer added to report.")
                st.caption("Open the downloaded file in your browser, then File → Print → Save as PDF.")
                with st.expander("Preview report HTML (first 2000 chars)"):
                    st.code(html_report[:2000], language="html")


# ── Router ────────────────────────────────────────────────────────────────────

if page == "Document Intake":
    page_upload()
elif page == "Company Search":
    page_company_search()
elif page == "Analyst Intelligence":
    page_chat()
elif page == "Portfolio Overview":
    page_dashboard()
elif page == "ESG & Fitch Factors":
    page_esg_factors()
elif page == "Regulatory Mapping":
    page_regulatory()
elif page == "Portfolio Analytics":
    page_portfolio()
elif page == "Generate Report":
    page_report()
elif page == "Document Key":
    page_document_key()
elif page == "NACE Classification":
    page_nace()
elif page == "Accuracy Validation":
    page_validation()
else:
    page_upload()
