import os
import re
import csv
import fitz

PDF_FOLDER = r"C:\Users\rahim\Desktop\Project4"
OUTPUT_CSV = r"C:\Users\rahim\Desktop\Project4\outputs\all_pages.csv"
IMAGE_ROOT = r"C:\Users\rahim\Desktop\Project4\outputs\page_images"

KEYWORDS_INCLUDE = [
    "segment",
    "operating segment",
    "business segment",
    "revenue",
    "net sales",
    "sales",
    "division",
]

KEYWORDS_EXCLUDE = [
    "geography",
    "geographic",
    "region",
    "country",
    "by market",
    "by destination",
]

def clean_text(text):
    text = text.replace("\x00", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text

def keyword_score(text):
    lower = text.lower()
    include_hits = sum(1 for kw in KEYWORDS_INCLUDE if kw in lower)
    exclude_hits = sum(1 for kw in KEYWORDS_EXCLUDE if kw in lower)
    return include_hits, exclude_hits

def main():
    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)
    os.makedirs(IMAGE_ROOT, exist_ok=True)

    pdf_files = [f for f in os.listdir(PDF_FOLDER) if f.lower().endswith(".pdf")]

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f_out:
        writer = csv.writer(f_out)
        writer.writerow([
            "pdf_name",
            "page_number",
            "total_pages",
            "text_length",
            "include_hits",
            "exclude_hits",
            "candidate_page",
            "page_text_preview",
            "page_text_full",
        ])

        for pdf_name in pdf_files:
            pdf_path = os.path.join(PDF_FOLDER, pdf_name)
            print(f"Processing: {pdf_name}")

            try:
                doc = fitz.open(pdf_path)
            except Exception as e:
                print(f"Failed: {e}")
                continue

            pdf_base = os.path.splitext(pdf_name)[0]
            pdf_image_folder = os.path.join(IMAGE_ROOT, pdf_base)
            os.makedirs(pdf_image_folder, exist_ok=True)

            total_pages = len(doc)

            for page_index in range(total_pages):
                page = doc[page_index]
                text = clean_text(page.get_text())

                include_hits, exclude_hits = keyword_score(text)
                candidate_page = 1 if include_hits > 0 else 0

                writer.writerow([
                    pdf_name,
                    page_index + 1,
                    total_pages,
                    len(text),
                    include_hits,
                    exclude_hits,
                    candidate_page,
                    text[:500],
                    text,
                ])

                if candidate_page == 1:
                    pix = page.get_pixmap()
                    pix.save(os.path.join(pdf_image_folder, f"page_{page_index+1}.png"))

            doc.close()

    print("DONE")

if __name__ == "__main__":
    main()