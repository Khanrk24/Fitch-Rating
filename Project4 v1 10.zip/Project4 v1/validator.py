"""
validator.py — Accuracy measurement engine
Compares extracted segment data against the ground truth spreadsheet.

Accuracy is measured per-row:
  - Segment name match: exact or fuzzy (≥85 token similarity)
  - Value match: within ±1% tolerance (handles rounding differences)
  - Value label match: case-insensitive
  - Currency match: exact
  - Unit match: exact
  - Reporting period match: within ±5 days

Final metrics reported:
  - Row-level precision, recall, F1
  - Field-level accuracy per column
  - Document-level accuracy
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

from config import GROUND_TRUTH_PATH, VALIDATION_CSV


# ── Matching helpers ──────────────────────────────────────────────────────────

def _normalise_str(s: str) -> str:
    return re.sub(r"\s+", " ", str(s).strip().lower())


def _name_match(a: str, b: str, threshold: int = 65) -> bool:
    """Fuzzy segment name match. Falls back to exact if rapidfuzz not available."""
    a, b = _normalise_str(a), _normalise_str(b)
    if a == b:
        return True
    if HAS_RAPIDFUZZ:
        return fuzz.token_sort_ratio(a, b) >= threshold
    # Fallback: check if one is a substring of the other
    return a in b or b in a


def _value_match(extracted: float, truth: float, tol: float = 0.01) -> bool:
    """Values match within ±1% (handles rounding)."""
    if truth == 0:
        return abs(extracted) < 1
    return abs((extracted - truth) / truth) <= tol


def _date_match(extracted: Optional[str], truth_dt: Optional[datetime], tol_days: int = 5) -> bool:
    if not extracted or truth_dt is None:
        return True  # skip date check if missing
    try:
        ext_dt = datetime.strptime(str(extracted)[:10], "%Y-%m-%d")
        return abs((ext_dt - truth_dt).days) <= tol_days
    except Exception:
        return False


def _label_match(a: str, b: str) -> bool:
    """Value label match — normalise whitespace and case."""
    return _normalise_str(a) == _normalise_str(b)


def _currency_match(a: str, b: str) -> bool:
    return str(a).strip().upper() == str(b).strip().upper()


def _unit_match(a: str, b: str) -> bool:
    return _normalise_str(a) == _normalise_str(b)


# ── Ground truth loader ───────────────────────────────────────────────────────

def load_ground_truth(path: Path = GROUND_TRUTH_PATH) -> pd.DataFrame:
    df = pd.read_excel(str(path))
    df.columns = [c.strip().lower() for c in df.columns]
    df["reporting_period"] = pd.to_datetime(df["reporting_period"], errors="coerce")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df


# ── Per-document validation ───────────────────────────────────────────────────

def validate_document(
    doc_name: str,
    extracted_segments: list[dict],
    ground_truth_df: pd.DataFrame,
) -> dict:
    """
    Compare extracted segments for one document against ground truth.
    Returns a dict with row-level match records and summary metrics.
    """
    gt = ground_truth_df[ground_truth_df["doc"] == doc_name].copy()
    if gt.empty:
        return {
            "doc": doc_name,
            "gt_rows": 0,
            "extracted_rows": len(extracted_segments),
            "matched_rows": 0,
            "precision": None,
            "recall": None,
            "f1": None,
            "matches": [],
        }

    matched_gt_indices = set()
    match_records = []

    for ext in extracted_segments:
        ext_seg = str(ext.get("segment", ""))
        ext_val = float(ext.get("value", 0) or 0)
        ext_label = str(ext.get("value_label", ""))
        ext_currency = str(ext.get("currency", ""))
        ext_unit = str(ext.get("unit", ""))
        ext_period = ext.get("reporting_period", "")

        best_gt_idx = None
        best_score = -1

        for idx, gt_row in gt.iterrows():
            if idx in matched_gt_indices:
                continue
            score = 0
            if _name_match(ext_seg, str(gt_row.get("segment", ""))):
                score += 3
            if _value_match(ext_val, float(gt_row.get("value", 0) or 0)):
                score += 3
            if _label_match(ext_label, str(gt_row.get("value_label", ""))):
                score += 1
            if _currency_match(ext_currency, str(gt_row.get("currency", ""))):
                score += 1
            if _unit_match(ext_unit, str(gt_row.get("unit", ""))):
                score += 1
            if score > best_score:
                best_score = score
                best_gt_idx = idx

        # Match if: name+value both strong (score>=6), OR value exact + some name overlap (score>=4)
        if best_gt_idx is not None and best_score >= 4:
            matched_gt_indices.add(best_gt_idx)
            gt_row = gt.loc[best_gt_idx]
            match_records.append({
                "doc": doc_name,
                "extracted_segment": ext_seg,
                "gt_segment": gt_row["segment"],
                "extracted_value": ext_val,
                "gt_value": gt_row["value"],
                "extracted_currency": ext_currency,
                "gt_currency": gt_row.get("currency", ""),
                "extracted_unit": ext_unit,
                "gt_unit": gt_row.get("unit", ""),
                "match_score": best_score,
                "name_match": _name_match(ext_seg, str(gt_row["segment"])),
                "value_match": _value_match(ext_val, float(gt_row["value"] or 0)),
                "currency_match": _currency_match(ext_currency, str(gt_row.get("currency", ""))),
                "unit_match": _unit_match(ext_unit, str(gt_row.get("unit", ""))),
                "matched": True,
            })
        else:
            match_records.append({
                "doc": doc_name,
                "extracted_segment": ext_seg,
                "gt_segment": None,
                "extracted_value": ext_val,
                "gt_value": None,
                "match_score": best_score,
                "matched": False,
            })

    # Unmatched ground truth rows (false negatives)
    for idx, gt_row in gt.iterrows():
        if idx not in matched_gt_indices:
            match_records.append({
                "doc": doc_name,
                "extracted_segment": None,
                "gt_segment": gt_row["segment"],
                "extracted_value": None,
                "gt_value": gt_row["value"],
                "match_score": 0,
                "matched": False,
            })

    n_gt = len(gt)
    n_ext = len(extracted_segments)
    n_matched = len(matched_gt_indices)

    precision = n_matched / n_ext if n_ext > 0 else 0.0
    recall = n_matched / n_gt if n_gt > 0 else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0

    return {
        "doc": doc_name,
        "gt_rows": n_gt,
        "extracted_rows": n_ext,
        "matched_rows": n_matched,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "matches": match_records,
    }


# ── Full validation report ────────────────────────────────────────────────────

def run_full_validation(
    all_extracted: list[dict],   # list of {doc, segments:[...]}
    ground_truth_path: Path = GROUND_TRUTH_PATH,
) -> dict:
    """
    Run validation across all extracted documents and produce a summary report.
    all_extracted: [{"doc": "82_Orsted...", "segments": [{...}, ...], ...}, ...]
    """
    gt_df = load_ground_truth(ground_truth_path)
    gt_docs = set(gt_df["doc"].unique())

    doc_results = []
    all_matches = []

    for doc_entry in all_extracted:
        doc_name = doc_entry["doc"]
        segments = doc_entry.get("segments", [])
        # Attach currency/unit from extraction to each segment if not already there
        for seg in segments:
            if "currency" not in seg:
                seg["currency"] = doc_entry.get("currency", "")
            if "unit" not in seg:
                seg["unit"] = doc_entry.get("unit", "")
            if "reporting_period" not in seg:
                seg["reporting_period"] = doc_entry.get("reporting_period", "")

        if doc_name in gt_docs:
            result = validate_document(doc_name, segments, gt_df)
            doc_results.append(result)
            all_matches.extend(result["matches"])

    # Aggregate metrics
    total_gt = sum(r["gt_rows"] for r in doc_results)
    total_matched = sum(r["matched_rows"] for r in doc_results)
    total_extracted = sum(r["extracted_rows"] for r in doc_results)

    overall_precision = total_matched / total_extracted if total_extracted > 0 else 0
    overall_recall = total_matched / total_gt if total_gt > 0 else 0
    overall_f1 = (
        2 * overall_precision * overall_recall / (overall_precision + overall_recall)
        if (overall_precision + overall_recall) > 0 else 0
    )

    # Save detailed match records
    if all_matches:
        match_df = pd.DataFrame(all_matches)
        match_df.to_csv(str(VALIDATION_CSV), index=False)
        print(f"Validation details saved to {VALIDATION_CSV}")

    return {
        "overall_precision": round(overall_precision, 4),
        "overall_recall": round(overall_recall, 4),
        "overall_f1": round(overall_f1, 4),
        "overall_accuracy": round(overall_recall, 4),  # recall = % of GT rows found
        "total_gt_rows": total_gt,
        "total_matched_rows": total_matched,
        "total_extracted_rows": total_extracted,
        "doc_results": doc_results,
        "meets_target": overall_recall >= 0.90,
    }


def print_report(validation: dict) -> None:
    sep = "=" * 60
    target_str = "YES" if validation["meets_target"] else "NO"
    lines = [
        f"\n{sep}",
        "VALIDATION REPORT",
        sep,
        f"Overall Accuracy (Recall):  {validation['overall_accuracy']:.1%}",
        f"Overall Precision:          {validation['overall_precision']:.1%}",
        f"Overall F1:                 {validation['overall_f1']:.1%}",
        f"Ground truth rows:          {validation['total_gt_rows']}",
        f"Matched rows:               {validation['total_matched_rows']}",
        f"Target met (>=90%):         {target_str}",
        "",
    ]
    for dr in validation.get("doc_results", []):
        lines.append(
            f"  {dr['doc'][:55]:<55} | recall={dr['recall']:.0%} "
            f"| precision={dr['precision']:.0%} | F1={dr['f1']:.0%}"
        )
    lines.append(sep)
    for line in lines:
        try:
            print(line)
        except UnicodeEncodeError:
            print(line.encode("ascii", errors="replace").decode())
