"""
report_generator.py — FinExtract AI
Generates a beautiful, professional HTML research note.
Self-contained — works when opened directly in a browser.
"""

from __future__ import annotations

import html
import re
from datetime import date
from typing import Optional


# ---------------------------------------------------------------------------
# Data normalisation helpers — map pipeline output keys → report keys
# ---------------------------------------------------------------------------

def _norm_segments(segments: list[dict]) -> list[dict]:
    """Accept either {name, revenue} or pipeline format {segment, value, ...}."""
    out = []
    for s in segments:
        name = s.get("name") or s.get("segment") or "Unknown"
        revenue = s.get("revenue") or s.get("value") or 0
        try:
            revenue = float(revenue)
        except (TypeError, ValueError):
            revenue = 0.0
        if s.get("is_total"):
            continue  # skip total rows in chart
        out.append({
            "name": name,
            "revenue": revenue,
            "yoy_growth": s.get("yoy_growth"),
            "value_label": s.get("value_label", "Revenue"),
        })
    return out


def _norm_fitch(factors: list[dict]) -> list[dict]:
    """Accept either {factor, category, score} or pipeline format {factor_id, dimension, name, ...}."""
    out = []
    for f in factors:
        factor_name = f.get("factor") or f.get("name") or f.get("factor_id") or ""
        category = f.get("category") or f.get("dimension") or "E"
        score = f.get("score") or 3
        description = f.get("description") or f.get("evidence") or ""
        try:
            score = int(float(score))
        except (TypeError, ValueError):
            score = 3
        out.append({
            "factor": factor_name,
            "category": str(category).upper()[:1],
            "score": score,
            "description": str(description)[:200],
            "disclosed": f.get("disclosed", True),
        })
    return out


def _norm_esg(esg: dict) -> dict:
    """Normalise ESG keys from pipeline output."""
    if not esg:
        return {}
    raw_flags = esg.get("greenwashing_flags") or []
    if isinstance(raw_flags, str) and raw_flags.strip():
        # Split on semicolon, newline, or pipe — fall back to single-item list
        gw_flags = [f.strip() for f in re.split(r"[;\n|]", raw_flags) if f.strip()]
        if not gw_flags:
            gw_flags = [raw_flags.strip()]
    else:
        gw_flags = list(raw_flags) if raw_flags else []
    return {
        "composite": esg.get("composite") or esg.get("composite_score") or esg.get("esg_score") or 0,
        "rating": esg.get("rating") or esg.get("esg_rating") or "",
        "e_score": esg.get("e_score") or esg.get("environmental_score") or 0,
        "s_score": esg.get("s_score") or esg.get("social_score") or 0,
        "g_score": esg.get("g_score") or esg.get("governance_score") or 0,
        "greenwashing_penalty": esg.get("greenwashing_penalty") or 0,
        "greenwashing_flags": gw_flags,
    }


# ---------------------------------------------------------------------------
# Markdown → HTML (simple inline renderer, no external deps)
# ---------------------------------------------------------------------------

def _md_to_html(text: str) -> str:
    """Convert a subset of Markdown to HTML for the analyst brief."""
    if not text:
        return ""
    lines = text.split("\n")
    out = []
    in_ul = False
    for raw in lines:
        line = raw.strip()
        if not line:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            out.append('<div style="height:8px;"></div>')
            continue
        if line.startswith("### "):
            if in_ul: out.append("</ul>"); in_ul = False
            h = html.escape(line[4:])
            out.append(f'<h4 style="color:#1f2328;font-size:13px;font-weight:700;margin:14px 0 4px;letter-spacing:0.3px;">{h}</h4>')
        elif line.startswith("## "):
            if in_ul: out.append("</ul>"); in_ul = False
            h = html.escape(line[3:])
            out.append(f'<h3 style="color:#1f2328;font-size:14px;font-weight:700;margin:16px 0 6px;border-bottom:1px solid #d0d7de;padding-bottom:4px;">{h}</h3>')
        elif line.startswith("# "):
            if in_ul: out.append("</ul>"); in_ul = False
            h = html.escape(line[2:])
            out.append(f'<h2 style="color:#1f2328;font-size:16px;font-weight:700;margin:16px 0 6px;">{h}</h2>')
        elif line.startswith("- ") or line.startswith("* "):
            if not in_ul:
                out.append('<ul style="margin:4px 0 4px 16px;padding:0;">')
                in_ul = True
            item = _md_inline(line[2:])
            out.append(f'<li style="color:#24292f;font-size:13px;padding:2px 0;line-height:1.5;">{item}</li>')
        elif line.startswith("---"):
            if in_ul: out.append("</ul>"); in_ul = False
            out.append('<hr style="border:none;border-top:1px solid #d0d7de;margin:12px 0;"/>')
        else:
            if in_ul: out.append("</ul>"); in_ul = False
            p = _md_inline(line)
            out.append(f'<p style="color:#24292f;font-size:13px;line-height:1.6;margin:4px 0;">{p}</p>')
    if in_ul:
        out.append("</ul>")
    return "\n".join(out)


def _md_inline(text: str) -> str:
    """Handle inline markdown: **bold**, *italic*, `code`."""
    text = html.escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r'<strong>\1</strong>', text)
    text = re.sub(r"\*(.+?)\*", r'<em>\1</em>', text)
    text = re.sub(r"`(.+?)`", r'<code style="background:#f0f0f0;padding:1px 5px;border-radius:3px;font-size:11px;">\1</code>', text)
    return text


# ---------------------------------------------------------------------------
# Score/rating helpers
# ---------------------------------------------------------------------------

def _score_color(score: int) -> str:
    return {1: "#cf222e", 2: "#bc4c00", 3: "#9a6700", 4: "#1a7f37", 5: "#116329"}.get(
        max(1, min(5, int(score or 1))), "#57606a"
    )


def _score_bg(score: int) -> str:
    return {1: "#ffebe9", 2: "#fff1e5", 3: "#fff8c5", 4: "#dafbe1", 5: "#d1f5db"}.get(
        max(1, min(5, int(score or 1))), "#f6f8fa"
    )


def _rating_colors(rating: str):
    r = (rating or "").upper()
    if "AAA" in r or "AA" in r:
        return "#dafbe1", "#116329"
    elif r.startswith("A"):
        return "#ddf4ff", "#0969da"
    elif "BBB" in r:
        return "#fff8c5", "#9a6700"
    elif "BB" in r:
        return "#fff1e5", "#bc4c00"
    else:
        return "#ffebe9", "#cf222e"


def _rag_badge_html(status: str) -> str:
    s = (status or "").lower().strip()
    if s in ("disclosed", "met", "green"):
        bg, fg, label, icon = "#dafbe1", "#1a7f37", "Disclosed", "✓"
    elif s in ("partial", "amber", "yellow"):
        bg, fg, label, icon = "#fff8c5", "#9a6700", "Partial", "~"
    else:
        bg, fg, label, icon = "#ffebe9", "#cf222e", "Not Found", "✗"
    return (
        f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:4px;'
        f'font-size:11px;font-weight:700;white-space:nowrap;border:1px solid {fg}30;">'
        f'{icon} {html.escape(label)}</span>'
    )


# ---------------------------------------------------------------------------
# SVG segment bar chart
# ---------------------------------------------------------------------------

def _segment_svg_chart(segments: list[dict], currency: str, unit: str) -> str:
    if not segments:
        return '<p style="color:#57606a;font-style:italic;padding:8px 0;">No segment revenue data available.</p>'

    capped = [s for s in segments if float(s.get("revenue", 0) or 0) != 0][:15]
    if not capped:
        capped = segments[:15]

    capped_sorted = sorted(capped, key=lambda s: float(s.get("revenue", 0) or 0), reverse=True)
    max_rev = max(abs(float(s.get("revenue", 0) or 0)) for s in capped_sorted) or 1

    bar_height = 26
    row_gap = 10
    label_w = 190
    bar_area = 380
    val_w = 130
    total_w = label_w + bar_area + val_w
    total_h = len(capped_sorted) * (bar_height + row_gap) + 36

    rows_svg = []
    for i, seg in enumerate(capped_sorted):
        name = html.escape(str(seg.get("name", f"Segment {i+1}")))[:35]
        revenue = float(seg.get("revenue", 0) or 0)
        bar_len = max(int(abs(revenue) / max_rev * bar_area * 0.88), 3)
        bar_color = "#1a7f37" if revenue >= 0 else "#cf222e"
        y = i * (bar_height + row_gap) + 28
        mid_y = y + bar_height // 2 + 4

        rows_svg.append(
            f'<text x="{label_w - 8}" y="{mid_y}" text-anchor="end" '
            f'fill="#24292f" font-size="12" font-family="-apple-system,sans-serif">{name}</text>'
            f'<rect x="{label_w}" y="{y}" width="{bar_len}" height="{bar_height - 4}" '
            f'fill="{bar_color}" rx="3" opacity="0.85"/>'
            f'<text x="{label_w + bar_len + 7}" y="{mid_y}" fill="#24292f" '
            f'font-size="12" font-family="monospace">{revenue:,.1f}</text>'
        )

    unit_label = html.escape(f"{currency} ({unit})")
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{total_h}" '
        f'style="max-width:100%;display:block;">'
        f'<text x="{label_w}" y="16" fill="#57606a" font-size="11" '
        f'font-family="monospace">{unit_label}</text>'
        + "".join(rows_svg)
        + "</svg>"
    )


# ---------------------------------------------------------------------------
# ESG score visual (horizontal bar gauge)
# ---------------------------------------------------------------------------

def _esg_bar(label: str, score: float, color: str) -> str:
    pct = min(max(float(score or 0), 0), 100)
    return (
        f'<div style="margin-bottom:10px;">'
        f'<div style="display:flex;justify-content:space-between;margin-bottom:3px;">'
        f'<span style="font-size:12px;font-weight:600;color:#24292f;">{html.escape(label)}</span>'
        f'<span style="font-size:12px;font-weight:700;color:{color};">{pct:.0f}</span>'
        f'</div>'
        f'<div style="background:#eaeef2;border-radius:4px;height:8px;overflow:hidden;">'
        f'<div style="background:{color};height:100%;width:{pct}%;border-radius:4px;'
        f'transition:width 0.3s;"></div></div></div>'
    )


# ---------------------------------------------------------------------------
# Fitch heatmap
# ---------------------------------------------------------------------------

def _fitch_heatmap_html(factors: list[dict]) -> str:
    if not factors:
        return '<p style="color:#57606a;font-style:italic;padding:8px 0;">Run Fitch analysis first.</p>'

    e = [f for f in factors if f.get("category", "").upper().startswith("E")]
    s = [f for f in factors if f.get("category", "").upper().startswith("S")]
    g = [f for f in factors if f.get("category", "").upper().startswith("G")]

    def _col(factors_list: list, dim_label: str, dim_color: str) -> str:
        cells = ""
        for f in factors_list:
            sc = max(1, min(5, int(f.get("score", 3) or 3)))
            bg = _score_bg(sc)
            fg = _score_color(sc)
            name = html.escape(str(f.get("factor", "")))
            desc = html.escape(str(f.get("description", ""))[:90])
            dots = "".join(
                f'<span style="display:inline-block;width:10px;height:10px;border-radius:50%;'
                f'background:{_score_color(d) if d <= sc else "#d0d7de"};margin-right:2px;">'
                f'</span>'
                for d in range(1, 6)
            )
            cells += (
                f'<div style="background:{bg};border:1px solid {fg}30;border-radius:6px;'
                f'padding:8px 10px;margin-bottom:6px;">'
                f'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;">'
                f'<span style="font-size:12px;font-weight:700;color:#1f2328;">{name}</span>'
                f'<span style="font-size:13px;font-weight:800;color:{fg};">{sc}/5</span>'
                f'</div>'
                + (f'<div style="font-size:10px;color:#57606a;margin-bottom:4px;line-height:1.3;">'
                   f'{desc}</div>' if desc else "")
                + f'<div>{dots}</div></div>'
            )
        return (
            f'<div style="flex:1;min-width:180px;">'
            f'<div style="background:{dim_color};color:#fff;text-align:center;padding:6px;'
            f'border-radius:6px;font-size:11px;font-weight:700;letter-spacing:0.5px;'
            f'margin-bottom:8px;">{html.escape(dim_label)}</div>'
            f'{cells}</div>'
        )

    return (
        '<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-start;">'
        + _col(e, "E — Environmental", "#1a7f37")
        + _col(s, "S — Social", "#0969da")
        + _col(g, "G — Governance", "#9a6700")
        + "</div>"
        + '<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">'
        + "".join(
            f'<span style="background:{_score_bg(sc)};color:{_score_color(sc)};'
            f'padding:2px 8px;border-radius:3px;font-size:10px;font-weight:600;'
            f'border:1px solid {_score_color(sc)}30;">'
            f'{sc} — {["Weak","Below Avg","Average","Above Avg","Strong"][sc-1]}</span>'
            for sc in range(1, 6)
        )
        + "</div>"
    )


# ---------------------------------------------------------------------------
# Regulatory table
# ---------------------------------------------------------------------------

def _regulatory_table_html(req_list: list[dict], title: str, pct: float) -> str:
    if not req_list:
        return ""

    pct_color = "#1a7f37" if pct >= 70 else "#9a6700" if pct >= 40 else "#cf222e"
    rows = ""
    for req in req_list:
        req_id = html.escape(str(req.get("id", req.get("requirement_id", ""))))
        topic = html.escape(str(req.get("topic") or req.get("pillar") or req.get("article") or ""))
        status = str(req.get("status", "not_disclosed"))
        evidence = str(req.get("evidence", "") or "")
        ev_short = html.escape(evidence[:120] + ("…" if len(evidence) > 120 else ""))
        badge = _rag_badge_html(status)
        rows += (
            f"<tr>"
            f'<td style="padding:7px 10px;border-bottom:1px solid #eaecef;font-family:monospace;'
            f'font-size:11px;color:#0969da;white-space:nowrap;font-weight:600;">{req_id}</td>'
            f'<td style="padding:7px 10px;border-bottom:1px solid #eaecef;font-size:12px;color:#24292f;">{topic}</td>'
            f'<td style="padding:7px 10px;border-bottom:1px solid #eaecef;white-space:nowrap;">{badge}</td>'
            f'<td style="padding:7px 10px;border-bottom:1px solid #eaecef;font-size:11px;color:#57606a;'
            f'font-style:italic;">{ev_short}</td>'
            "</tr>"
        )

    return (
        f'<div style="margin-bottom:24px;">'
        f'<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">'
        f'<h4 style="color:#1f2328;font-size:12px;font-weight:700;text-transform:uppercase;'
        f'letter-spacing:0.8px;margin:0;">{html.escape(title)}</h4>'
        f'<span style="font-size:18px;font-weight:800;color:{pct_color};">{pct:.0f}%</span>'
        f'</div>'
        f'<div style="background:#eaecef;border-radius:4px;height:6px;margin-bottom:12px;">'
        f'<div style="background:{pct_color};height:100%;width:{pct:.1f}%;border-radius:4px;"></div></div>'
        f'<div style="overflow-x:auto;border:1px solid #d0d7de;border-radius:6px;">'
        f'<table style="width:100%;border-collapse:collapse;">'
        f"<thead><tr style='background:#f6f8fa;'>"
        f'<th style="text-align:left;padding:7px 10px;border-bottom:1px solid #d0d7de;'
        f'font-size:11px;color:#57606a;font-weight:600;">ID</th>'
        f'<th style="text-align:left;padding:7px 10px;border-bottom:1px solid #d0d7de;'
        f'font-size:11px;color:#57606a;font-weight:600;">Topic / Pillar</th>'
        f'<th style="text-align:left;padding:7px 10px;border-bottom:1px solid #d0d7de;'
        f'font-size:11px;color:#57606a;font-weight:600;">Status</th>'
        f'<th style="text-align:left;padding:7px 10px;border-bottom:1px solid #d0d7de;'
        f'font-size:11px;color:#57606a;font-weight:600;">Evidence</th>'
        f"</tr></thead>"
        f"<tbody>{rows}</tbody>"
        f"</table></div></div>"
    )


# ---------------------------------------------------------------------------
# Greenwashing flags
# ---------------------------------------------------------------------------

def _greenwashing_html(flags: list, penalty: float) -> str:
    if not flags:
        return ""
    items = "".join(
        f'<div style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;'
        f'border-bottom:1px solid #ffebe9;">'
        f'<span style="color:#cf222e;font-size:14px;flex-shrink:0;">⚠</span>'
        f'<span style="font-size:12px;color:#24292f;">{html.escape(str(f))}</span>'
        f'</div>'
        for f in flags
    )
    return (
        f'<div style="background:#fff8f8;border:1px solid #ffcbca;border-radius:6px;'
        f'padding:12px 14px;margin-top:12px;">'
        f'<div style="font-size:12px;font-weight:700;color:#cf222e;margin-bottom:8px;">'
        f'⚠ Greenwashing Risk Flags — Penalty: −{penalty:.0f} pts</div>'
        f'{items}</div>'
    )


# ---------------------------------------------------------------------------
# Executive summary bullets (data-driven, no LLM)
# ---------------------------------------------------------------------------

def _derive_exec_bullets(
    segments: list[dict], esg: dict, fitch_factors: list[dict], fwd: Optional[dict]
) -> list[str]:
    bullets = []

    if segments:
        total = sum(float(s.get("revenue", 0) or 0) for s in segments)
        largest = max(segments, key=lambda s: float(s.get("revenue", 0) or 0), default=None)
        lname = largest.get("name", "largest segment") if largest else "largest segment"
        lval = float(largest.get("revenue", 0) or 0) if largest else 0
        if total > 0:
            pct = lval / total * 100
            bullets.append(
                f"{len(segments)} revenue segments totalling {total:,.1f} — "
                f"{lname} is the largest contributor ({pct:.0f}% of total)."
            )
        else:
            bullets.append(f"{len(segments)} segments extracted — revenue values not available in data.")
    else:
        bullets.append("Segment breakdown not available — upload PDF to extract revenue data.")

    if esg:
        composite = float(esg.get("composite", 0) or 0)
        rating = esg.get("rating", "")
        e, s, g = float(esg.get("e_score", 0) or 0), float(esg.get("s_score", 0) or 0), float(esg.get("g_score", 0) or 0)
        strongest = max([("Environmental", e), ("Social", s), ("Governance", g)], key=lambda x: x[1])
        weakest = min([("Environmental", e), ("Social", s), ("Governance", g)], key=lambda x: x[1])
        rating_str = f" ({rating})" if rating else ""
        bullets.append(
            f"ESG composite score {composite:.0f}/100{rating_str} — "
            f"{strongest[0]} is the strongest pillar ({strongest[1]:.0f}/100); "
            f"{weakest[0]} has most room for improvement ({weakest[1]:.0f}/100)."
        )
    elif fitch_factors:
        avg = sum(float(f.get("score", 3) or 3) for f in fitch_factors) / len(fitch_factors)
        disclosed = sum(1 for f in fitch_factors if f.get("disclosed", True))
        bullets.append(
            f"Fitch ESG: {len(fitch_factors)} factors assessed, {disclosed} disclosed — "
            f"average score {avg:.1f}/5."
        )

    if fitch_factors:
        g_facs = [f for f in fitch_factors if f.get("category", "").upper().startswith("G")]
        if g_facs:
            avg_g = sum(float(f.get("score", 3) or 3) for f in g_facs) / len(g_facs)
            sentiment = "strong" if avg_g >= 4 else "moderate" if avg_g >= 3 else "weak"
            bullets.append(
                f"Governance: {sentiment} disclosure ({avg_g:.1f}/5 avg across {len(g_facs)} factors) — "
                + ("board structure and remuneration linkage to ESG are key differentiators." if avg_g >= 4
                   else "gaps remain in compensation ESG-linkage and anti-corruption reporting.")
            )

    if fwd:
        nz = fwd.get("net_zero_year") or fwd.get("net_zero_target")
        scope = fwd.get("net_zero_scope") or "Scope 1+2"
        targets = fwd.get("targets") or fwd.get("interim_targets") or []
        risks = fwd.get("risks") or fwd.get("key_risks") or []
        if nz:
            bullets.append(
                f"Net-zero commitment by {nz} covering {scope}"
                + (f"; {len(targets) if isinstance(targets, list) else 1} interim target(s) disclosed." if targets else ".")
            )
        else:
            bullets.append("No explicit net-zero commitment identified in the document.")
        if risks:
            n = len(risks) if isinstance(risks, list) else 1
            bullets.append(f"{n} material risk factor(s) identified including climate transition and market exposure.")

    return bullets[:5]


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def generate_html_report(
    doc_name: str,
    segments: Optional[list[dict]] = None,
    esg: Optional[dict] = None,
    fitch_factors: Optional[list[dict]] = None,
    forward_looking: Optional[dict] = None,
    regulatory_data: Optional[dict] = None,
    peers: Optional[list[dict]] = None,
    news_items: Optional[list[dict]] = None,
    currency: str = "EUR",
    unit: str = "millions",
    reporting_period: str = "",
    context_brief: str = "",
    online_disclaimer: str = "",
) -> str:
    """Generate a complete self-contained HTML research note."""

    # Normalise all data to report-expected format
    segments = _norm_segments(segments or [])
    fitch_factors = _norm_fitch(fitch_factors or [])
    esg_norm = _norm_esg(esg or {})
    peers = peers or []
    news_items = news_items or []
    fwd = forward_looking or {}

    today_str = date.today().strftime("%d %b %Y")
    period_str = html.escape(reporting_period or "—")
    company = html.escape(doc_name or "Unknown Company")

    rating = esg_norm.get("rating", "")
    rating_bg, rating_fg = _rating_colors(rating)

    exec_bullets = _derive_exec_bullets(segments, esg_norm, fitch_factors, fwd)

    # --- Segment section ---
    seg_chart = _segment_svg_chart(segments, currency, unit)

    # Segment table
    seg_table_rows = ""
    for s in segments:
        seg_table_rows += (
            f'<tr>'
            f'<td style="padding:7px 12px;border-bottom:1px solid #eaecef;font-size:13px;'
            f'color:#24292f;font-weight:500;">{html.escape(str(s.get("name","")))} </td>'
            f'<td style="padding:7px 12px;border-bottom:1px solid #eaecef;font-size:13px;'
            f'color:#24292f;text-align:right;font-family:monospace;">{float(s.get("revenue",0) or 0):,.1f}</td>'
            f'</tr>'
        )
    seg_table = (
        f'<table style="width:280px;border-collapse:collapse;border:1px solid #d0d7de;border-radius:6px;overflow:hidden;">'
        f'<thead><tr style="background:#f6f8fa;">'
        f'<th style="padding:7px 12px;text-align:left;font-size:11px;color:#57606a;border-bottom:1px solid #d0d7de;">Segment</th>'
        f'<th style="padding:7px 12px;text-align:right;font-size:11px;color:#57606a;border-bottom:1px solid #d0d7de;">{html.escape(currency)} ({html.escape(unit)})</th>'
        f'</tr></thead><tbody>{seg_table_rows}</tbody></table>'
    ) if segments else ""

    # --- ESG section ---
    esg_section = ""
    if esg_norm.get("composite"):
        comp = float(esg_norm["composite"])
        comp_color = "#1a7f37" if comp >= 70 else "#9a6700" if comp >= 50 else "#cf222e"
        esg_section = (
            f'<div style="display:flex;gap:32px;flex-wrap:wrap;align-items:flex-start;">'
            f'<div style="text-align:center;min-width:120px;">'
            f'<div style="font-size:48px;font-weight:800;color:{comp_color};line-height:1;">'
            f'{comp:.0f}</div>'
            f'<div style="font-size:11px;color:#57606a;margin-top:2px;">/ 100 composite</div>'
            + (f'<div style="margin-top:8px;background:{rating_bg};color:{rating_fg};'
               f'padding:4px 14px;border-radius:4px;font-size:16px;font-weight:800;'
               f'display:inline-block;border:1px solid {rating_fg}40;">'
               f'{html.escape(rating)}</div>' if rating else "")
            + f'</div>'
            f'<div style="flex:1;min-width:200px;">'
            + _esg_bar("Environmental (E)", esg_norm.get("e_score", 0), "#1a7f37")
            + _esg_bar("Social (S)", esg_norm.get("s_score", 0), "#0969da")
            + _esg_bar("Governance (G)", esg_norm.get("g_score", 0), "#9a6700")
            + f'</div></div>'
            + _greenwashing_html(esg_norm.get("greenwashing_flags", []), float(esg_norm.get("greenwashing_penalty", 0)))
        )
    elif fitch_factors:
        avg = sum(float(f.get("score", 3) or 3) for f in fitch_factors) / len(fitch_factors)
        avg_color = _score_color(round(avg))
        esg_section = (
            f'<div style="text-align:center;padding:16px;">'
            f'<div style="font-size:40px;font-weight:800;color:{avg_color};">{avg:.1f}</div>'
            f'<div style="color:#57606a;font-size:12px;">avg Fitch factor score / 5</div></div>'
        )
    else:
        esg_section = '<p style="color:#57606a;font-style:italic;">No ESG data — run analysis first.</p>'

    # --- Fitch heatmap ---
    heatmap_html = _fitch_heatmap_html(fitch_factors)

    # --- Regulatory ---
    reg_html = ""
    overall_pct = None
    if regulatory_data:
        csrd_reqs = regulatory_data.get("csrd", {}).get("requirements", [])
        tcfd_reqs = regulatory_data.get("tcfd", {}).get("requirements", [])
        eu_reqs = regulatory_data.get("eu_taxonomy", {}).get("requirements", [])
        csrd_pct = regulatory_data.get("csrd", {}).get("overall_pct", 0)
        tcfd_pct = regulatory_data.get("tcfd", {}).get("overall_pct", 0)
        eu_pct = regulatory_data.get("eu_taxonomy", {}).get("overall_pct", 0)
        overall_pct = regulatory_data.get("overall_compliance_score")
        if csrd_reqs:
            reg_html += _regulatory_table_html(csrd_reqs, f"CSRD / ESRS Requirements", csrd_pct)
        if tcfd_reqs:
            reg_html += _regulatory_table_html(tcfd_reqs, f"TCFD Recommendations", tcfd_pct)
        if eu_reqs:
            reg_html += _regulatory_table_html(eu_reqs, f"EU Taxonomy Article 8", eu_pct)

    if not reg_html:
        reg_html = '<p style="color:#57606a;font-style:italic;">Run regulatory check to populate this section.</p>'

    overall_pct_html = ""
    if overall_pct is not None:
        oc = float(overall_pct)
        oc_color = "#1a7f37" if oc >= 70 else "#9a6700" if oc >= 40 else "#cf222e"
        overall_pct_html = (
            f'<div style="display:inline-flex;align-items:center;gap:12px;'
            f'background:#f6f8fa;border:1px solid {oc_color}50;border-radius:8px;'
            f'padding:10px 18px;margin-bottom:20px;">'
            f'<div style="font-size:28px;font-weight:800;color:{oc_color};">{oc:.0f}%</div>'
            f'<div style="font-size:12px;color:#57606a;">Overall regulatory<br>compliance score</div>'
            f'</div>'
        )

    # --- Forward-looking ---
    fwd_html = ""
    if fwd:
        nz = fwd.get("net_zero_year") or fwd.get("net_zero_target")
        scope = fwd.get("net_zero_scope") or "Scope 1+2"
        if nz:
            fwd_html += (
                f'<div style="display:inline-flex;align-items:center;gap:12px;'
                f'background:#dafbe1;border:1px solid #1a7f37;border-radius:8px;'
                f'padding:10px 18px;margin-bottom:16px;">'
                f'<span style="font-size:24px;">🌿</span>'
                f'<div><div style="color:#116329;font-weight:700;font-size:14px;">'
                f'Net-zero by {html.escape(str(nz))}</div>'
                f'<div style="color:#1a7f37;font-size:12px;">Covering {html.escape(str(scope))}</div>'
                f'</div></div>'
            )

        targets = fwd.get("targets") or fwd.get("interim_targets") or []
        if targets:
            tlist = targets if isinstance(targets, list) else [targets]
            t_items = "".join(
                f'<li style="font-size:13px;color:#24292f;padding:3px 0;line-height:1.4;">'
                f'{html.escape(str(t))}</li>' for t in tlist
            )
            fwd_html += (
                f'<h4 style="color:#0969da;font-size:12px;font-weight:700;'
                f'text-transform:uppercase;letter-spacing:0.5px;margin:12px 0 6px;">Climate Targets</h4>'
                f'<ul style="margin:0;padding-left:16px;">{t_items}</ul>'
            )

        risks = fwd.get("risks") or fwd.get("key_risks") or []
        if risks:
            rlist = risks if isinstance(risks, list) else [risks]
            r_items = "".join(
                f'<div style="display:flex;gap:8px;padding:5px 0;border-bottom:1px solid #ffebe9;">'
                f'<span style="color:#cf222e;flex-shrink:0;">⚠</span>'
                f'<span style="font-size:12px;color:#24292f;">{html.escape(str(r))}</span></div>'
                for r in rlist
            )
            fwd_html += (
                f'<h4 style="color:#cf222e;font-size:12px;font-weight:700;'
                f'text-transform:uppercase;letter-spacing:0.5px;margin:14px 0 6px;">Key Risks</h4>'
                + r_items
            )

        frameworks = fwd.get("frameworks") or fwd.get("mentioned_frameworks") or []
        if frameworks:
            flist = frameworks if isinstance(frameworks, list) else [frameworks]
            pills = "".join(
                f'<span style="background:#ddf4ff;color:#0969da;padding:3px 10px;'
                f'border-radius:12px;font-size:11px;font-weight:600;margin:3px;'
                f'display:inline-block;border:1px solid #54aeff40;">'
                f'{html.escape(str(fw))}</span>' for fw in flist
            )
            fwd_html += (
                f'<h4 style="color:#57606a;font-size:12px;font-weight:700;'
                f'text-transform:uppercase;letter-spacing:0.5px;margin:14px 0 6px;">'
                f'Frameworks Referenced</h4>'
                f'<div style="margin-top:4px;">{pills}</div>'
            )

    if not fwd_html:
        fwd_html = '<p style="color:#57606a;font-style:italic;">Forward-looking data not extracted for this document.</p>'

    # --- News ---
    news_html = ""
    if news_items:
        cards = []
        for item in news_items[:8]:
            title_raw = str(item.get("title") or item.get("headline") or "")
            source = html.escape(str(item.get("source", "")))
            date_s = html.escape(str(item.get("date", ""))[:10])
            url = html.escape(str(item.get("url") or item.get("href") or "#"))
            body = html.escape(str(item.get("body", ""))[:180])
            title_esc = html.escape(title_raw)
            cards.append(
                f'<div style="flex:1 1 calc(50% - 8px);min-width:220px;background:#f6f8fa;'
                f'border:1px solid #d0d7de;border-radius:8px;padding:14px;">'
                f'<div style="font-size:10px;color:#57606a;margin-bottom:6px;">'
                f'{source}{"  ·  " + date_s if date_s else ""}</div>'
                f'<a href="{url}" target="_blank" style="text-decoration:none;">'
                f'<div style="color:#0969da;font-size:13px;font-weight:600;line-height:1.4;'
                f'margin-bottom:6px;">{title_esc}</div></a>'
                + (f'<div style="color:#57606a;font-size:11px;line-height:1.5;">{body}{"…" if body else ""}</div>' if body else "")
                + '</div>'
            )
        news_html = '<div style="display:flex;flex-wrap:wrap;gap:12px;">' + "".join(cards) + "</div>"
    else:
        news_html = '<p style="color:#57606a;font-style:italic;">No recent news items available.</p>'

    # --- Peers ---
    if peers:
        peer_rows = "".join(
            f'<tr>'
            f'<td style="padding:8px 12px;border-bottom:1px solid #eaecef;font-size:13px;'
            f'font-weight:600;color:#24292f;">{html.escape(str(p.get("name","—")))}</td>'
            f'<td style="padding:8px 12px;border-bottom:1px solid #eaecef;font-size:12px;'
            f'color:#57606a;">{html.escape(str(p.get("region","—")))}</td>'
            f'<td style="padding:8px 12px;border-bottom:1px solid #eaecef;font-size:12px;'
            f'color:#57606a;">{html.escape(str(p.get("reason","")))}</td>'
            f'</tr>' for p in peers
        )
        peers_html = (
            f'<table style="width:100%;border-collapse:collapse;border:1px solid #d0d7de;border-radius:6px;overflow:hidden;">'
            f'<thead><tr style="background:#f6f8fa;">'
            f'<th style="text-align:left;padding:7px 12px;border-bottom:1px solid #d0d7de;font-size:11px;color:#57606a;">Company</th>'
            f'<th style="text-align:left;padding:7px 12px;border-bottom:1px solid #d0d7de;font-size:11px;color:#57606a;">Region</th>'
            f'<th style="text-align:left;padding:7px 12px;border-bottom:1px solid #d0d7de;font-size:11px;color:#57606a;">Rationale</th>'
            f'</tr></thead><tbody>{peer_rows}</tbody></table>'
        )
    else:
        peers_html = '<p style="color:#57606a;font-style:italic;">No peer companies identified.</p>'

    # --- Analyst brief ---
    brief_html = ""
    if context_brief:
        brief_html = (
            f'<div style="background:#f6f8fa;border:1px solid #d0d7de;border-radius:8px;'
            f'padding:16px 20px;margin-bottom:20px;">'
            f'<div style="font-size:11px;font-weight:700;color:#57606a;text-transform:uppercase;'
            f'letter-spacing:0.8px;margin-bottom:10px;">AI Analyst Brief</div>'
            + _md_to_html(context_brief)
            + '</div>'
        )

    # --- Exec bullets HTML ---
    bullets_html = "".join(
        f'<div style="display:flex;gap:10px;padding:7px 0;border-bottom:1px solid #eaecef;">'
        f'<span style="color:#0969da;font-size:16px;flex-shrink:0;margin-top:-1px;">›</span>'
        f'<span style="font-size:13px;color:#24292f;line-height:1.5;">{html.escape(b)}</span>'
        f'</div>'
        for b in exec_bullets
    )

    # --- Online disclaimer banner ---
    disclaimer_html = ""
    if online_disclaimer:
        disclaimer_html = (
            f'<div style="background:#fff8c5;border:1px solid #d4a017;border-radius:6px;'
            f'padding:10px 14px;margin-bottom:18px;font-size:11px;color:#3d2b00;line-height:1.5;">'
            f'<strong style="color:#9a6700;">Data Source Disclosure &nbsp;&mdash;&nbsp;</strong>'
            + _md_inline(html.unescape(online_disclaimer))
            + f'</div>'
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>FinExtract AI — {company}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{
    background:#ffffff;
    color:#24292f;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
    font-size:14px;line-height:1.5;
  }}
  .header{{
    background:linear-gradient(135deg,#1f2328 0%,#2d333b 100%);
    padding:28px 48px;
    display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;
    border-bottom:3px solid #0969da;
  }}
  .company{{font-size:30px;font-weight:800;color:#ffffff;letter-spacing:-0.5px;}}
  .meta{{font-size:11px;color:#8b949e;font-family:monospace;margin-top:5px;}}
  .brand{{font-size:11px;color:#8b949e;text-align:right;font-family:monospace;}}
  .brand strong{{color:#58a6ff;font-size:13px;}}
  .container{{max-width:1140px;margin:0 auto;padding:32px 40px;}}
  .section{{
    background:#ffffff;border:1px solid #d0d7de;border-radius:10px;
    padding:24px 28px;margin-bottom:22px;
    box-shadow:0 1px 3px rgba(0,0,0,0.06);
  }}
  .section-title{{
    font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;
    color:#57606a;border-bottom:1px solid #eaecef;padding-bottom:10px;margin-bottom:18px;
    display:flex;align-items:center;gap:8px;
  }}
  .section-title::before{{
    content:"";display:inline-block;width:3px;height:14px;
    background:#0969da;border-radius:2px;
  }}
  .two-col{{display:grid;grid-template-columns:1fr 1fr;gap:20px;}}
  .footer{{
    background:#f6f8fa;border-top:1px solid #d0d7de;
    padding:16px 40px;text-align:center;
    font-size:11px;color:#57606a;font-family:monospace;margin-top:32px;
  }}
  @media print{{
    .section{{box-shadow:none;border:1px solid #d0d7de;}}
    .header{{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
    a{{color:#0969da;text-decoration:none;}}
  }}
  @media(max-width:768px){{
    .two-col{{grid-template-columns:1fr;}}
    .header,.container{{padding:16px 20px;}}
    .company{{font-size:22px;}}
  }}
</style>
</head>
<body>

<div class="header">
  <div>
    <div class="company">{company}</div>
    <div class="meta">Period: {period_str} &nbsp;|&nbsp; Generated: {today_str} &nbsp;|&nbsp; Currency: {html.escape(currency)} ({html.escape(unit)}) &nbsp;|&nbsp; FinExtract AI Research Note</div>
  </div>
  <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
    {(f'<span style="background:{rating_bg};color:{rating_fg};padding:6px 16px;border-radius:6px;font-size:18px;font-weight:800;border:1px solid {rating_fg}40;">{html.escape(rating)}</span>') if rating else ""}
    <div class="brand"><strong>FinExtract AI</strong><br/>Fitch-Grade Financial Analysis</div>
  </div>
</div>

<div class="container">

  <!-- Executive Summary -->
  <div class="section">
    <div class="section-title">Executive Summary</div>
    {disclaimer_html}
    {brief_html}
    <div style="background:#f6f8fa;border-radius:6px;padding:12px 16px;">
      {bullets_html}
    </div>
  </div>

  <!-- Revenue Segments + ESG Overview -->
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:22px;">
    <div class="section" style="margin-bottom:0;">
      <div class="section-title">Revenue Segments</div>
      <div style="overflow-x:auto;">{seg_chart}</div>
      {('<div style="margin-top:16px;">' + seg_table + '</div>') if seg_table else ''}
    </div>
    <div class="section" style="margin-bottom:0;">
      <div class="section-title">ESG Overview</div>
      {esg_section}
    </div>
  </div>

  <!-- Fitch ESG Factors -->
  <div class="section">
    <div class="section-title">Fitch ESG Factors</div>
    {heatmap_html}
  </div>

  <!-- Regulatory Gap Analysis -->
  <div class="section">
    <div class="section-title">Regulatory Gap Analysis</div>
    {overall_pct_html}
    {reg_html}
  </div>

  <!-- Forward-Looking -->
  <div class="section">
    <div class="section-title">Forward-Looking &amp; Climate Commitments</div>
    {fwd_html}
  </div>

  <!-- News + Peers -->
  <div class="two-col">
    <div class="section" style="margin-bottom:0;">
      <div class="section-title">Recent News</div>
      {news_html}
    </div>
    <div class="section" style="margin-bottom:0;">
      <div class="section-title">Comparable Companies</div>
      {peers_html}
    </div>
  </div>

</div>

<div class="footer">
  <strong style="color:#0969da;">FinExtract AI</strong> — Financial PDF Analysis Tool &nbsp;|&nbsp;
  Generated {today_str} &nbsp;|&nbsp;
  AI-generated report for informational purposes only. Not financial advice.
</div>

</body>
</html>"""
