# Financial PDF Extraction System — Architecture

**Project:** Fitch-grade segment revenue extraction with ESG scoring  
**Deadline:** May 7, 2026  
**Target accuracy:** ≥90% recall on ground truth rows

---

## Problem Statement

Given 100+ annual reports from companies worldwide (US, Europe, Asia, South America, Middle East), extract:
- **Business operating segment** revenue/income values
- **Reporting period**, currency, and unit
- **ESG scores** (Environmental, Social, Governance)
- **Greenwashing detection** for companies misrepresenting climate impact
- **NACE Rev 2.1** industry classification tags

All cheaper than Azure Document Intelligence / proprietary data providers.

---

## System Architecture

```
PDF Files
    │
    ▼
┌─────────────────────────────────────────────────┐
│  Agent 1: Page Finder (table_extractor.py)       │
│  • Keyword scoring: segment/revenue hits         │
│  • Penalise geographic keyword matches           │
│  • Returns top-3 candidate pages per PDF         │
└────────────────────┬────────────────────────────┘
                     │ candidate pages
                     ▼
┌─────────────────────────────────────────────────┐
│  Agent 2: Table Extractor (table_extractor.py)   │
│  • pdfplumber: structured table extraction       │
│  • PyMuPDF: raw page text extraction             │
│  • Combines table + text into page context       │
└────────────────────┬────────────────────────────┘
                     │ page context (text + tables)
                     ▼
┌─────────────────────────────────────────────────┐
│  Agent 3: LLM Extractor (llm_extractor.py)       │
│  • Claude Haiku (primary — cheap, fast)          │
│  • Claude Sonnet (fallback if confidence < 60%) │
│  • Prompt caching: system prompt billed once     │
│  • Few-shot examples from ground truth           │
│  • Returns structured JSON: segments + metadata  │
│  • Math validation: segment sum ≈ total          │
│  • Rule-based fallback if no API key             │
└────────────────────┬────────────────────────────┘
                     │ extracted segments
                     ▼
┌─────────────────────────────────────────────────┐
│  Agent 4: NACE Tagger (nace_tagger.py)           │
│  • 30+ keyword rules → NACE Rev 2.1 sections     │
│  • Company-level context from first page         │
│  • Confidence score per tag                      │
└────────────────────┬────────────────────────────┘
                     │ tagged segments
                     ▼
┌─────────────────────────────────────────────────┐
│  Agent 5: ESG Scorer (esg_scorer.py)             │
│  • Pattern-match full PDF text                   │
│  • E: Scope 1/2/3, renewables, intensity, targets│
│  • S: Safety, diversity, employee metrics        │
│  • G: Audit, board composition, TCFD/CSRD/ESRS  │
│  • Greenwashing penalty (up to -40 pts):         │
│    – Missing Scope 3                             │
│    – Vague aspirational language                 │
│    – No third-party assurance                    │
│    – Round suspicious emission numbers           │
│    – Net-zero without any quantified data        │
└────────────────────┬────────────────────────────┘
                     │ ESG scores + flags
                     ▼
┌─────────────────────────────────────────────────┐
│  Agent 6: Validator (validator.py)               │
│  • Fuzzy segment name match (rapidfuzz)          │
│  • Value match: ±1% tolerance                    │
│  • Currency + unit exact match                   │
│  • Precision / Recall / F1 per document          │
│  • Overall accuracy vs ground truth              │
└────────────────────┬────────────────────────────┘
                     │ accuracy metrics
                     ▼
┌─────────────────────────────────────────────────┐
│  Human-in-the-loop UI (app.py — Streamlit)       │
│  • Browse extracted data alongside source page   │
│  • Edit, approve, or reject rows                 │
│  • ESG radar charts + greenwashing dashboard     │
│  • NACE distribution charts                      │
│  • One-click pipeline trigger                    │
│  • Export corrected data for retraining          │
└─────────────────────────────────────────────────┘
```

---

## File Index

| File | Role | Agent |
|------|------|-------|
| `config.py` | Central config, paths, model selection | — |
| `table_extractor.py` | PDF parsing, page scoring | 1 + 2 |
| `llm_extractor.py` | LLM-based segment extraction | 3 |
| `nace_tagger.py` | NACE Rev 2.1 classification | 4 |
| `esg_scorer.py` | ESG scoring + greenwashing | 5 |
| `validator.py` | Ground truth accuracy measurement | 6 |
| `pipeline.py` | Orchestrates all agents | — |
| `app.py` | Streamlit human review UI | — |
| `requirements.txt` | Python dependencies | — |

---

## Cost Analysis (vs Azure Document Intelligence)

| Tool | Price per page | 100 PDFs (~150pp avg) |
|------|---------------|------------------------|
| Azure Document Intelligence | $0.001–0.01 | $150–$1,500 |
| **Our system (Claude Haiku)** | **~$0.0001** | **~$1.50** |
| Our system (Claude Sonnet) | ~$0.001 | ~$15 |
| Rule-based fallback (no LLM) | $0 | $0 |

**Savings: ~99% vs Azure Document Intelligence**

Key cost-reduction strategies:
- **Prompt caching**: system prompt + few-shot examples cached (90% cost reduction on repeated calls)
- **Page pre-filtering**: only 3 pages per PDF sent to LLM (not all 150+)
- **Haiku-first**: use cheapest model, escalate to Sonnet only on uncertainty
- **Rule-based fallback**: zero cost for documents with clean table structure

---

## Accuracy Strategy

**Target: ≥90% recall on ground truth rows**

| Challenge | Solution |
|-----------|----------|
| Finding the right page | Keyword scoring (include/exclude lists) |
| Table structure diversity | pdfplumber + LLM context combination |
| Geographic vs business segments | Explicit rule in system prompt |
| Negative values (eliminations) | Preserved in LLM prompt rule |
| Multi-language PDFs | LLM handles natively |
| Unit/currency ambiguity | Extracted from table header context |
| Hallucination prevention | Math cross-check (sum of segments = total) |
| Manual verification | Streamlit UI with source page image |

---

## Greenwashing Detection Logic

Scores are reduced (up to -40 points) when:

1. **Missing Scope 3** — company reports Scope 1+2 but omits value chain emissions (-10 pts)
2. **No third-party assurance** — net-zero claims without Deloitte/PwC/Bureau Veritas verification (-8 pts)
3. **High vague language** — phrases like "committed to sustainability", "green future" without metrics (-2 pts/phrase, max -12)
4. **Round emission numbers** — suspiciously exact figures like "100,000 tCO2" suggest estimation not measurement (-5 pts)
5. **Zero quantified data** — sustainability claims with no emissions figures at all (-15 pts)

---

## NACE Classification

Uses NACE Rev 2.1 (EU standard, globally accepted for ESG reporting under CSRD/ESRS).

- 30+ keyword rules map segment names → NACE section + division
- Company-level context (first page text) refines segment-level classification
- Confidence score per tag (0.0–1.0)
- Falls back to section S (Other services) for unclassifiable segments

---

## How to Run

### Install dependencies
```bash
pip install -r requirements.txt
```

### Set API key
```bash
# Windows
set ANTHROPIC_API_KEY=sk-ant-...

# Or create .env file
echo ANTHROPIC_API_KEY=sk-ant-... > .env
```

### Run pipeline (ground truth PDFs only — fast)
```bash
python pipeline.py
```

### Run pipeline (all PDFs)
```bash
python pipeline.py --max 10        # first 10 PDFs
python pipeline.py                 # all PDFs
```

### Launch human review UI
```bash
streamlit run app.py
```

---

## Ground Truth Schema

The `sample_ground_truth.xlsx` defines what we're trying to extract:

| Column | Description |
|--------|-------------|
| `doc` | PDF filename |
| `pdf_page_no` | Page where the segment table appears |
| `segment` | Business segment name |
| `value_label` | Type of financial metric (Revenue, Total income, etc.) |
| `value` | Numeric value |
| `reporting_period` | Fiscal year-end date |
| `currency` | ISO currency code |
| `unit` | millions / thousands / billions |

**Validated documents (30 rows):**
- `82_Orsted Annual Report 2025.pdf` — 6 rows (DKK, renewable energy)
- `726_Alliander_Annual_Report_2024 (4).pdf` — 6 rows (EUR, utilities)
- `728_2025 Annual report.pdf` — 5 rows (USD, Alphabet/Google)
- `766_2024 annual report.pdf` — 8 rows (USD, Citigroup)
- `11140_2025 Consolidated Financial Statements (Dec 2025).pdf` — 5 rows (SAR, Saudi bank)

---

## Anti-Hallucination Checks

| Check | Implementation |
|-------|----------------|
| Math consistency | Segment sum validated against total row (±15%) |
| Source citation | Each extracted row records source page number |
| Confidence score | LLM reports 0.0–1.0 confidence; low → Sonnet retry |
| Human review | Analyst can see source page image alongside extracted data |
| Approved export | Only analyst-approved rows go into final dataset |

---

## Extensibility

- **New geographies**: system prompt is language-agnostic; Claude handles DE/FR/TR/AR natively
- **New document types**: add keywords to `SEGMENT_INCLUDE` in `table_extractor.py`
- **Fine-tuning**: approved analyst corrections can be collected and used to fine-tune a smaller open-source model (Mistral-7B via LoRA) — reduces LLM cost further
- **Retraining loop**: `outputs/approved_*.csv` files accumulate labeled training data each review cycle

---

## 2-Week Delivery Plan

| Week | Milestone |
|------|-----------|
| Week 1 (now) | ✅ Pipeline built, all 5 agents implemented |
| Apr 21–25 | Set API key, run on 5 GT PDFs, tune prompts to hit 90% |
| Apr 25–28 | Run on all 100+ PDFs, ESG scores, NACE tags |
| Apr 28–May 2 | Streamlit UI review with analyst, collect corrections |
| May 2–6 | Final tuning, documentation, slide deck |
| **May 7** | **Final presentation** |
