"""
forward_looking.py — Forward-Looking Intelligence Extractor
Extracts climate commitments, financial guidance, strategic priorities,
and key risks from annual report text using OpenAI gpt-4o.

The extractor focuses on two text windows:
  • First 30,000 characters — covers the CEO letter and strategy section.
  • Last 15,000 characters  — covers appendices, frameworks, and assurance statements.

All list-type fields are JSON-serialised when written to CSV and deserialised
on load, so the in-memory representation always uses Python lists/dicts.
"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Optional

import pandas as pd

from config import ANTHROPIC_API_KEY, COMPLEX_MODEL, OUTPUT_DIR

# ── Extraction schema ──────────────────────────────────────────────────────────

EXTRACTION_SCHEMA: dict = {
    "net_zero_year": {
        "type": "int or null",
        "description": "The year the company explicitly commits to reaching net-zero emissions.",
        "example": 2050,
    },
    "net_zero_scope": {
        "type": "str",
        "description": (
            "Scope coverage of the net-zero commitment, e.g. 'Scope 1 and 2', 'all scopes', "
            "'Scope 1, 2 and 3'. Empty string if not disclosed."
        ),
        "example": "Scope 1, 2 and 3",
    },
    "interim_targets": {
        "type": "list of objects",
        "description": (
            "Specific interim emissions or sustainability reduction targets with a named year, "
            "metric, quantified target value, and baseline year/value."
        ),
        "item_schema": {
            "year": "int — the target year",
            "metric": "str — what is being reduced/improved (e.g. 'GHG emissions', 'renewable energy %')",
            "target_value": "str — the quantified target (e.g. '30% reduction', '100% renewable')",
            "baseline": "str — baseline year or value (e.g. '2019 baseline', '2020: 500 ktCO2e')",
        },
        "example": [{"year": 2030, "metric": "GHG emissions", "target_value": "30% reduction", "baseline": "2019"}],
    },
    "renewable_energy_target": {
        "type": "object or null",
        "description": "A specific target for renewable energy as a percentage of total energy by a stated year.",
        "item_schema": {
            "pct": "float — target percentage (e.g. 100.0)",
            "year": "int — target year",
        },
        "example": {"pct": 100.0, "year": 2030},
    },
    "capex_guidance": {
        "type": "object or null",
        "description": "Forward-looking capital expenditure guidance or planned investment.",
        "item_schema": {
            "value": "float — numeric amount",
            "currency": "str — 3-letter ISO currency code (e.g. 'EUR', 'USD')",
            "unit": "str — 'millions' or 'billions'",
            "year": "int — the year the capex relates to",
            "description": "str — brief description of what the capex covers",
        },
        "example": {"value": 2.5, "currency": "EUR", "unit": "billions", "year": 2025, "description": "Grid investment"},
    },
    "revenue_guidance": {
        "type": "object or null",
        "description": (
            "Forward-looking revenue or sales growth guidance, expressed as a percentage range "
            "and the year it applies to."
        ),
        "item_schema": {
            "description": "str — verbatim or paraphrased guidance statement",
            "low_pct": "float — lower end of growth range (e.g. 3.0 for 3%)",
            "high_pct": "float — upper end of growth range (e.g. 5.0 for 5%)",
            "year": "int — the year the guidance applies to",
        },
        "example": {"description": "Revenue growth of 3–5%", "low_pct": 3.0, "high_pct": 5.0, "year": 2025},
    },
    "key_risks": {
        "type": "list of str",
        "description": (
            "Up to 5 key risks, preferably taken verbatim or near-verbatim from the risk section "
            "of the report. Focus on material and novel risks rather than boilerplate."
        ),
        "example": ["Rising interest rates", "Regulatory changes in the EU", "Cybersecurity threats"],
    },
    "strategic_initiatives": {
        "type": "list of str",
        "description": (
            "Up to 5 strategic priorities or initiatives described in the CEO letter or strategy section. "
            "Quote the names/labels used by the company where possible."
        ),
        "example": ["Digital transformation", "Expansion into Asian markets", "Cost reduction programme"],
    },
    "mentioned_frameworks": {
        "type": "list of str",
        "description": (
            "All ESG/sustainability reporting frameworks cited anywhere in the document. "
            "Common examples: TCFD, CSRD, GRI, SASB, IFRS S1, IFRS S2, CDP, UN SDG, TNFD, ESRS, "
            "ISO 14001, ISO 50001, Science Based Targets (SBTi)."
        ),
        "example": ["TCFD", "GRI", "SASB", "UN SDG"],
    },
    "dividend_guidance": {
        "type": "str or null",
        "description": (
            "Forward-looking dividend policy statement, e.g. 'progressive dividend policy targeting "
            "40-50% payout ratio'. Null if not disclosed."
        ),
        "example": "Progressive dividend, targeting 40-50% payout ratio",
    },
}

# ── Reporting frameworks used in regex fallback ────────────────────────────────

_FRAMEWORK_PATTERNS: list[tuple[str, str]] = [
    (r"\bTCFD\b", "TCFD"),
    (r"\bCSRD\b", "CSRD"),
    (r"\bESRS\b", "ESRS"),
    (r"\bGRI\b", "GRI"),
    (r"\bSASB\b", "SASB"),
    (r"\bIFRS S1\b", "IFRS S1"),
    (r"\bIFRS S2\b", "IFRS S2"),
    (r"\bCDP\b", "CDP"),
    (r"\bUN SDG\b|\bSDGs?\b", "UN SDG"),
    (r"\bTNFD\b", "TNFD"),
    (r"\bSBTi\b|Science Based Targets", "SBTi"),
    (r"\bISO 14001\b", "ISO 14001"),
    (r"\bISO 50001\b", "ISO 50001"),
    (r"\bISO 27001\b", "ISO 27001"),
    (r"\bIRC\b|Integrated Reporting", "Integrated Reporting (<IR>)"),
    (r"\bPRI\b|Principles for Responsible Investment", "PRI"),
    (r"\bWEF IBC\b|World Economic Forum.*stakeholder", "WEF IBC"),
]

# ── Output file ────────────────────────────────────────────────────────────────

FORWARD_CSV = OUTPUT_DIR / "forward_looking.csv"

# Columns that contain JSON-serialised lists/objects
_JSON_COLUMNS = [
    "interim_targets",
    "renewable_energy_target",
    "capex_guidance",
    "revenue_guidance",
    "key_risks",
    "strategic_initiatives",
    "mentioned_frameworks",
]

_ALL_COLUMNS = [
    "doc",
    "net_zero_year",
    "net_zero_scope",
    "interim_targets",
    "renewable_energy_target",
    "capex_guidance",
    "revenue_guidance",
    "key_risks",
    "strategic_initiatives",
    "mentioned_frameworks",
    "dividend_guidance",
]


# ── Regex-based fallback ───────────────────────────────────────────────────────

def _regex_extract_net_zero_year(text: str) -> Optional[int]:
    """
    Search for net-zero commitment year using regex patterns.
    Returns an int year or None if not found.
    """
    patterns = [
        r"net[\s-]zero\s+(?:by\s+)?(\d{4})",
        r"carbon\s+neutral(?:ity)?\s+(?:by\s+)?(\d{4})",
        r"climate\s+neutral(?:ity)?\s+(?:by\s+)?(\d{4})",
        r"(\d{4})\s+net[\s-]zero",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I)
        if m:
            year = int(m.group(1))
            if 2020 <= year <= 2100:
                return year
    return None


def _regex_extract_frameworks(text: str) -> list[str]:
    """Return list of ESG framework names mentioned in text."""
    found: list[str] = []
    for pattern, label in _FRAMEWORK_PATTERNS:
        if re.search(pattern, text, re.I):
            found.append(label)
    return found


def _regex_fallback(pdf_text: str) -> dict:
    """
    Minimal regex-based extraction for when no API key is available.
    Covers net_zero_year and mentioned_frameworks reliably;
    other fields are returned as None / empty lists.
    """
    sample = pdf_text[:30_000] + pdf_text[-15_000:]
    return {
        "net_zero_year": _regex_extract_net_zero_year(sample),
        "net_zero_scope": "",
        "interim_targets": [],
        "renewable_energy_target": None,
        "capex_guidance": None,
        "revenue_guidance": None,
        "key_risks": [],
        "strategic_initiatives": [],
        "mentioned_frameworks": _regex_extract_frameworks(sample),
        "dividend_guidance": None,
    }


# ── LLM extraction ─────────────────────────────────────────────────────────────

def extract_forward_looking(pdf_text: str, doc_name: str) -> dict:
    """
    Extract forward-looking intelligence from an annual report using Claude Sonnet.

    Uses the first 30,000 characters of the document (CEO letter, strategy section)
    and the last 15,000 characters (appendices, framework references) to maximise
    coverage while controlling token cost.

    The schema definition is placed in the system prompt with cache_control:ephemeral
    so it is only billed once per cache TTL across repeated calls.

    Falls back to regex_fallback() when no API key is configured.

    Args:
        pdf_text: Full extracted text of the PDF document.
        doc_name: Document identifier used for error logging.

    Returns:
        Dict matching EXTRACTION_SCHEMA keys. Missing fields are None or [].
    """
    if not ANTHROPIC_API_KEY:
        return _regex_fallback(pdf_text)

    import anthropic

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    # Build a readable schema description for the system prompt
    schema_lines: list[str] = []
    for field_name, meta in EXTRACTION_SCHEMA.items():
        example_str = json.dumps(meta["example"]) if "example" in meta else ""
        schema_lines.append(
            f'"{field_name}" ({meta["type"]}): {meta["description"]} '
            f'{"Example: " + example_str if example_str else ""}'
        )
    schema_block = "\n".join(f"  • {line}" for line in schema_lines)

    system_prompt_text = (
        "You are a specialist financial analyst extracting forward-looking intelligence "
        "from corporate annual reports and integrated reports. "
        "Your task is to find and return structured data exactly as described in the schema. "
        "Only extract information that is explicitly stated in the document. "
        "Do NOT infer, estimate, or assume. If a field is not present, return null or an empty list.\n\n"
        "OUTPUT FORMAT: Return ONLY a valid JSON object with exactly these keys:\n"
        f"{schema_block}\n\n"
        "STRICT RULES:\n"
        "1. net_zero_year must be an integer (e.g. 2050) or null — not a string.\n"
        "2. interim_targets must be a list of objects with year (int), metric (str), "
        "target_value (str), baseline (str). Empty list if none found.\n"
        "3. renewable_energy_target must be {\"pct\": float, \"year\": int} or null.\n"
        "4. capex_guidance value must be a float, not a string.\n"
        "5. key_risks: maximum 5 items, prefer verbatim language from the risk section.\n"
        "6. strategic_initiatives: maximum 5 items from CEO letter or strategy section.\n"
        "7. mentioned_frameworks: list only frameworks explicitly named in the document.\n"
        "8. Return ONLY the JSON object — no markdown, no commentary."
    )

    # Take front + back slices of the document
    front = pdf_text[:30_000]
    back = pdf_text[-15_000:] if len(pdf_text) > 30_000 else ""
    separator = "\n\n[... middle of document omitted ...]\n\n" if back else ""
    document_excerpt = front + separator + back

    user_prompt = (
        f"Extract all forward-looking intelligence from the following annual report excerpt.\n\n"
        f"DOCUMENT: {doc_name}\n\n"
        f"{document_excerpt}"
    )

    try:
        response = client.messages.create(
            model=COMPLEX_MODEL,
            max_tokens=4096,
            system=system_prompt_text,
            messages=[{"role": "user", "content": user_prompt}],
        )
        raw = response.content[0].text.strip()

        # Strip markdown code fences if present
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)

        data: dict = json.loads(raw)
        return _validate_and_fill(data)

    except json.JSONDecodeError:
        # Try to extract JSON object from response
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                return _validate_and_fill(json.loads(match.group()))
            except Exception:
                pass
        # Enrich regex fallback with framework info
        result = _regex_fallback(pdf_text)
        return result

    except Exception:
        return _regex_fallback(pdf_text)


def _validate_and_fill(data: dict) -> dict:
    """
    Ensure all schema keys are present and coerce obvious type mistakes.
    Returns a clean dict safe for downstream use and CSV serialisation.
    """
    result: dict = {}

    # net_zero_year
    nzy = data.get("net_zero_year")
    if isinstance(nzy, str):
        try:
            nzy = int(nzy)
        except (ValueError, TypeError):
            nzy = None
    result["net_zero_year"] = nzy if isinstance(nzy, int) and 2020 <= nzy <= 2100 else None

    # net_zero_scope
    result["net_zero_scope"] = str(data.get("net_zero_scope") or "")

    # interim_targets
    raw_it = data.get("interim_targets") or []
    cleaned_it: list[dict] = []
    for item in raw_it if isinstance(raw_it, list) else []:
        if isinstance(item, dict):
            cleaned_it.append({
                "year": int(item.get("year", 0)) if item.get("year") else None,
                "metric": str(item.get("metric", "")),
                "target_value": str(item.get("target_value", "")),
                "baseline": str(item.get("baseline", "")),
            })
    result["interim_targets"] = cleaned_it

    # renewable_energy_target
    ret = data.get("renewable_energy_target")
    if isinstance(ret, dict) and "pct" in ret and "year" in ret:
        try:
            result["renewable_energy_target"] = {
                "pct": float(ret["pct"]),
                "year": int(ret["year"]),
            }
        except (ValueError, TypeError):
            result["renewable_energy_target"] = None
    else:
        result["renewable_energy_target"] = None

    # capex_guidance
    cg = data.get("capex_guidance")
    if isinstance(cg, dict) and cg.get("value") is not None:
        try:
            result["capex_guidance"] = {
                "value": float(cg["value"]),
                "currency": str(cg.get("currency", "")).upper()[:3],
                "unit": str(cg.get("unit", "millions")),
                "year": int(cg["year"]) if cg.get("year") else None,
                "description": str(cg.get("description", "")),
            }
        except (ValueError, TypeError):
            result["capex_guidance"] = None
    else:
        result["capex_guidance"] = None

    # revenue_guidance
    rg = data.get("revenue_guidance")
    if isinstance(rg, dict) and rg.get("description"):
        try:
            result["revenue_guidance"] = {
                "description": str(rg.get("description", "")),
                "low_pct": float(rg["low_pct"]) if rg.get("low_pct") is not None else None,
                "high_pct": float(rg["high_pct"]) if rg.get("high_pct") is not None else None,
                "year": int(rg["year"]) if rg.get("year") else None,
            }
        except (ValueError, TypeError):
            result["revenue_guidance"] = None
    else:
        result["revenue_guidance"] = None

    # key_risks
    kr = data.get("key_risks") or []
    result["key_risks"] = [str(r) for r in kr if r][:5]

    # strategic_initiatives
    si = data.get("strategic_initiatives") or []
    result["strategic_initiatives"] = [str(s) for s in si if s][:5]

    # mentioned_frameworks
    mf = data.get("mentioned_frameworks") or []
    result["mentioned_frameworks"] = [str(f) for f in mf if f]

    # dividend_guidance
    dg = data.get("dividend_guidance")
    result["dividend_guidance"] = str(dg) if dg else None

    return result


# ── Persistence ────────────────────────────────────────────────────────────────

def save_forward_looking(data: dict, doc_name: str) -> None:
    """
    Persist forward-looking extraction to outputs/forward_looking.csv.

    List and dict fields are JSON-serialised for CSV storage.
    Existing rows for ``doc_name`` are replaced to prevent duplicates.

    Args:
        data: Output of extract_forward_looking().
        doc_name: Document identifier.
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    existing_rows: list[dict] = []

    if FORWARD_CSV.exists():
        try:
            with FORWARD_CSV.open(newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                existing_rows = [row for row in reader if row.get("doc") != doc_name]
        except Exception:
            existing_rows = []

    row: dict = {"doc": doc_name}
    for col in _ALL_COLUMNS[1:]:  # skip "doc"
        val = data.get(col)
        if col in _JSON_COLUMNS:
            row[col] = json.dumps(val, ensure_ascii=False) if val is not None else "null"
        else:
            row[col] = val if val is not None else ""

    all_rows = existing_rows + [row]

    with FORWARD_CSV.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=_ALL_COLUMNS)
        writer.writeheader()
        writer.writerows(all_rows)


def load_forward_looking(doc_name: Optional[str] = None) -> pd.DataFrame:
    """
    Load forward-looking data from outputs/forward_looking.csv.

    JSON-serialised columns are deserialised back to Python objects.

    Args:
        doc_name: If provided, filter to that document only.

    Returns:
        DataFrame with columns matching _ALL_COLUMNS.
        JSON columns contain Python lists/dicts (not strings).
    """
    if not FORWARD_CSV.exists():
        return pd.DataFrame(columns=_ALL_COLUMNS)

    try:
        df = pd.read_csv(str(FORWARD_CSV), dtype=str)

        # Deserialise JSON columns
        for col in _JSON_COLUMNS:
            if col in df.columns:
                df[col] = df[col].apply(_safe_json_loads)

        # Coerce net_zero_year to Int64 (nullable int)
        if "net_zero_year" in df.columns:
            df["net_zero_year"] = pd.to_numeric(df["net_zero_year"], errors="coerce").astype("Int64")

        if doc_name is not None:
            df = df[df["doc"] == doc_name].reset_index(drop=True)

        return df
    except Exception:
        return pd.DataFrame(columns=_ALL_COLUMNS)


def _safe_json_loads(val):
    """Attempt to parse a JSON string; return original value on failure."""
    if pd.isna(val) or val in ("", "null", "None"):
        return None
    if isinstance(val, str):
        try:
            return json.loads(val)
        except (json.JSONDecodeError, ValueError):
            return val
    return val


# ── Markdown formatter ─────────────────────────────────────────────────────────

def format_targets_markdown(data: dict) -> str:
    """
    Produce a human-readable markdown summary of the forward-looking data.

    Sections rendered (when data is available):
      1. Net-zero commitment
      2. Interim targets (bullet list)
      3. Renewable energy target
      4. CapEx and revenue guidance
      5. Reporting frameworks (inline badges)
      6. Key risks (numbered list)
      7. Strategic initiatives (numbered list)
      8. Dividend guidance

    Args:
        data: Output of extract_forward_looking() or a row from load_forward_looking().

    Returns:
        Markdown string. Returns "(No forward-looking data available)" if data is empty.
    """
    if not data:
        return "(No forward-looking data available)"

    sections: list[str] = []

    # ── Net-zero commitment ────────────────────────────────────────────────────
    nz_year = data.get("net_zero_year")
    nz_scope = data.get("net_zero_scope") or ""
    if nz_year:
        scope_str = f" ({nz_scope})" if nz_scope else ""
        sections.append(f"### Net-Zero Commitment\n**Target year:** {nz_year}{scope_str}")
    else:
        sections.append("### Net-Zero Commitment\n*No net-zero commitment found in document.*")

    # ── Interim targets ────────────────────────────────────────────────────────
    targets = data.get("interim_targets") or []
    if targets:
        lines = ["### Interim Targets"]
        for t in targets:
            year = t.get("year", "?")
            metric = t.get("metric", "")
            value = t.get("target_value", "")
            baseline = t.get("baseline", "")
            baseline_str = f" (baseline: {baseline})" if baseline else ""
            lines.append(f"- **{year}**: {value} — {metric}{baseline_str}")
        sections.append("\n".join(lines))
    else:
        sections.append("### Interim Targets\n*No quantified interim targets found.*")

    # ── Renewable energy target ────────────────────────────────────────────────
    ret = data.get("renewable_energy_target")
    if ret and isinstance(ret, dict):
        pct = ret.get("pct", "")
        year = ret.get("year", "")
        sections.append(f"### Renewable Energy Target\n**{pct}%** renewable energy by **{year}**")

    # ── CapEx guidance ─────────────────────────────────────────────────────────
    cg = data.get("capex_guidance")
    if cg and isinstance(cg, dict) and cg.get("value"):
        value = cg.get("value", "")
        currency = cg.get("currency", "")
        unit = cg.get("unit", "")
        year = cg.get("year", "")
        desc = cg.get("description", "")
        year_str = f" ({year})" if year else ""
        desc_str = f" — {desc}" if desc else ""
        sections.append(
            f"### CapEx Guidance\n"
            f"**{currency} {value} {unit}**{year_str}{desc_str}"
        )

    # ── Revenue guidance ───────────────────────────────────────────────────────
    rg = data.get("revenue_guidance")
    if rg and isinstance(rg, dict) and rg.get("description"):
        desc = rg.get("description", "")
        low = rg.get("low_pct")
        high = rg.get("high_pct")
        year = rg.get("year", "")
        range_str = f" ({low}%–{high}%)" if low is not None and high is not None else ""
        year_str = f" for {year}" if year else ""
        sections.append(f"### Revenue Guidance\n{desc}{range_str}{year_str}")

    # ── Reporting frameworks ───────────────────────────────────────────────────
    frameworks = data.get("mentioned_frameworks") or []
    if frameworks:
        if isinstance(frameworks, str):
            try:
                frameworks = json.loads(frameworks)
            except Exception:
                frameworks = [frameworks]
        badges = " ".join(f"`{f}`" for f in frameworks)
        sections.append(f"### Reporting Frameworks\n{badges}")
    else:
        sections.append("### Reporting Frameworks\n*None explicitly cited.*")

    # ── Key risks ──────────────────────────────────────────────────────────────
    risks = data.get("key_risks") or []
    if risks:
        if isinstance(risks, str):
            try:
                risks = json.loads(risks)
            except Exception:
                risks = [risks]
        lines = ["### Key Risks"]
        for i, risk in enumerate(risks, 1):
            lines.append(f"{i}. {risk}")
        sections.append("\n".join(lines))
    else:
        sections.append("### Key Risks\n*No key risks extracted.*")

    # ── Strategic initiatives ─────────────────────────────────────────────────
    initiatives = data.get("strategic_initiatives") or []
    if initiatives:
        if isinstance(initiatives, str):
            try:
                initiatives = json.loads(initiatives)
            except Exception:
                initiatives = [initiatives]
        lines = ["### Strategic Initiatives"]
        for i, init in enumerate(initiatives, 1):
            lines.append(f"{i}. {init}")
        sections.append("\n".join(lines))

    # ── Dividend guidance ──────────────────────────────────────────────────────
    dg = data.get("dividend_guidance")
    if dg:
        sections.append(f"### Dividend Policy\n{dg}")

    return "\n\n".join(sections)


# ── CLI entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python forward_looking.py <path_to_pdf>")
        sys.exit(1)

    from esg_scorer import extract_full_text

    pdf_path = Path(sys.argv[1])
    if not pdf_path.exists():
        print(f"File not found: {pdf_path}")
        sys.exit(1)

    print(f"Extracting text from {pdf_path.name}...")
    text = extract_full_text(pdf_path)
    print(f"Extracted {len(text):,} characters. Running forward-looking extraction...")

    result = extract_forward_looking(text, pdf_path.name)

    print("\n" + "=" * 60)
    print(f"Document: {pdf_path.name}")
    print("=" * 60)
    print(json.dumps(result, indent=2, ensure_ascii=False))

    print("\n" + "=" * 60)
    print("MARKDOWN SUMMARY")
    print("=" * 60)
    print(format_targets_markdown(result))

    save_forward_looking(result, pdf_path.name)
    print(f"\nData saved to {FORWARD_CSV}")
