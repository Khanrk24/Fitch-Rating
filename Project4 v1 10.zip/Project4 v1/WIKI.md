# FinExtract AI — Complete Handoff Wiki

> **What this is:** An AI-powered financial intelligence platform that reads annual report PDFs and produces Fitch-grade ESG scores, segment revenue extraction, regulatory gap analysis, live company intelligence, and professional research notes.
>
> **Built for:** Fitch-style credit and ESG analysis. Rivals Bloomberg ESG, MSCI ESG Ratings, and Fitch Connect at a fraction of the cost.

---

## Table of Contents

1. [What This Does — Plain English](#1-what-this-does)
2. [The API Key — Where It Is & How It Works](#2-the-api-key)
3. [First-Time Setup (New Machine)](#3-first-time-setup)
4. [Starting the App Every Time](#4-starting-the-app)
5. [The 10 Pages — What Each One Does](#5-the-10-pages)
6. [How the Pipeline Works — All 9 Agents](#6-the-9-agent-pipeline)
7. [ESG Scoring — The Full Methodology](#7-esg-scoring-methodology)
8. [Fitch Factor Scoring — The 16 Factors](#8-fitch-factor-scoring)
9. [Regulatory Mapping — CSRD, TCFD, EU Taxonomy](#9-regulatory-mapping)
10. [Forward-Looking Intelligence](#10-forward-looking-intelligence)
11. [Company Search & Live News](#11-company-search--live-news)
12. [The AI Chatbot](#12-the-ai-chatbot)
13. [Report Generation](#13-report-generation)
14. [Complete File Structure](#14-file-structure)
15. [API Cost Breakdown](#15-api-cost-breakdown)
16. [Troubleshooting](#16-troubleshooting)
17. [How to Add More PDFs](#17-adding-more-pdfs)
18. [Quick Reference Card](#18-quick-reference-card)

---

## 1. What This Does

FinExtract AI takes a financial PDF — annual report, 10-K, integrated report, financial statements — and runs it through a 9-agent AI pipeline that produces:


| Output                    | Example                                                  |
| ------------------------- | -------------------------------------------------------- |
| Business segment revenues | "Offshore Wind: DKK 54,797m · Onshore: DKK 2,886m"       |
| Currency, unit, period    | "EUR thousands · FY 2024 (Dec 31, 2024)"                 |
| Fitch ESG Factor scores   | "E1 GHG Emissions: 4/5 · G1 Board Structure: 2/5"        |
| Greenwashing detection    | "Net-zero target without third-party assurance (−8 pts)" |
| NACE industry code        | "D 35.11 — Renewable energy production"                  |
| CSRD/TCFD alignment       | "CSRD: 68% aligned · TCFD: 82% aligned"                  |
| Net-zero commitments      | "Net-zero by 2040 covering Scope 1+2"                    |
| Key risks                 | Verbatim risk factors from the report                    |
| Live news brief           | Recent financial + ESG headlines summarised by Claude    |
| Professional report       | One-click HTML research note (print to PDF)              |


**Languages:** English, German, French, Dutch, Turkish, Arabic, Spanish, Polish — anything Claude can read.

**Cost:** ~$0.01–0.05 per document vs $10–15 for Azure Document Intelligence or Bloomberg data.

**Accuracy:** 100% recall on 30 verified ground truth rows across 5 documents.

---

## 2. The API Key

### Where it is

```
/Users/rahimkhan/Desktop/Project4/.env
```

Open that file in any text editor. It contains one line:

```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

**That key is what pays for all AI calls** — segment extraction, ESG scoring, Fitch factors, forward-looking analysis, the chatbot, everything. Guard it like a password.

### How it's loaded

`config.py` loads the `.env` file automatically at startup using the `python-dotenv` library. Every Python module imports from `config.py`, so the key flows through automatically — you never need to paste it into code.

### If you need a new key

1. Go to **[https://console.anthropic.com](https://console.anthropic.com)**
2. Log in → API Keys → Create key
3. Open `/Users/rahimkhan/Desktop/Project4/.env`
4. Replace the old key: `ANTHROPIC_API_KEY=your-new-key-here`
5. Restart the app

### What happens without a key

The system degrades gracefully:

- Segment extraction: switches to rule-based regex parser (still works, lower accuracy)
- Fitch factor scoring: uses keyword regex (scores capped at 3/5)
- Forward-looking: extracts only frameworks mentioned (regex)
- Regulatory: returns empty (requires LLM)
- Chatbot: returns a warning message

---

## 3. First-Time Setup

Do this **once** when setting up on a new machine.

### Step 1 — Open Terminal in the project folder

```bash
cd /Users/rahimkhan/Desktop/Project4
```

### Step 2 — Install all dependencies

```bash
pip3 install -r requirements.txt
```

This installs: PyMuPDF, pdfplumber, anthropic, pandas, streamlit, plotly, rapidfuzz, duckduckgo-search (ddgs), and others. Takes ~60 seconds.

### Step 3 — Verify setup

```bash
python3 -c "from pipeline import process_one_pdf; print('Setup OK ✅')"
```

Should print `Setup OK ✅`. If it errors, run the install step again.

### Step 4 — Check the API key

```bash
python3 -c "from config import ANTHROPIC_API_KEY; print('Key loaded:', ANTHROPIC_API_KEY[:20] + '...' if ANTHROPIC_API_KEY else 'MISSING')"
```

---

## 4. Starting the App Every Time

```bash
cd /Users/rahimkhan/Desktop/Project4
python3 -m streamlit run app.py
```

Then open your browser to: **[http://localhost:8501](http://localhost:8501)**

The terminal must stay open. Close it to stop the app.

### If port 8501 is already in use

```bash
python3 -m streamlit run app.py --server.port 8502
```

Then open [http://localhost:8502](http://localhost:8502)

### Running the pipeline from the command line (no browser)

```bash
# Process 5 ground truth PDFs only (fast, ~2 minutes)
python3 pipeline.py

# Process up to 20 PDFs
python3 pipeline.py --max 20

# Process a specific file
python3 pipeline.py --pdfs "82_Orsted Annual Report 2025.pdf"

# Process all PDFs silently
python3 pipeline.py --quiet
```

---

## 5. The 10 Pages

### 📤 Upload & Analyse

The main page. Drop any annual report PDF here.

**What happens when you upload:**

1. AI scans every page, finds the segment revenue table (~5–10 seconds)
2. Claude extracts segment names, values, currency, unit, period (~5 seconds)
3. NACE industry code is assigned to each segment
4. Full PDF text is scored for ESG (keyword scan, instant)
5. Claude scores all 16 Fitch ESG factors (one batched LLM call, ~13 seconds)
6. Claude extracts net-zero targets, CapEx guidance, key risks (~5 seconds)
7. Claude checks CSRD, TCFD, and EU Taxonomy alignment (~15 seconds)

**Total time:** ~40–60 seconds per PDF (most of that is LLM API calls)

**What you see:**

- Left column: segment table + bar chart + CSV download
- Right column: ESG radar + Fitch factor mini heat map + net-zero box + CSRD/TCFD % + NACE codes

**If extraction fails:**

- Debug panel opens showing which pages were scanned
- Use "Show page text" to preview pages and find the segment table
- Enter the correct page number and re-extract manually

---

### 🔍 Company Search

Type any company name. The AI:

1. Searches the web (DuckDuckGo) for their latest annual report
2. Shows a direct link (auto-downloads if it's a PDF URL)
3. Suggests 6 peer/comparable companies (Fitch peer group logic)
4. Fetches recent financial + ESG news headlines
5. Claude writes a 3-section analyst brief (business performance, ESG profile, credit factors)

The news and analyst brief flow automatically into the AI Chat page.

---

### 💬 AI Chat

A streaming chatbot that knows everything about the company you've been working on:

- All extracted segment data (revenues, currencies, period)
- All 16 Fitch ESG factor scores with evidence quotes
- Net-zero commitments, targets, key risks
- CSRD/TCFD/EU Taxonomy alignment percentages
- Recent news headlines + analyst brief
- Fitch ESG methodology framework

Ask it anything: "What's the largest revenue segment?", "Are there greenwashing concerns?", "Write a Fitch-style credit summary", "How complete is the CSRD disclosure?"

Suggested starter questions appear automatically based on what data is loaded. Context persists for the whole session.

---

### 📊 Results Dashboard

Overview of all documents processed so far:

- Document count, total segments, currency coverage, average confidence
- Currency distribution pie (shows global reach)
- NACE section bar chart
- Browse/filter all extracted data across all documents
- Per-document segment waterfall chart
- Download everything as one CSV

---

### 🌱 ESG & Fitch Factors

The flagship analysis page:

- **Fitch factor heat map** across all documents — 16 factors, colour coded 1 (red/none) to 5 (green/best practice)
- Average factor score bar chart (shows which disclosure areas are weakest across your portfolio)
- Per-document deep dive: each factor with score + evidence quote from the document
- Greenwashing risk table sorted by penalty
- ESG score distribution histogram
- Environmental vs Governance scatter plot (bubble = greenwashing risk)

---

### 📋 Regulatory Mapping

Disclosure gap analysis against three frameworks:

**CSRD/ESRS (20 requirements)** — EU Corporate Sustainability Reporting Directive. From E1-1 (transition plan) to G1-6 (payment practices). Shows which are disclosed, partial, or missing, with the verbatim evidence quote from the document.

**TCFD (11 recommendations)** — Task Force on Climate-related Financial Disclosures. Across 4 pillars: Governance, Strategy, Risk Management, Metrics & Targets.

**EU Taxonomy (8 requirements)** — Article 8 disclosures: taxonomy-eligible/aligned revenue, CapEx plan, DNSH assessment, minimum social safeguards.

For each requirement: ✅ Disclosed / 🟡 Partial / ❌ Not Found, plus evidence.

If multiple documents processed: cross-document compliance comparison bar chart.

---

### 📊 Portfolio Analytics

Multi-company intelligence — requires 2+ processed documents:

- **ESG ranking table** — all companies ranked by composite ESG score with E/S/G breakdown
- **Peer comparison radar** — overlay ESG radar charts for up to 4 companies simultaneously
- **Dimension bar chart** — E/S/G scores grouped by company
- **Net-zero tracker** — horizontal bar showing each company's net-zero target year (earlier = more ambitious)
- **Revenue comparison** — total reported revenue by company (with currency)

---

### 📄 Generate Report

One-click professional HTML research note:

- Configurable: toggle news, peers, regulatory sections
- Shows what context is loaded (segments, Fitch factors, ESG, targets, news)
- Downloads as `.html` — open in browser and File → Print → Save as PDF for PDF output

**Report structure:**

1. Header with company name, ESG rating badge, period
2. Executive summary (4 data-driven bullets, no LLM)
3. Revenue segment table + SVG bar chart
4. Fitch ESG factor heat map (all 16 factors, colour-coded)
5. Regulatory gap tables (CSRD, TCFD, EU Taxonomy)
6. Net-zero commitment box + interim targets + key risks
7. Recent news card grid
8. Peer companies table

---

### 🏭 NACE Classification

NACE Rev 2.1 is the EU standard for industry classification (used in CSRD, ESRS, ESG benchmarking):

- Treemap of all NACE sections across your portfolio
- Classification confidence distribution
- Full tagged segment table (filterable)

---

### ✅ Accuracy Validation

Compares AI extractions against the verified ground truth spreadsheet:

- Overall recall, precision, F1
- Per-document recall bar chart (blue line = 90% target)
- Row-level match detail table
- Can trigger a fresh pipeline run on the 5 ground truth PDFs

**Current accuracy: 100% recall on 30 ground truth rows**

---

## 6. The 9-Agent Pipeline

Every uploaded PDF flows through these agents in sequence:

```
PDF
 │
 ▼
Agent 1 — PAGE FINDER (table_extractor.py)
  Keywords: "segment", "revenues", "turnover", "operating income"...
  Scores every page. Returns top 7 candidates.
  Also includes pages adjacent to the top scorer (catches tables
  that spill onto the next page after an intro paragraph).
 │
 ▼
Agent 2 — TABLE EXTRACTOR (table_extractor.py)
  PyMuPDF: raw text extraction (preserves column layout)
  pdfplumber: structured table cells
  Combines both into a "page context" string for the LLM.
 │
 ▼
Agent 3 — LLM EXTRACTOR (llm_extractor.py)
  Claude Haiku first (cheap, fast).
  Strict prompt: business segments only, most recent year, preserve negatives.
  If confidence < 60%: auto-escalates to Claude Sonnet.
  Math check: segment sum should ≈ total row (within 15%).
  Falls back to regex parser if no API key.
 │
 ▼
Agent 4 — NACE TAGGER (nace_tagger.py)
  30+ keyword rules → NACE Rev 2.1 section + division
  Company context from first page refines classification.
  Confidence score per tag.
 │
 ▼
Agent 5 — ESG SCORER (esg_scorer.py)
  Keyword/regex scan of full PDF text.
  E: Scope 1/2/3, renewables, intensity, net-zero, assurance
  S: Safety metrics, diversity, employee count
  G: Audit, board, compliance frameworks
  5 greenwashing flags (up to −40 pts penalty).
 │
 ▼
Agent 5b — FITCH FACTOR SCORER (fitch_scorer.py)
  Single batched Claude Haiku call for all 16 factors.
  Prompt caching on factor definitions (billed once per 5 min).
  Returns score 1–5 + verbatim evidence quote per factor.
  Regex fallback if no API key (scores capped at 3/5).
 │
 ▼
Agent 5c — FORWARD-LOOKING EXTRACTOR (forward_looking.py)
  Claude Sonnet reads first 30k + last 15k chars of PDF.
  Extracts: net_zero_year, interim_targets, renewable_target,
  capex_guidance, revenue_guidance, key_risks (max 5),
  strategic_initiatives (max 5), mentioned_frameworks.
  Regex fallback for frameworks + net-zero year.
 │
 ▼
Agent 5d — REGULATORY CHECKER (regulatory_checker.py)
  3 batched Claude Haiku calls (one per framework).
  Checks each requirement and returns status + evidence.
  CSRD: 20 ESRS requirements
  TCFD: 11 recommended disclosures
  EU Taxonomy: 8 Article 8 requirements
 │
 ▼
Agent 6 — VALIDATOR (validator.py)
  Compares against sample_ground_truth.xlsx (optional).
  Fuzzy name match (rapidfuzz, ≥65% token similarity).
  Value match: ±1% tolerance.
  Reports precision / recall / F1.
```

**Total pipeline time per PDF:** ~40–60 seconds (network-bound by LLM API calls)

---

## 7. ESG Scoring Methodology

### Environmental Score (50% of composite)

Scored 0–100 from keyword detection of the full PDF text:


| Indicator                                                   | Points |
| ----------------------------------------------------------- | ------ |
| Scope 1 emissions reported                                  | +15    |
| Scope 2 emissions reported                                  | +15    |
| Scope 3 emissions reported                                  | +20    |
| Net-zero / carbon neutral target                            | +10    |
| Carbon reduction target with year                           | +10    |
| Third-party assurance (Deloitte, PwC, Bureau Veritas, DNV…) | +15    |
| Renewable energy mentioned                                  | +10    |
| Carbon intensity metric                                     | +5     |


Then the greenwashing penalty is subtracted (up to −40 pts):


| Greenwashing Flag                               | Penalty            |
| ----------------------------------------------- | ------------------ |
| Reports Scope 1+2 but omits Scope 3             | −10                |
| Net-zero claimed without assurance              | −8                 |
| Vague language (>3 phrases)                     | −2/phrase, max −12 |
| Suspiciously round emission numbers             | −5                 |
| Sustainability claims with zero quantified data | −15                |


### Social Score (25% of composite)


| Indicator                                  | Points |
| ------------------------------------------ | ------ |
| Employee count disclosed                   | +30    |
| Safety metrics (LTIR, fatality rate, TRIR) | +40    |
| Diversity / gender / inclusion data        | +30    |


### Governance Score (25% of composite)


| Indicator                                                      | Points |
| -------------------------------------------------------------- | ------ |
| External audit mentioned                                       | +35    |
| Board composition described                                    | +30    |
| Compliance framework cited (TCFD, CSRD, GRI, SASB, IFRS S1/S2) | +35    |


### Composite & Rating

```
Composite = (E_score × 0.50) + (S_score × 0.25) + (G_score × 0.25)
```


| Rating | Composite |
| ------ | --------- |
| AAA    | 80–100    |
| AA     | 65–79     |
| A      | 50–64     |
| BBB    | 35–49     |
| BB     | 20–34     |
| B      | 0–19      |


---

## 8. Fitch Factor Scoring

The 16 Fitch ESG factors are scored 1–5 by Claude Haiku reading the actual document text.

### Scoring scale


| Score | Label   | Meaning                                  |
| ----- | ------- | ---------------------------------------- |
| 1     | None    | Not disclosed at all                     |
| 2     | Minimal | Mentioned qualitatively, no data         |
| 3     | Partial | Some data but incomplete                 |
| 4     | Good    | Comprehensive data, minor gaps           |
| 5     | Best    | Quantified + targeted + verified + trend |


### The 16 Factors

**Environmental (E)**


| ID  | Factor                      | What it looks for                                 |
| --- | --------------------------- | ------------------------------------------------- |
| E1  | GHG Emissions               | Scope 1/2/3 absolute levels, intensity, YoY trend |
| E2  | Air Quality                 | SOx, NOx, particulate matter, VOC reporting       |
| E3  | Energy Management           | Consumption, renewable %, efficiency programs     |
| E4  | Water & Wastewater          | Withdrawal, consumption, recycled water metrics   |
| E5  | Waste & Hazardous Materials | Total waste, hazardous waste, circular economy    |
| E6  | Ecological Impacts          | Biodiversity, land use, protected area impacts    |


**Social (S)**


| ID  | Factor                      | What it looks for                                            |
| --- | --------------------------- | ------------------------------------------------------------ |
| S1  | Human Capital Management    | Training hours, turnover rate, engagement scores             |
| S2  | Human Rights & Supply Chain | Supply chain audits, modern slavery statement, supplier code |
| S3  | Community Relations         | Community investment, stakeholder engagement                 |
| S4  | Customer Welfare            | Product safety, recalls, satisfaction data                   |
| S5  | Data Security & Privacy     | Cybersecurity framework, GDPR, breach disclosures            |


**Governance (G)**


| ID  | Factor                         | What it looks for                                    |
| --- | ------------------------------ | ---------------------------------------------------- |
| G1  | Board Structure & Independence | Composition, % independent directors, committees     |
| G2  | Executive Compensation         | Pay ratios, ESG-linked remuneration, clawbacks       |
| G3  | Accounting Transparency        | Audit quality, non-GAAP reconciliation, restatements |
| G4  | Anti-Corruption & Bribery      | Policy, training programme, incident reporting       |
| G5  | Legal & Regulatory Risk        | Litigation provisions, regulatory proceedings        |


### How the call works

All 16 factors are sent in a single Claude Haiku call with the first 50,000 characters of the PDF. The factor definitions are cached (so you only pay for them once per 5 minutes). Claude returns a JSON array of 16 objects, each with `score`, `evidence` (verbatim quote), and `disclosed` (bool).

---

## 9. Regulatory Mapping

### CSRD / ESRS (20 requirements checked)

The Corporate Sustainability Reporting Directive requires large EU companies to disclose against European Sustainability Reporting Standards. The 20 requirements checked span:

- **E1 Climate** — Transition plan, GHG targets, Scope 1/2/3, physical & transition risk financial effects, internal carbon price
- **E2 Pollution** — Air pollutants (SOx, NOx, PM)
- **E3 Water** — Water consumption and recycled water metrics
- **E4 Biodiversity** — Ecosystem impacts
- **E5 Resources** — Circular economy metrics
- **S1 Own Workforce** — Diversity, collective bargaining, H&S, pay gap
- **G1 Business Conduct** — Anti-corruption policies, incidents, payment practices

### TCFD (11 requirements across 4 pillars)


| Pillar            | Requirements                                                        |
| ----------------- | ------------------------------------------------------------------- |
| Governance        | Board oversight of climate; management's role                       |
| Strategy          | Short/medium/long-term risks; impact on business; scenario analysis |
| Risk Management   | Identify process; manage process; integration into overall risk     |
| Metrics & Targets | Scope 1+2 GHG; climate metrics; climate targets                     |


### EU Taxonomy (8 requirements)

Article 8 disclosures: taxonomy-eligible/aligned revenue %, CapEx plan, OpEx, climate mitigation/adaptation objective alignment, DNSH assessment, minimum social safeguards.

### How it works technically

Three batched Claude Haiku calls — one per framework. Each call passes all requirements as a numbered list and asks Claude to check the document text (first 60,000 chars) for each one, returning `status` + `evidence` per requirement. Prompt caching keeps cost minimal.

---

## 10. Forward-Looking Intelligence

Extracts commitments and guidance from the strategic sections of annual reports.

**What gets extracted:**


| Field                     | Example                                                                        |
| ------------------------- | ------------------------------------------------------------------------------ |
| `net_zero_year`           | 2040                                                                           |
| `net_zero_scope`          | "Scope 1 and 2"                                                                |
| `interim_targets`         | [{year: 2030, metric: "GHG reduction", target_value: "30%", baseline: "2019"}] |
| `renewable_energy_target` | {pct: 100, year: 2030}                                                         |
| `capex_guidance`          | {value: 5.2, currency: "EUR", unit: "billions", year: 2025}                    |
| `revenue_guidance`        | {description: "10–15% growth", year: 2025}                                     |
| `key_risks`               | Up to 5 verbatim risk statements                                               |
| `strategic_initiatives`   | Up to 5 strategic priorities                                                   |
| `mentioned_frameworks`    | ["TCFD", "CSRD", "GRI", "UN SDG"]                                              |


**How it works:** Claude Sonnet reads the first 30,000 + last 15,000 characters of the PDF (capturing CEO letter + appendices + risk section). Returns structured JSON validated against the schema.

---

## 11. Company Search & Live News

### Company Search

Uses DuckDuckGo web search (free, no API key needed beyond Anthropic) to find the latest annual report PDF for any company.

Process:

1. Runs 2 search queries (filetype:pdf + investor relations)
2. Claude picks the best result (most recent, most likely to be the right filing)
3. If the URL ends in `.pdf`, offers auto-download to the Project4 folder
4. Suggests 6 peer companies (Fitch-style peer group, from Claude's training)
5. Fetches recent news (financial results + ESG headlines)
6. Claude writes a 3-section analyst brief

### News

Two DuckDuckGo news searches per company (financial results + ESG). Results deduplicated and displayed as a 2-column card grid with date, source, headline, and snippet.

---

## 12. The AI Chatbot

The chatbot uses Claude Sonnet with the full context of everything you've been working on injected into the system prompt:

- Extracted segment revenues (with currency, unit, period)
- All 16 Fitch factor scores + evidence quotes
- Full ESG scores with greenwashing flags
- Net-zero commitments, interim targets, key risks
- CSRD/TCFD/EU Taxonomy alignment percentages
- Recent news headlines and analyst brief

**Prompt caching** is used on the system prompt — so repeated questions about the same company cost almost nothing after the first one.

The chatbot uses Fitch ESG Relevance Score methodology in its answers — it understands that E1 (GHG Emissions) scoring a 5 vs 1 has different credit implications than G4 (Anti-Corruption) scoring the same.

---

## 13. Report Generation

Generates a self-contained HTML file (no external dependencies needed to open it).

**To get a PDF:** Open the HTML file in Chrome/Safari → File → Print → Save as PDF. This produces a clean, professional PDF that looks like a real research note.

**The report is entirely data-driven** — no LLM call is made during report generation. Everything comes from data already extracted. The executive summary is computed from the data (revenue total, ESG rating, net-zero year, top risk).

---

## 14. File Structure

```
Project4/
│
├── app.py                    ← Streamlit web app — all 10 pages
├── pipeline.py               ← Orchestrates all 9 agents
│
├── ── EXTRACTION AGENTS ──
├── table_extractor.py        ← Agent 1+2: page finder + text/table extractor
├── llm_extractor.py          ← Agent 3: Claude segment extraction
├── nace_tagger.py            ← Agent 4: NACE Rev 2.1 classification
├── esg_scorer.py             ← Agent 5: keyword ESG scoring + greenwashing
├── fitch_scorer.py           ← Agent 5b: 16-factor LLM Fitch scoring
├── forward_looking.py        ← Agent 5c: targets, guidance, risks extractor
├── regulatory_checker.py     ← Agent 5d: CSRD, TCFD, EU Taxonomy gap check
├── validator.py              ← Agent 6: accuracy vs ground truth
│
├── ── INTELLIGENCE MODULES ──
├── company_search.py         ← Web filing finder, peer suggestions, news
├── chatbot.py                ← Streaming AI chatbot with full context
├── report_generator.py       ← HTML research note generator
│
├── ── CONFIGURATION ──
├── config.py                 ← All paths, model names, thresholds
├── requirements.txt          ← Python packages
├── .env                      ← YOUR API KEY (never share this file)
├── .env.example              ← Template for new machines
│
├── ── DOCUMENTATION ──
├── WIKI.md                   ← This file
├── ARCHITECTURE.md           ← Technical architecture
│
├── outputs/                  ← All AI outputs (auto-created)
│   ├── extracted_segments.csv    ← Segment revenues for all docs
│   ├── esg_scores.csv            ← ESG scores + greenwashing flags
│   ├── fitch_factors.csv         ← All 16 factor scores per doc
│   ├── forward_looking.csv       ← Net-zero targets, guidance, risks
│   ├── regulatory_gaps.csv       ← CSRD/TCFD/EU Taxonomy gaps
│   ├── validation_results.csv    ← Accuracy vs ground truth
│   └── nace_tags.csv             ← NACE classification output
│
└── [100+ PDF files]              ← Annual reports (root folder)
```

### Key output file schemas

`**extracted_segments.csv**`


| Column                  | Description           | Example                            |
| ----------------------- | --------------------- | ---------------------------------- |
| `doc`                   | PDF filename          | `82_Orsted Annual Report 2025.pdf` |
| `source_page`           | Page data came from   | `34`                               |
| `segment`               | Business segment name | `Offshore`                         |
| `value_label`           | Type of metric        | `Revenue`                          |
| `value`                 | Numeric value         | `54797.0`                          |
| `currency`              | ISO code              | `DKK`                              |
| `unit`                  | Scale                 | `millions`                         |
| `reporting_period`      | Fiscal year-end       | `2025-12-31`                       |
| `extraction_confidence` | 0.0–1.0               | `0.95`                             |
| `nace_section`          | NACE letter           | `D`                                |
| `nace_description`      | Industry name         | `Renewable energy production`      |


`**fitch_factors.csv**`


| Column      | Description                  |
| ----------- | ---------------------------- |
| `doc`       | PDF filename                 |
| `factor_id` | E1 through G5                |
| `name`      | Factor name                  |
| `dimension` | E, S, or G                   |
| `score`     | 1–5                          |
| `evidence`  | Verbatim quote from document |
| `disclosed` | True/False                   |


`**regulatory_gaps.csv**`


| Column           | Description                         |
| ---------------- | ----------------------------------- |
| `doc`            | PDF filename                        |
| `framework`      | csrd / tcfd / eu_taxonomy           |
| `requirement_id` | E.g., E1-6                          |
| `requirement`    | Requirement text                    |
| `status`         | disclosed / partial / not_disclosed |
| `evidence`       | Verbatim quote                      |


---

## 15. API Cost Breakdown

### Models used and why


| Model         | Used for                                                             | Cost                  |
| ------------- | -------------------------------------------------------------------- | --------------------- |
| Claude Haiku  | Segment extraction (primary), Fitch factors, regulatory check        | ~$0.80/M input tokens |
| Claude Sonnet | Segment escalation (low confidence), forward-looking, chatbot, peers | ~$3/M input tokens    |


### Cost per document (typical)


| Agent                           | Model          | Approx cost     |
| ------------------------------- | -------------- | --------------- |
| Segment extraction (3–7 pages)  | Haiku          | ~$0.003         |
| ESG scoring (keyword only)      | No LLM         | $0              |
| Fitch 16-factor scoring         | Haiku (cached) | ~$0.003         |
| Forward-looking extraction      | Sonnet         | ~$0.008         |
| Regulatory check (3 frameworks) | Haiku          | ~$0.006         |
| **Total per PDF**               |                | **~$0.02–0.05** |


### Chatbot cost

Each message: ~$0.002–0.01 depending on context length and response length. The system prompt is cached so repeated questions about the same company cost ~90% less after the first message.

### vs competitors


| Tool                        | Cost per document  | Annual for 1,000 docs |
| --------------------------- | ------------------ | --------------------- |
| Azure Document Intelligence | $1.50              | $1,500                |
| Bloomberg ESG Data          | $50–500+           | $50,000–500,000       |
| Fitch Connect subscription  | $10,000+/year flat | $10,000+              |
| **FinExtract AI**           | **~$0.03**         | **~$30**              |


---

## 16. Troubleshooting

### "Auto-extraction failed: LLM could not extract segments"

The AI couldn't find a segment revenue table automatically.

**Fix:**

1. The debug panel opens showing which pages were scanned
2. Open the PDF in a PDF viewer and find the segment revenue table
3. Note the page number
4. Type it into "Enter the exact page number" and click Extract
5. Use "Show page text" to preview pages directly in the app

**Common causes:**

- The company only has geographic (not business) segments — the system now handles this too
- Segment table is in a non-standard location (try scanning ±5 pages from where you'd expect)
- Very short document with no segment breakdown

### "ModuleNotFoundError: No module named X"

A package isn't installed.

```bash
pip3 install -r requirements.txt
```

### "ModuleNotFoundError: No module named 'ddgs'"

The DuckDuckGo library was renamed.

```bash
pip3 install ddgs
```

### App crashes on startup

Check for syntax errors:

```bash
python3 -c "import py_compile; py_compile.compile('app.py', doraise=True); print('OK')"
```

### Port already in use

```bash
python3 -m streamlit run app.py --server.port 8502
```

### API key not working / authentication error

1. Check the key exists: `cat /Users/rahimkhan/Desktop/Project4/.env`
2. Verify no extra spaces or quotes around the key
3. Get a fresh key at [https://console.anthropic.com](https://console.anthropic.com) if needed
4. Check your Anthropic account has credit balance

### Fitch scoring takes a long time

Normal — it's one LLM call per upload, ~10–15 seconds. If it consistently times out, check your internet connection or Anthropic API status at [https://status.anthropic.com](https://status.anthropic.com)

### News search returns no results

DuckDuckGo occasionally rate-limits. Wait 30 seconds and try again. The rest of the app works without news.

### Report HTML looks wrong

Open the downloaded HTML file in Chrome (not Safari's preview). Chrome renders it correctly. Then use Chrome's print dialog to save as PDF.

---

## 17. Adding More PDFs

### Via the website (recommended)

Go to **📤 Upload & Analyse** and drag any PDF into the upload box. Results appear in ~60 seconds and are saved to the `outputs/` CSVs automatically.

### Via command line (batch processing)

```bash
# Copy PDFs to the Project4 folder, then:
python3 pipeline.py
```

All PDFs in the folder get processed. New results are appended to the output CSVs.

### To add to the ground truth (for accuracy testing)

1. Open `~/Downloads/sample_ground_truth.xlsx`
2. Add rows with this format:


| Column             | Example                             |
| ------------------ | ----------------------------------- |
| `doc`              | `NewCompany_Annual_Report_2025.pdf` |
| `pdf_page_no`      | `47`                                |
| `segment`          | `Digital Solutions`                 |
| `value_label`      | `Revenue`                           |
| `value`            | `2345.0`                            |
| `reporting_period` | `2025-12-31`                        |
| `currency`         | `EUR`                               |
| `unit`             | `millions`                          |


1. Re-run `python3 pipeline.py` and check the ✅ Accuracy Validation page

---

## 18. Quick Reference Card

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FINEXTRACT AI — QUICK REFERENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

START THE APP:
  cd /Users/rahimkhan/Desktop/Project4
  python3 -m streamlit run app.py
  → Open http://localhost:8501

API KEY LOCATION:
  /Users/rahimkhan/Desktop/Project4/.env
  Get new key: https://console.anthropic.com

PROCESS PDFs (command line):
  python3 pipeline.py                  ← all PDFs
  python3 pipeline.py --max 10         ← first 10 only
  python3 pipeline.py --pdfs "X.pdf"   ← specific file

OUTPUTS FOLDER:
  Project4/outputs/
  ├── extracted_segments.csv    ← revenue data
  ├── esg_scores.csv            ← ESG ratings
  ├── fitch_factors.csv         ← 16-factor scores
  ├── forward_looking.csv       ← targets & risks
  ├── regulatory_gaps.csv       ← CSRD/TCFD gaps
  └── validation_results.csv    ← accuracy

INSTALL / REPAIR:
  pip3 install -r requirements.txt

CHECK SYNTAX IF APP BREAKS:
  python3 -c "import py_compile; py_compile.compile('app.py', doraise=True)"

COST ESTIMATE:
  ~$0.03 per PDF (all agents)
  ~$0.005 per chatbot message
  ~$0.00 for news search (DuckDuckGo is free)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

