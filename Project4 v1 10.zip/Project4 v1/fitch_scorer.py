"""
fitch_scorer.py — Fitch-style ESG Factor Scoring
Replaces the simple E/S/G composite in esg_scorer.py with a structured
15-factor scoring framework aligned to Fitch Ratings ESG Relevance Scores.

Factors are scored 1–5:
  1 = Not disclosed
  2 = Qualitative language only (no metrics)
  3 = Partial quantitative data (some metrics, no targets or trend)
  4 = Comprehensive data with gaps (metrics + targets, missing verification or trend)
  5 = Best practice (quantified + time-series + third-party verified + forward-looking targets)

Each dimension's score is averaged across its factors and scaled to 0–100.
Composite = E*50% + S*25% + G*25%, rated AAA → B.
"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Optional

import pandas as pd

from config import ANTHROPIC_API_KEY, EXTRACTION_MODEL, OUTPUT_DIR

# ── Factor definitions ─────────────────────────────────────────────────────────

FITCH_FACTORS: dict[str, dict] = {
    "E1": {
        "name": "GHG Emissions",
        "dimension": "E",
        "description": (
            "Greenhouse gas disclosure covering Scope 1 (direct), Scope 2 (energy indirect), "
            "and Scope 3 (value chain) emissions. Includes absolute levels (tCO2e), "
            "intensity metrics (tCO2e per unit of revenue/output), year-on-year trends, "
            "and reduction targets with baseline years."
        ),
        "score_examples": {
            "1": "No GHG data disclosed anywhere in the document.",
            "3": "Scope 1 and 2 absolute figures given for current year only; no Scope 3, no intensity, no trend.",
            "5": "Scope 1/2/3 absolute + intensity data, multi-year trend table, SBTi-aligned reduction target, "
                 "third-party verified by an accredited assurance provider.",
        },
    },
    "E2": {
        "name": "Air Quality",
        "dimension": "E",
        "description": (
            "Disclosure of air pollutant emissions including sulphur oxides (SOx), nitrogen oxides (NOx), "
            "particulate matter (PM10/PM2.5), and volatile organic compounds (VOCs). "
            "Covers regulatory compliance, abatement investments, and year-on-year trends."
        ),
        "score_examples": {
            "1": "No air quality data or discussion in the document.",
            "3": "Brief mention of NOx or SOx compliance without quantified emission levels.",
            "5": "Annual SOx/NOx/PM quantified in tonnes, compared to prior year, linked to regulatory limits, "
                 "with abatement capex disclosed.",
        },
    },
    "E3": {
        "name": "Energy Management",
        "dimension": "E",
        "description": (
            "Total energy consumption (MWh or GJ), breakdown by source (fossil vs. renewable), "
            "renewable energy percentage, power purchase agreements (PPAs), "
            "energy efficiency programmes, and energy intensity metrics."
        ),
        "score_examples": {
            "1": "No energy data disclosed.",
            "3": "Total energy consumption figure given; no renewable split or efficiency targets.",
            "5": "Total consumption + renewable % + multi-year trend + named efficiency programmes + "
                 "target renewable % by year, third-party verified.",
        },
    },
    "E4": {
        "name": "Water & Wastewater",
        "dimension": "E",
        "description": (
            "Water withdrawal volumes (by source), water consumption, water recycling/reuse rates, "
            "wastewater treatment and discharge quality, water stress area identification, "
            "and reduction targets."
        ),
        "score_examples": {
            "1": "No water data disclosed.",
            "3": "Total water withdrawal figure only; no source breakdown or targets.",
            "5": "Withdrawal + consumption + recycled water volumes by source, water-stressed site mapping, "
                 "multi-year trend, reduction target with baseline, verified.",
        },
    },
    "E5": {
        "name": "Waste & Hazardous Materials",
        "dimension": "E",
        "description": (
            "Total waste generated (tonnes), split between hazardous and non-hazardous, "
            "disposal routes (landfill, incineration, recycling, reuse), "
            "circular economy initiatives, and waste intensity metrics."
        ),
        "score_examples": {
            "1": "No waste data disclosed.",
            "3": "Total waste figure given; no hazardous split or disposal route detail.",
            "5": "Hazardous vs. non-hazardous split, full disposal-route breakdown, circular economy "
                 "programme described with diversion rate target, multi-year trend.",
        },
    },
    "E6": {
        "name": "Ecological Impacts",
        "dimension": "E",
        "description": (
            "Biodiversity impacts, land use (hectares disturbed and restored), "
            "operations in or near protected areas, species risk assessments, "
            "ecosystem services valuation, and nature-related targets (e.g. TNFD alignment)."
        ),
        "score_examples": {
            "1": "No biodiversity or land-use disclosure.",
            "3": "General statement about environmental sensitivity; no quantified land footprint.",
            "5": "Site-level land footprint quantified, protected-area exposure mapped, biodiversity "
                 "action plans with measurable targets, TNFD or SBTN-aligned disclosure.",
        },
    },
    "S1": {
        "name": "Human Capital Management",
        "dimension": "S",
        "description": (
            "Employee headcount (FTE), training hours per employee, voluntary turnover rate, "
            "employee engagement/satisfaction scores, diversity statistics (gender, ethnicity), "
            "and talent development programmes."
        ),
        "score_examples": {
            "1": "No employee metrics disclosed.",
            "3": "Headcount and gender ratio given; no training hours or turnover rate.",
            "5": "Full suite: headcount + gender/ethnicity breakdown + training hours/employee + "
                 "turnover rate + engagement score + multi-year trend + targets.",
        },
    },
    "S2": {
        "name": "Human Rights & Supply Chain",
        "dimension": "S",
        "description": (
            "Supply chain human rights due diligence, number of supplier audits conducted, "
            "modern slavery statement compliance, supplier code of conduct, "
            "remediation actions taken, and coverage of high-risk suppliers."
        ),
        "score_examples": {
            "1": "No supply chain or human rights disclosure.",
            "3": "Modern slavery statement referenced; no audit numbers or remediation detail.",
            "5": "Number of supplier audits, % of spend covered, identified violations and remediation "
                 "actions, modern slavery Act compliance, supplier code sign-off rate.",
        },
    },
    "S3": {
        "name": "Community Relations",
        "dimension": "S",
        "description": (
            "Community investment (£/€/$ or % of pre-tax profit), stakeholder engagement processes, "
            "social licence to operate indicators, local hiring rates, "
            "and community grievance mechanisms."
        ),
        "score_examples": {
            "1": "No community or social investment data.",
            "3": "Community investment amount mentioned but no stakeholder engagement process described.",
            "5": "Community investment quantified + stakeholder engagement programme documented + "
                 "grievance mechanism described + local hiring/procurement % reported.",
        },
    },
    "S4": {
        "name": "Customer Welfare",
        "dimension": "S",
        "description": (
            "Product safety incidents or recalls, customer satisfaction scores (NPS or equivalent), "
            "regulatory fines or penalties for product/service failures, "
            "responsible marketing policies, and accessibility initiatives."
        ),
        "score_examples": {
            "1": "No customer welfare data disclosed.",
            "3": "Customer satisfaction score cited; no product recall or safety incident data.",
            "5": "Safety incident count + recall data + NPS trend + regulatory fine history + "
                 "responsible marketing policy described.",
        },
    },
    "S5": {
        "name": "Data Security & Privacy",
        "dimension": "S",
        "description": (
            "Cybersecurity framework (ISO 27001, NIST, SOC 2), GDPR/CCPA compliance posture, "
            "number and nature of data breach disclosures, security investment levels, "
            "privacy-by-design practices, and regulatory cyber-risk assessments."
        ),
        "score_examples": {
            "1": "No data security or privacy disclosure.",
            "3": "GDPR compliance mentioned; no framework certification or breach history.",
            "5": "Named cybersecurity framework + certification status + breach disclosure (zero or "
                 "quantified) + security investment + DPO governance described.",
        },
    },
    "G1": {
        "name": "Board Structure & Independence",
        "dimension": "G",
        "description": (
            "Board composition (size, tenure, skills matrix), percentage of independent non-executive "
            "directors, board committee structure (audit, remuneration, risk, ESG), "
            "diversity on the board (gender, nationality), and chair/CEO separation."
        ),
        "score_examples": {
            "1": "No board composition data disclosed.",
            "3": "Board size and number of independent directors given; no skills matrix or committee detail.",
            "5": "Full composition table + independence % + skills matrix + committee charters summarised + "
                 "diversity targets + chair/CEO separation confirmed.",
        },
    },
    "G2": {
        "name": "Executive Compensation",
        "dimension": "G",
        "description": (
            "CEO-to-median worker pay ratio, ESG-linked remuneration (% of bonus tied to ESG KPIs), "
            "clawback provisions, share ownership requirements, "
            "and remuneration committee independence."
        ),
        "score_examples": {
            "1": "No executive pay data beyond total remuneration figure.",
            "3": "ESG KPIs mentioned in remuneration policy; no % weighting or pay ratio disclosed.",
            "5": "Pay ratio + ESG weighting % + named ESG KPIs + clawback policy + share ownership "
                 "guidelines + remuneration committee composition.",
        },
    },
    "G3": {
        "name": "Accounting Transparency",
        "dimension": "G",
        "description": (
            "External audit quality (auditor tenure, fees, non-audit services ratio), "
            "non-GAAP/alternative performance measure reconciliation to IFRS/GAAP, "
            "any restatements in the last three years, and material accounting judgement disclosures."
        ),
        "score_examples": {
            "1": "Auditor named but no fee disclosure or reconciliation of non-GAAP measures.",
            "3": "Non-GAAP measures reconciled; auditor fees disclosed but non-audit/audit ratio not.",
            "5": "Full audit fee breakdown + non-audit % + non-GAAP reconciliation table + "
                 "restatement history (none or explained) + key audit matter detail.",
        },
    },
    "G4": {
        "name": "Anti-Corruption & Bribery",
        "dimension": "G",
        "description": (
            "Anti-bribery and corruption (ABC) policy scope, employee training completion rates "
            "(% trained), incidents investigated and outcomes, whistleblower/ethics hotline "
            "usage statistics, and third-party due diligence on agents/distributors."
        ),
        "score_examples": {
            "1": "No ABC policy or training data disclosed.",
            "3": "ABC policy mentioned; no training completion rate or incident count.",
            "5": "Policy + % trained + incident count + hotline usage statistics + "
                 "third-party due diligence process described.",
        },
    },
    "G5": {
        "name": "Legal & Regulatory Risk Management",
        "dimension": "G",
        "description": (
            "Material litigation provisions (amount and nature), ongoing regulatory investigations "
            "or proceedings, compliance breach history, legal risk quantification, "
            "and regulatory change management processes."
        ),
        "score_examples": {
            "1": "No litigation or regulatory risk disclosure beyond boilerplate.",
            "3": "Material litigation provisions quantified; no ongoing regulatory proceedings disclosed.",
            "5": "Provisions quantified + pending proceedings listed + compliance breach history + "
                 "regulatory change monitoring process described.",
        },
    },
}

# ── Scoring guide ──────────────────────────────────────────────────────────────

SCORING_GUIDE: str = (
    "Score 1 — Not disclosed: The topic is entirely absent from the document. "
    "Score 2 — Qualitative only: The topic is mentioned with narrative language but no quantitative metrics. "
    "Score 3 — Partial quantitative: Some numeric metrics are present but the disclosure is incomplete "
    "(e.g. single-year figure, no targets, no third-party verification). "
    "Score 4 — Comprehensive with gaps: Metrics, trends, and targets are present but at least one "
    "element is missing (e.g. no external assurance, or Scope 3 absent). "
    "Score 5 — Best practice: Fully quantified data with multi-year trend, forward-looking targets, "
    "and third-party verified or externally assured. Meets or exceeds leading disclosure standards."
)

# ── Output file ────────────────────────────────────────────────────────────────

FITCH_CSV = OUTPUT_DIR / "fitch_factors.csv"
_FITCH_COLUMNS = ["doc", "factor_id", "name", "dimension", "score", "evidence", "disclosed"]


# ── Regex fallback scorer ──────────────────────────────────────────────────────

def regex_score_fitch_factors(pdf_text: str) -> list[dict]:
    """
    Keyword/regex-based fallback that assigns rough 1–3 scores without an API key.
    Covers the most common signals; never scores above 3 since we cannot verify
    quantification depth without LLM reasoning.

    Returns a list of 15 dicts (same schema as score_fitch_factors output).
    """
    t = pdf_text[:50_000]  # same window as LLM path

    def _has(*patterns: str) -> bool:
        return any(re.search(p, t, re.I) for p in patterns)

    def _mk(fid: str, score: int, evidence: str) -> dict:
        f = FITCH_FACTORS[fid]
        return {
            "factor_id": fid,
            "name": f["name"],
            "dimension": f["dimension"],
            "score": score,
            "evidence": evidence,
            "disclosed": score > 1,
        }

    results: list[dict] = []

    # E1 — GHG Emissions
    scope1 = _has(r"scope\s*1", r"direct emission")
    scope2 = _has(r"scope\s*2", r"energy indirect")
    scope3 = _has(r"scope\s*3", r"value chain.*emission", r"upstream.*emission")
    if scope1 and scope2 and scope3:
        results.append(_mk("E1", 3, "Scope 1, 2, and 3 keywords detected"))
    elif scope1 or scope2:
        results.append(_mk("E1", 2, "Scope 1/2 keywords detected"))
    else:
        results.append(_mk("E1", 1, "Not found"))

    # E2 — Air Quality
    if _has(r"\b(sox|nox|sulphur oxide|nitrogen oxide|particulate|VOC)\b"):
        results.append(_mk("E2", 2, "Air quality pollutant keywords detected"))
    else:
        results.append(_mk("E2", 1, "Not found"))

    # E3 — Energy Management
    if _has(r"renewable energy|solar|wind energy|ppa|power purchase") and _has(r"energy consumption|mwh|gwh|gj\b"):
        results.append(_mk("E3", 3, "Renewable energy and consumption metrics keywords detected"))
    elif _has(r"energy consumption|energy use|mwh|gwh"):
        results.append(_mk("E3", 2, "Energy consumption keywords detected"))
    else:
        results.append(_mk("E3", 1, "Not found"))

    # E4 — Water & Wastewater
    if _has(r"water withdrawal|water consumption|megalit|m3\b|cubic met"):
        results.append(_mk("E4", 3, "Water volume keywords detected"))
    elif _has(r"water use|water management|wastewater"):
        results.append(_mk("E4", 2, "Water management language detected"))
    else:
        results.append(_mk("E4", 1, "Not found"))

    # E5 — Waste & Hazardous
    if _has(r"hazardous waste|tonnes.*waste|waste.*tonnes"):
        results.append(_mk("E5", 3, "Hazardous/quantified waste keywords detected"))
    elif _has(r"waste management|landfill|recycl"):
        results.append(_mk("E5", 2, "Waste management language detected"))
    else:
        results.append(_mk("E5", 1, "Not found"))

    # E6 — Ecological
    if _has(r"biodiversity|land use|protected area|tnfd|sbtn"):
        results.append(_mk("E6", 2, "Biodiversity/ecological keywords detected"))
    else:
        results.append(_mk("E6", 1, "Not found"))

    # S1 — Human Capital
    if _has(r"training hours|hours per employee") and _has(r"turnover rate|attrition"):
        results.append(_mk("S1", 3, "Training hours and turnover keywords detected"))
    elif _has(r"\d[\d,]*\s*(employees|fte|full.time)", r"headcount"):
        results.append(_mk("S1", 2, "Employee count keywords detected"))
    else:
        results.append(_mk("S1", 1, "Not found"))

    # S2 — Human Rights
    if _has(r"supplier audit|modern slavery|human rights due diligence"):
        results.append(_mk("S2", 2, "Human rights/supplier audit keywords detected"))
    else:
        results.append(_mk("S2", 1, "Not found"))

    # S3 — Community
    if _has(r"community investment|social investment|stakeholder engagement"):
        results.append(_mk("S3", 2, "Community/stakeholder keywords detected"))
    else:
        results.append(_mk("S3", 1, "Not found"))

    # S4 — Customer Welfare
    if _has(r"product recall|safety incident|nps|net promoter|customer satisfaction"):
        results.append(_mk("S4", 2, "Customer welfare keywords detected"))
    else:
        results.append(_mk("S4", 1, "Not found"))

    # S5 — Data Security
    if _has(r"iso 27001|soc 2|nist|cybersecurity framework|data breach"):
        results.append(_mk("S5", 2, "Cybersecurity framework/breach keywords detected"))
    elif _has(r"gdpr|ccpa|data protection|privacy"):
        results.append(_mk("S5", 2, "Data privacy keywords detected"))
    else:
        results.append(_mk("S5", 1, "Not found"))

    # G1 — Board Structure
    if _has(r"independent director|non.executive|board composition") and _has(r"audit committee|remuneration committee"):
        results.append(_mk("G1", 3, "Board independence and committee keywords detected"))
    elif _has(r"board of directors|supervisory board"):
        results.append(_mk("G1", 2, "Board structure keywords detected"))
    else:
        results.append(_mk("G1", 1, "Not found"))

    # G2 — Executive Compensation
    if _has(r"esg.linked|esg kpi|sustainability.*remuneration|pay ratio"):
        results.append(_mk("G2", 3, "ESG-linked remuneration and pay ratio keywords detected"))
    elif _has(r"executive remuneration|ceo pay|total compensation"):
        results.append(_mk("G2", 2, "Executive compensation keywords detected"))
    else:
        results.append(_mk("G2", 1, "Not found"))

    # G3 — Accounting Transparency
    if _has(r"non.gaap|alternative performance measure|reconciliation") and _has(r"external audit|statutory audit"):
        results.append(_mk("G3", 3, "Non-GAAP reconciliation and audit keywords detected"))
    elif _has(r"external audit|auditor|audit committee"):
        results.append(_mk("G3", 2, "Audit keywords detected"))
    else:
        results.append(_mk("G3", 1, "Not found"))

    # G4 — Anti-Corruption
    if _has(r"anti.bribery|anti.corruption|abc policy") and _has(r"training.*complet|hotline|whistleblow"):
        results.append(_mk("G4", 3, "ABC policy and training/hotline keywords detected"))
    elif _has(r"anti.bribery|anti.corruption|compliance.*policy"):
        results.append(_mk("G4", 2, "Anti-corruption policy keywords detected"))
    else:
        results.append(_mk("G4", 1, "Not found"))

    # G5 — Legal & Regulatory
    if _has(r"litigation provision|legal provision|regulatory proceeding"):
        results.append(_mk("G5", 3, "Litigation provision and regulatory proceeding keywords detected"))
    elif _has(r"legal risk|compliance risk|regulatory risk"):
        results.append(_mk("G5", 2, "Legal/regulatory risk language detected"))
    else:
        results.append(_mk("G5", 1, "Not found"))

    return results


# ── LLM-based scorer ───────────────────────────────────────────────────────────

def score_fitch_factors(pdf_text: str, doc_name: str) -> list[dict]:
    """
    Score all 15 Fitch ESG factors against the provided PDF text using Claude Haiku.

    Makes a single batched API call with all factor definitions in the system prompt
    (marked with cache_control: ephemeral for prompt caching). Scores each factor
    1–5 and returns verbatim evidence quotes where available.

    Falls back to regex_score_fitch_factors() when no API key is configured.

    Args:
        pdf_text: Full extracted PDF text (up to 50,000 chars are submitted).
        doc_name: Document identifier for logging/error messages.

    Returns:
        List of 15 dicts, one per factor, with keys:
            factor_id, name, dimension, score (int 1-5),
            evidence (str — verbatim quote or "Not found"), disclosed (bool).
    """
    if not ANTHROPIC_API_KEY:
        return regex_score_fitch_factors(pdf_text)

    import anthropic

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    # Build a compact factor reference block for the system prompt
    factor_lines: list[str] = []
    for fid, fdata in FITCH_FACTORS.items():
        factor_lines.append(
            f"{fid} | {fdata['name']} ({fdata['dimension']}) | {fdata['description']} | "
            f"Score 1: {fdata['score_examples']['1']} | "
            f"Score 3: {fdata['score_examples']['3']} | "
            f"Score 5: {fdata['score_examples']['5']}"
        )
    factor_block = "\n".join(factor_lines)

    system_prompt_text = (
        "You are a specialist ESG analyst trained in Fitch Ratings' ESG Relevance Score methodology. "
        "You score 15 predefined ESG factors on a 1-5 scale based solely on disclosed content in "
        "annual reports and sustainability reports.\n\n"
        f"SCORING GUIDE:\n{SCORING_GUIDE}\n\n"
        "FACTOR DEFINITIONS (ID | Name | Description | Score 1 example | Score 3 example | Score 5 example):\n"
        f"{factor_block}"
    )

    user_prompt = (
        "Score each of the 15 Fitch ESG factors for the following document excerpt. "
        "Be strict. Only score what is explicitly quantified in the document. "
        "Do NOT infer or assume. If a topic is not mentioned, score 1. "
        "For each factor provide a short verbatim evidence quote from the text, or 'Not found'.\n\n"
        "Return ONLY a valid JSON array with exactly 15 objects, one per factor, in the same order "
        "as the factor definitions. Each object must have these keys:\n"
        '  "factor_id": string (e.g. "E1"),\n'
        '  "score": integer 1-5,\n'
        '  "evidence": string (verbatim quote from document, max 200 chars, or "Not found")\n\n'
        "DOCUMENT EXCERPT (first 50,000 characters):\n"
        f"{pdf_text[:50_000]}"
    )

    try:
        response = client.messages.create(
            model=EXTRACTION_MODEL,
            max_tokens=4096,
            system=system_prompt_text,
            messages=[{"role": "user", "content": user_prompt}],
        )
        raw = response.content[0].text.strip()

        # Strip markdown code fences if present
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)

        parsed: list[dict] = json.loads(raw)

        # Normalise and fill in name/dimension from our master dict
        results: list[dict] = []
        seen_ids: set[str] = set()
        for item in parsed:
            fid = str(item.get("factor_id", "")).upper().strip()
            if fid not in FITCH_FACTORS:
                continue
            score = int(item.get("score", 1))
            score = max(1, min(5, score))  # clamp to 1-5
            evidence = str(item.get("evidence", "Not found"))[:500]
            results.append({
                "factor_id": fid,
                "name": FITCH_FACTORS[fid]["name"],
                "dimension": FITCH_FACTORS[fid]["dimension"],
                "score": score,
                "evidence": evidence,
                "disclosed": score > 1,
            })
            seen_ids.add(fid)

        # Backfill any factors the LLM skipped
        for fid, fdata in FITCH_FACTORS.items():
            if fid not in seen_ids:
                results.append({
                    "factor_id": fid,
                    "name": fdata["name"],
                    "dimension": fdata["dimension"],
                    "score": 1,
                    "evidence": "Not found (LLM did not return this factor)",
                    "disclosed": False,
                })

        # Return in canonical order
        order = list(FITCH_FACTORS.keys())
        results.sort(key=lambda x: order.index(x["factor_id"]) if x["factor_id"] in order else 99)
        return results

    except json.JSONDecodeError as exc:
        # Try to extract JSON array from the raw response
        match = re.search(r"\[.*\]", raw, re.DOTALL)
        if match:
            try:
                return _normalise_llm_results(json.loads(match.group()))
            except Exception:
                pass
        # Full fallback
        return regex_score_fitch_factors(pdf_text)

    except Exception:
        return regex_score_fitch_factors(pdf_text)


def _normalise_llm_results(parsed: list) -> list[dict]:
    """Shared normalisation logic reused by error handler."""
    results: list[dict] = []
    seen_ids: set[str] = set()
    for item in parsed:
        fid = str(item.get("factor_id", "")).upper().strip()
        if fid not in FITCH_FACTORS:
            continue
        score = max(1, min(5, int(item.get("score", 1))))
        results.append({
            "factor_id": fid,
            "name": FITCH_FACTORS[fid]["name"],
            "dimension": FITCH_FACTORS[fid]["dimension"],
            "score": score,
            "evidence": str(item.get("evidence", "Not found"))[:500],
            "disclosed": score > 1,
        })
        seen_ids.add(fid)
    for fid, fdata in FITCH_FACTORS.items():
        if fid not in seen_ids:
            results.append({
                "factor_id": fid,
                "name": fdata["name"],
                "dimension": fdata["dimension"],
                "score": 1,
                "evidence": "Not found",
                "disclosed": False,
            })
    order = list(FITCH_FACTORS.keys())
    results.sort(key=lambda x: order.index(x["factor_id"]) if x["factor_id"] in order else 99)
    return results


# ── Score aggregation ──────────────────────────────────────────────────────────

def fitch_factors_to_esg_dict(factors: list[dict]) -> dict:
    """
    Convert a list of 15 Fitch factor scores to E/S/G sub-scores and composite.

    Each dimension score = mean(factor scores in dimension) * 20, giving a 0–100 scale.
    Composite = E * 50% + S * 25% + G * 25%.
    Rating: AAA ≥ 80, AA ≥ 65, A ≥ 50, BBB ≥ 35, BB ≥ 20, B < 20.

    Args:
        factors: Output of score_fitch_factors().

    Returns:
        Dict with keys: e_score, s_score, g_score, composite, rating.
        All score values are floats rounded to 1 decimal place.
    """
    e_scores = [f["score"] for f in factors if f["dimension"] == "E"]
    s_scores = [f["score"] for f in factors if f["dimension"] == "S"]
    g_scores = [f["score"] for f in factors if f["dimension"] == "G"]

    def _safe_mean(vals: list[int | float]) -> float:
        return sum(vals) / len(vals) if vals else 1.0

    e_score = round(_safe_mean(e_scores) * 20, 1)
    s_score = round(_safe_mean(s_scores) * 20, 1)
    g_score = round(_safe_mean(g_scores) * 20, 1)
    composite = round(e_score * 0.50 + s_score * 0.25 + g_score * 0.25, 1)

    if composite >= 80:
        rating = "AAA"
    elif composite >= 65:
        rating = "AA"
    elif composite >= 50:
        rating = "A"
    elif composite >= 35:
        rating = "BBB"
    elif composite >= 20:
        rating = "BB"
    else:
        rating = "B"

    return {
        "e_score": e_score,
        "s_score": s_score,
        "g_score": g_score,
        "composite": composite,
        "rating": rating,
    }


# ── Persistence ────────────────────────────────────────────────────────────────

def save_fitch_scores(factors: list[dict], doc_name: str) -> None:
    """
    Persist factor scores to outputs/fitch_factors.csv.

    Existing rows for ``doc_name`` are replaced before appending the new scores,
    so re-running on the same document does not create duplicates.

    Args:
        factors: Output of score_fitch_factors().
        doc_name: Document identifier used as the 'doc' key.
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    existing_rows: list[dict] = []

    if FITCH_CSV.exists():
        try:
            with FITCH_CSV.open(newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                existing_rows = [row for row in reader if row.get("doc") != doc_name]
        except Exception:
            existing_rows = []

    from config import OUTPUT_DIR as _OD  # local import to avoid circular
    try:
        import json as _json
        _lp = _OD / "doc_labels.json"
        _labs = _json.loads(_lp.read_text(encoding="utf-8")) if _lp.exists() else {}
    except Exception:
        _labs = {}
    company_name = _labs.get(doc_name, doc_name)

    new_rows = [
        {
            "company_name": company_name,
            "doc": doc_name,
            "factor_id": f["factor_id"],
            "name": f["name"],
            "dimension": f["dimension"],
            "score": f["score"],
            "evidence": f["evidence"],
            "disclosed": f["disclosed"],
        }
        for f in factors
    ]

    all_rows = existing_rows + new_rows

    with FITCH_CSV.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=_FITCH_COLUMNS)
        writer.writeheader()
        writer.writerows(all_rows)


def load_fitch_scores(doc_name: Optional[str] = None) -> pd.DataFrame:
    """
    Load Fitch factor scores from outputs/fitch_factors.csv.

    Args:
        doc_name: If provided, filter to rows for that document only.

    Returns:
        DataFrame with columns matching _FITCH_COLUMNS, or an empty DataFrame
        if the file does not exist.
    """
    if not FITCH_CSV.exists():
        return pd.DataFrame(columns=_FITCH_COLUMNS)

    try:
        df = pd.read_csv(str(FITCH_CSV), dtype=str)
        # Coerce numeric columns
        if "score" in df.columns:
            df["score"] = pd.to_numeric(df["score"], errors="coerce").fillna(1).astype(int)
        if "disclosed" in df.columns:
            df["disclosed"] = df["disclosed"].map(
                lambda v: str(v).lower() in ("true", "1", "yes")
            )
        if doc_name is not None:
            df = df[df["doc"] == doc_name].reset_index(drop=True)
        return df
    except Exception:
        return pd.DataFrame(columns=_FITCH_COLUMNS)


# ── CLI entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python fitch_scorer.py <path_to_pdf>")
        sys.exit(1)

    from esg_scorer import extract_full_text

    pdf_path = Path(sys.argv[1])
    if not pdf_path.exists():
        print(f"File not found: {pdf_path}")
        sys.exit(1)

    print(f"Extracting text from {pdf_path.name}...")
    text = extract_full_text(pdf_path)
    print(f"Extracted {len(text):,} characters. Scoring 15 Fitch factors...")

    factor_scores = score_fitch_factors(text, pdf_path.name)
    esg_dict = fitch_factors_to_esg_dict(factor_scores)

    print(f"\n{'='*60}")
    print(f"Document: {pdf_path.name}")
    print(f"{'='*60}")
    for f in factor_scores:
        status = "Y" if f["disclosed"] else "N"
        print(f"  [{status}] {f['factor_id']:3s} {f['name']:<35s} Score: {f['score']}  |  {f['evidence'][:80]}")

    print(f"\nE-score : {esg_dict['e_score']:.1f}")
    print(f"S-score : {esg_dict['s_score']:.1f}")
    print(f"G-score : {esg_dict['g_score']:.1f}")
    print(f"Composite: {esg_dict['composite']:.1f}  |  Rating: {esg_dict['rating']}")

    save_fitch_scores(factor_scores, pdf_path.name)
    print(f"\nScores saved to {FITCH_CSV}")
