"""
nace_tagger.py — Agent 4
Assigns NACE Rev 2.1 section codes to each extracted segment based on:
  1. Segment name keyword matching
  2. Company-level industry context from PDF filename / first-page text
  3. LLM disambiguation for ambiguous cases (optional, cached)

NACE is the European standard used globally for financial reporting classification.
Also maps to GICS sectors for US/international documents.
"""
from __future__ import annotations

import re
from typing import Optional
from config import NACE_SECTIONS

# ── NACE keyword mapping (section → keywords that strongly imply that section) ─
# Each entry: (nace_section_code, division_code, description, keywords[])
NACE_RULES: list[tuple[str, str, str, list[str]]] = [
    # Energy
    ("D", "35.1", "Electric power generation, transmission and distribution",
     ["electricity", "power", "electric", "grid", "utility", "network operator", "transmission", "distribution network"]),
    ("D", "35.2", "Manufacture of gas; distribution through mains",
     ["gas distribution", "natural gas", "gas network", "lng", "biogas"]),
    ("D", "35.3", "Steam and air conditioning supply",
     ["heat", "district heating", "steam"]),
    ("B", "06.1", "Extraction of crude petroleum",
     ["oil", "petroleum", "crude", "upstream", "exploration", "production", "e&p"]),
    ("B", "06.2", "Extraction of natural gas",
     ["natural gas", "gas extraction", "gas production"]),
    ("D", "35.11", "Production of electricity from renewable sources",
     ["offshore wind", "onshore wind", "solar", "renewable", "wind", "hydro", "bioenergy", "biomass"]),
    # Finance
    ("K", "64.1", "Monetary intermediation",
     ["bank", "banking", "retail banking", "corporate banking", "commercial banking", "treasury bank",
      "wealth management", "uspb", "services banking", "markets banking", "investment & brokerage",
      "investment banking", "credit", "loan", "deposit", "financial institution", "monetary"]),
    ("K", "65.1", "Life insurance",
     ["life insurance", "insurance", "reinsurance", "protection"]),
    ("K", "66.1", "Activities auxiliary to financial services",
     ["brokerage", "asset management", "fund management", "investment management"]),
    # Real estate
    ("L", "68.2", "Rental and operating of own or leased real estate",
     ["real estate", "residential", "commercial property", "rental", "housing", "reit"]),
    # Manufacturing - Automotive
    ("C", "29.1", "Manufacture of motor vehicles",
     ["automotive", "vehicle", "car", "truck", "renault", "volkswagen", "bmw", "ford", "toyota"]),
    ("C", "29.3", "Manufacture of parts and accessories for motor vehicles",
     ["auto parts", "components", "tier 1", "forvia", "zf", "chassis"]),
    # Manufacturing - Chemicals / Pharma
    ("C", "20", "Manufacture of chemicals and chemical products",
     ["chemical", "specialty chemicals", "evonik", "basf"]),
    ("C", "21", "Manufacture of pharmaceuticals",
     ["pharma", "pharmaceutical", "drug", "medicine", "novartis", "roche"]),
    # Telecoms
    ("J", "61", "Telecommunications",
     ["telecom", "mobile", "broadband", "telecoms", "network", "kpn", "polsat"]),
    # IT / Cloud
    ("J", "62", "Computer programming, consultancy and related activities",
     ["cloud", "software", "it services", "google cloud", "google services", "other bets", "technology"]),
    ("J", "63", "Information service activities",
     ["data", "platform", "digital", "online", "google", "alphabet"]),
    # Transport
    ("H", "49", "Land transport",
     ["rail", "road transport", "logistics land"]),
    ("H", "50", "Water transport",
     ["shipping", "maritime", "sea", "hlag", "hapag"]),
    ("H", "51", "Air transport",
     ["airline", "aviation", "airport", "heathrow"]),
    ("H", "52", "Warehousing and support activities",
     ["logistics", "warehousing", "supply chain", "dhl", "freight"]),
    # Utilities - Water
    ("E", "36", "Water collection, treatment and supply",
     ["water", "sewerage", "wastewater", "anglian", "south west water"]),
    # Construction
    ("F", "41", "Construction of buildings",
     ["construction", "building", "housing"]),
    # Retail
    ("G", "47", "Retail trade",
     ["retail", "store", "supermarket", "e-commerce"]),
    # Paper / Packaging
    ("C", "17", "Manufacture of paper and paper products",
     ["paper", "packaging", "cardboard", "smurfit", "ds smith"]),
    # Metals / Mining
    ("B", "07", "Mining of metal ores",
     ["mining", "aluminium", "aluminum", "alcoa", "copper", "metals", "steel"]),
    ("C", "24", "Manufacture of basic metals",
     ["smelting", "metal production", "alumina"]),
    # Machinery
    ("C", "28", "Manufacture of machinery and equipment",
     ["machinery", "equipment", "industrial", "deere", "pumps", "weir"]),
    # Accommodation / Tourism
    ("I", "55", "Accommodation",
     ["hotel", "hospitality", "accommodation", "tui"]),
]


def _normalise(s: str) -> str:
    return re.sub(r"\s+", " ", s.lower().strip())


def tag_segment(segment_name: str, company_context: str = "") -> dict:
    """
    Return the best-matching NACE code for a segment.
    company_context: first few hundred chars of the PDF to help disambiguate.
    """
    combined = _normalise(segment_name + " " + company_context)
    best_score = 0
    best_match = None

    for section, division, description, keywords in NACE_RULES:
        score = sum(1 for kw in keywords if kw in combined)
        if score > best_score:
            best_score = score
            best_match = {
                "nace_section": section,
                "nace_division": division,
                "nace_description": description,
                "nace_section_name": NACE_SECTIONS.get(section, ""),
                "match_score": score,
                "match_confidence": min(score / max(len(keywords), 1) * 2, 1.0),
            }

    if best_match is None:
        # Unknown — assign section S (Other service activities) as catch-all
        best_match = {
            "nace_section": "S",
            "nace_division": "99",
            "nace_description": "Not elsewhere classified",
            "nace_section_name": NACE_SECTIONS["S"],
            "match_score": 0,
            "match_confidence": 0.1,
        }

    return best_match


def tag_document(segments: list[dict], company_context: str = "") -> list[dict]:
    """
    Attach NACE tags to each segment row. Modifies in place and returns.
    Company-level context is derived once and shared across all segments.
    """
    for seg in segments:
        tag = tag_segment(seg.get("segment", ""), company_context)
        seg.update({
            "nace_section": tag["nace_section"],
            "nace_division": tag["nace_division"],
            "nace_description": tag["nace_description"],
            "nace_section_name": tag["nace_section_name"],
            "nace_confidence": tag["match_confidence"],
        })
    return segments


def extract_company_context(first_page_text: str) -> str:
    """Return the first 500 chars of the document to help NACE classification."""
    return _normalise(first_page_text[:500])


if __name__ == "__main__":
    test_segments = [
        {"segment": "Offshore Wind", "value": 54797},
        {"segment": "Google Cloud", "value": 58705},
        {"segment": "Retail Banking", "value": 5544986},
        {"segment": "Network operator Liander", "value": 2927},
        {"segment": "Aluminium smelting", "value": 8000},
    ]
    tagged = tag_document(test_segments, company_context="annual report renewable energy")
    for s in tagged:
        print(f"{s['segment']:40s} → NACE {s['nace_section']}.{s['nace_division']} ({s['nace_description']})")
